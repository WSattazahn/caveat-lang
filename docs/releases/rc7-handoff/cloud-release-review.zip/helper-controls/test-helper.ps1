$ErrorActionPreference='Stop'
$tokens=$null;$errors=$null
$ast=[System.Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot 'Publish-Rc7.ps1'),[ref]$tokens,[ref]$errors)
if($errors.Count){throw ($errors|Out-String)}
$functions=$ast.FindAll({param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -in @('Invoke-Native','Read-NativeJson','Assert-Hash','Get-RegistryVersion')},$true)
foreach($f in $functions){Invoke-Expression $f.Extent.Text}
$Exe='/tmp/rc7-pwsh/pwsh'
Invoke-Native -Exe $Exe -Arguments @('-NoProfile','-Command','exit 0')
$Failed=$false
try {Invoke-Native -Exe $Exe -Arguments @('-NoProfile','-Command','exit 7')} catch {$Failed=$_.Exception.Message -match 'exited 7'}
if(-not $Failed){throw 'Native exit failure not enforced'}
$Result=Read-NativeJson -Exe $Exe -Arguments @('-NoProfile','-Command','Write-Output ''{"ok":true}''')
if(-not $Result.ok){throw 'Native JSON failed'}
$Failed=$false
try {Read-NativeJson -Exe $Exe -Arguments @('-NoProfile','-Command','Write-Output ''{"ok":true}'';exit 9')} catch {$Failed=$_.Exception.Message -match 'exited 9'}
if(-not $Failed){throw 'Native JSON exit failure not enforced'}
$Sample=Join-Path $PSScriptRoot 'hash-control.txt'
[IO.File]::WriteAllText($Sample,'receipt control')
$ExpectedSha256=(Get-FileHash $Sample -Algorithm SHA256).Hash.ToLowerInvariant()
$sha=[Security.Cryptography.SHA512]::Create()
try {$ExpectedIntegrity='sha512-'+[Convert]::ToBase64String($sha.ComputeHash([IO.File]::ReadAllBytes($Sample)))} finally {$sha.Dispose()}
Assert-Hash $Sample
$ExpectedSha256='0'*64
$Failed=$false
try {Assert-Hash $Sample} catch {$Failed=$_.Exception.Message -match 'SHA256 mismatch'}
if(-not $Failed){throw 'SHA256 failure not enforced'}
$ExpectedSha256=(Get-FileHash $Sample -Algorithm SHA256).Hash.ToLowerInvariant()
$ExpectedIntegrity='sha512-invalid'
$Failed=$false
try {Assert-Hash $Sample} catch {$Failed=$_.Exception.Message -match 'SHA512 integrity mismatch'}
if(-not $Failed){throw 'SHA512 failure not enforced'}
'PowerShell parser/native exit/JSON/hash controls passed (Linux PowerShell; not a Windows end-to-end publication test)'

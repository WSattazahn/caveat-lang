import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {existsSync, mkdirSync, readFileSync, writeFileSync} from 'node:fs';
import {dirname, join, resolve} from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';

const HERE = fileURLToPath(import.meta.url);
const ROOT = resolve(dirname(HERE), '..');
const SOURCE_PATH = join(ROOT, 'fixtures/post-collection.cav');
const INVENTORY_PATH = join(ROOT, 'post-collection-inventory.json');
const sha = value => createHash('sha256').update(value).digest('hex');
const source = readFileSync(SOURCE_PATH, 'utf8');
const trace = ['start', 'advance', 'skip', 'decide'];
const markerPaths = [['commitment_grounds', 'trust'], ['commitment_bases', 'trust', 'provenance']];
const at = (value, keys) => keys.reduce((item, key) => item[key], value);
const withdrawal = value => value.withdrawals.find(item => item.evidence === 'b@2');
const markerEdit = (value, edit) => { for (const keys of markerPaths) edit(at(value, keys)); };
const withdrawnEdge = edge => edge[0] === 'withdrawn' && edge[1] === 'qualifies' && edge[2] === 'b@2';
const mutants = [
  ['P10', 'duplicate same-history marker after genuine collection', value => markerEdit(value, p => p.departed.push(structuredClone(p.departed[0])))],
  ['P11', 'marker endpoint names still-held r@2', value => markerEdit(value, p => { p.departed[0].through = 2; })],
  ['P12', 'marker archive reference is uppercase hex', value => markerEdit(value, p => { p.departed[0].archive_ref = 'A'.repeat(64); })],
  ['P13', 'remaining withdrawal subject replaced with departed a@2', value => { withdrawal(value).evidence = 'a@2'; }],
  ['P14', 'remaining withdrawal reason replaced with departed a@2', value => { withdrawal(value).because = 'a@2'; }],
  ['P15', 'remove only remaining withdrawal ledger record', value => { value.withdrawals = value.withdrawals.filter(item => item.evidence !== 'b@2'); }],
  ['P16', 'remove only remaining withdrawal graph edge', value => { value.graph.relations = value.graph.relations.filter(edge => !withdrawnEdge(edge)); }],
  ['P17', 'duplicate remaining withdrawal ledger record', value => { value.withdrawals.push(structuredClone(withdrawal(value))); }],
  ['P18', 'remaining withdrawal has zero sequence', value => { withdrawal(value).sequence = 0; }],
  ['P19', 'remaining withdrawal names declared non-producing event', value => { withdrawal(value).event = 'continue'; }],
];
const inventory = {
  schema: 'caveat-post-collection-probes/1',
  scope: 'New source-derived P probes; not replicas of the unlocated F findings. No runtime or semantic edits.',
  driverSha256: sha(readFileSync(HERE)), sourceSha256: sha(source), trace,
  cells: ['rc15', 'candidate'],
  controls: [
    {id: 'P00', cells: ['rc15', 'candidate'], expected: 'Authentic same-cell exact restore; state-rooted original b@2 withdrawal; rejected final binding preserves save and snapshot, and candidate undrained archive; accepted continuation and root release match same-cell restored session. rc15 archive handover is unsupported, not a runtime-tested empty archive.'},
    {id: 'P01', cells: ['candidate'], expected: 'Actual advance collected a@2 while b@2 remained independently rooted; genuine r@1 departure markers and exact original withdrawal archive.'},
    {id: 'P02', cells: ['rc15-to-candidate'], expected: 'Authentic rc15 save restores without collection; rejected continuation changes nothing; accepted continuation collects isolated a@2, retains b@2 and its original reason, and remains restorable.'},
  ],
  mutants: mutants.map(([id, title]) => ({id, title, cell: 'candidate', expected: 'restore refusal with kind restore; an accepted mutant is a failed probe'})),
  contracts: ['spec/caveat-lineage-compaction-0.1.md:385-405', 'spec/caveat-withdrawal-0.1.md:110-122', 'spec/caveat-departure-0.1.md:66-76,104-111,153-170', 'docs/design/withdrawal-collector-draft.md:34-40,64-69'],
  limits: ['No authenticated replay or host integrity claim.', 'No prompt-injection or tool-permission probe.', 'rc15 has no departure markers or archive handover; candidate-only mutants are not run as rc15 format tests.', 'Every mutation is applied independently to one authentic post-collection save; no expectation of whole cross-version snapshot equality.', 'All source numbers are positive integers or zero; authentic controls preserve save text exactly.'],
};

if (process.argv.includes('--inventory')) {
  assert.equal(process.argv.length, 3, 'only --inventory is accepted in inventory mode');
  writeFileSync(INVENTORY_PATH, `${JSON.stringify(inventory, null, 2)}\n`, {flag: 'wx'});
  console.log(JSON.stringify({inventory: INVENTORY_PATH, sha256: sha(readFileSync(INVENTORY_PATH)), driverSha256: inventory.driverSha256, sourceSha256: inventory.sourceSha256}));
} else {
  assert.equal(process.argv.length, 4, 'usage: node post-collection-probes.mjs --out FRESH_DIRECTORY');
  assert.equal(process.argv[2], '--out');
  const output = resolve(process.argv[3]);
  assert.ok(!existsSync(output), 'output directory must be fresh');
  assert.deepEqual(JSON.parse(readFileSync(INVENTORY_PATH, 'utf8')), inventory, 'frozen inventory or source changed');
  mkdirSync(output, {recursive: false});
  const rows = [], runtimes = {}, bases = {};
  const artifact = (name, value) => writeFileSync(join(output, name), typeof value === 'string' ? value : `${JSON.stringify(value, null, 2)}\n`, {flag: 'wx'});
  artifact('inventory.json', readFileSync(INVENTORY_PATH, 'utf8'));
  artifact('source.cav', source);
  artifact('driver.mjs', readFileSync(HERE, 'utf8'));
  artifact('repro.json', {argv: process.argv, node: process.version, platform: process.platform, arch: process.arch, cwd: process.cwd(), inventorySha256: sha(readFileSync(INVENTORY_PATH)), sourceSha256: sha(source), driverSha256: sha(readFileSync(HERE))});
  const accepted = (session, event) => { const result = session.dispatch(event); assert.equal(result.outcome, 'accepted', `${event}: ${JSON.stringify(result)}`); return result; };
  const drain = session => session.drainArchive?.() ?? [];
  const pendingCount = session => session.undrained ?? 0;
  const recordItems = archive => archive.filter(item => item.kind !== 'provenance');
  const assertHeld = save => {
    assert.deepEqual(withdrawal(save), {evidence: 'b@2', because: 'b@2', sequence: 1, event: 'start'});
    assert.ok(Object.hasOwn(save.retired, 'b@2'), 'rooted old occurrence must be retired but standing');
    assert.ok((save.states.held.grounds ?? save.states.held.lineage).evidence.includes('b@2'), 'real state own-ground root is required');
    assert.equal(save.graph.relations.filter(withdrawnEdge).length, 1);
  };
  const build = runtime => {
    const session = runtime.open(source), events = [];
    try { for (const event of trace) events.push({event, result: accepted(session, event)}); return {session, events}; }
    catch (error) { session.close(); throw error; }
  };
  async function check(id, cell, expected, body) {
    const row = {id, cell, expected};
    try { row.observed = await body(); row.pass = true; }
    catch (error) { row.pass = false; row.error = String(error.stack ?? error); }
    rows.push(row);
    artifact(`${String(rows.length).padStart(2, '0')}-${cell}-${id}.json`, row);
    console.log(JSON.stringify(row));
  }
  try {
    for (const cell of ['rc15', 'candidate']) {
      const directory = join(ROOT, 'cells', cell), runtimeDirectory = join(directory, 'runtime');
      const {loadRuntimeFromDirectory} = await import(pathToFileURL(join(directory, 'lib/node.mjs')).href);
      const runtime = await loadRuntimeFromDirectory(runtimeDirectory);
      runtimes[cell] = runtime;
      artifact(`${cell}-identity.json`, {identity: runtime.identity, files: Object.fromEntries(['caveat_runtime.js', 'caveat_runtime_bg.wasm'].map(name => [name, sha(readFileSync(join(runtimeDirectory, name)))])), nodeLoaderSha256: sha(readFileSync(join(directory, 'lib/node.mjs'))), sessionLibrarySha256: sha(readFileSync(join(directory, 'lib/session.mjs')))});
      await check('P00', cell, inventory.controls[0].expected, () => {
        const original = build(runtime), reference = build(runtime);
        let restored;
        try {
          if (cell === 'candidate') {
            assert.equal(typeof original.session.drainArchive, 'function', 'candidate archive handover API required');
            assert.equal(typeof original.session.undrained, 'number', 'candidate pending archive count API required');
          }
          const text = original.session.save(), snapshot = original.session.snapshot(), save = JSON.parse(text);
          assert.equal(reference.session.save(), text);
          const archive = drain(reference.session);
          bases[cell] = {text, snapshot, save, archive, events: original.events};
          artifact(`${cell}-authentic-save.json`, text);
          artifact(`${cell}-authentic-snapshot.json`, snapshot);
          artifact(`${cell}-authentic-archive.json`, archive);
          artifact(`${cell}-events.json`, original.events);
          assertHeld(save);
          restored = runtime.restore(source, text);
          assert.equal(restored.save(), text);
          assert.deepEqual(restored.snapshot(), snapshot);
          assert.equal(pendingCount(restored), 0);
          assert.equal(pendingCount(original.session), archive.length);
          const failures = [];
          for (const [name, session] of [['original', original.session], ['restored', restored]]) {
            const pending = pendingCount(session), result = session.dispatch('fail');
            assert.equal(result.outcome, 'rejected');
            assert.equal(result.origin, 'evaluation');
            assert.equal(session.save(), text);
            assert.deepEqual(session.snapshot(), snapshot);
            assert.equal(pendingCount(session), pending);
            failures.push({name, result, unchangedSaveSha256: sha(session.save()), archiveApplicable: cell === 'candidate', undrained: cell === 'candidate' ? pending : null});
          }
          assert.deepEqual(drain(original.session), archive);
          assert.deepEqual(drain(restored), []);
          for (const event of ['continue', 'release']) {
            accepted(original.session, event); accepted(restored, event);
            assert.equal(restored.save(), original.session.save());
            assert.deepEqual(restored.snapshot(), original.session.snapshot());
            const nextArchive = drain(original.session);
            assert.deepEqual(drain(restored), nextArchive);
            artifact(`${cell}-${event}-archive.json`, nextArchive);
            if (event === 'release' && cell === 'candidate') assert.deepEqual(recordItems(nextArchive).map(item => item.record), ['b@2']);
          }
          artifact(`${cell}-failed-continuations.json`, failures);
          artifact(`${cell}-continued-save.json`, original.session.save());
          return {authenticSaveSha256: sha(text), archiveApplicable: cell === 'candidate', archiveItems: cell === 'candidate' ? archive.length : null, archiveRecords: cell === 'candidate' ? recordItems(archive).map(item => item.record) : null, failures, continuedSaveSha256: sha(original.session.save())};
        } finally { restored?.close(); original.session.close(); reference.session.close(); }
      });
    }
    await check('P01', 'candidate', inventory.controls[1].expected, () => {
      const base = bases.candidate;
      assert.ok(base, 'authentic candidate trace missing');
      assertHeld(base.save);
      assert.ok(!Object.hasOwn(base.save.retired, 'a@2'));
      assert.ok(!base.save.withdrawals.some(item => item.evidence === 'a@2'));
      const advance = base.events.find(item => item.event === 'advance').result.snapshot;
      assert.ok(advance.effects.some(item => item.kind === 'depart' && item.record === 'a@2'));
      assert.ok(!advance.effects.some(item => item.kind === 'depart' && item.record === 'b@2'));
      const departed = recordItems(base.archive).find(item => item.record === 'a@2');
      assert.ok(departed);
      assert.deepEqual(departed.withdrawal, {evidence: 'a@2', because: 'a@2', sequence: 1, event: 'start'});
      for (const keys of markerPaths) {
        const markers = at(base.save, keys).departed;
        assert.equal(markers.length, 1);
        assert.deepEqual({history: markers[0].history, from: markers[0].from, through: markers[0].through, read: markers[0].read}, {history: 'r', from: 1, through: 1, read: 1});
        assert.match(markers[0].archive_ref, /^[0-9a-f]{64}$/);
      }
      assert.ok(base.archive.some(item => item.record === 'r@1' && item.kind !== 'provenance'));
      return {retained: withdrawal(base.save), root: base.save.states.held, collectedWithdrawal: departed.withdrawal, marker: at(base.save, markerPaths[0]).departed[0]};
    });
    assert.ok(rows.find(row => row.id === 'P01')?.pass, 'candidate mutation preconditions must pass');
    for (const [id, title, mutate] of mutants) await check(id, 'candidate', 'restore refusal with kind restore', () => {
      const doc = structuredClone(bases.candidate.save); mutate(doc);
      const text = JSON.stringify(doc);
      assert.notEqual(text, JSON.stringify(bases.candidate.save), 'mutation must alter save');
      artifact(`${id}-mutant-save.json`, text);
      let refused;
      try {
        const session = runtimes.candidate.restore(source, text);
        try { artifact(`${id}-unexpected-accepted-save.json`, session.save()); } finally { session.close(); }
      } catch (error) { refused = {kind: error.kind, message: error.message}; }
      assert.ok(refused, 'malformed save unexpectedly accepted');
      assert.equal(refused.kind, 'restore', 'traps/fatal errors do not count as correct refusal');
      return {title, refused, mutantSha256: sha(text)};
    });
    await check('P02', 'rc15-to-candidate', inventory.controls[2].expected, () => {
      assert.ok(bases.rc15, 'authentic rc15 save missing');
      const session = runtimes.candidate.restore(source, bases.rc15.text);
      try {
        const before = session.save(), snapshot = session.snapshot(), doc = JSON.parse(before);
        assertHeld(doc);
        assert.ok(Object.hasOwn(doc.retired, 'a@2'), 'restore must not migrate by collecting');
        assert.equal(session.undrained, 0);
        const failure = session.dispatch('fail');
        assert.equal(failure.outcome, 'rejected'); assert.equal(failure.origin, 'evaluation');
        assert.equal(session.save(), before); assert.deepEqual(session.snapshot(), snapshot); assert.equal(session.undrained, 0);
        const continued = accepted(session, 'continue');
        assertHeld(JSON.parse(session.save()));
        assert.ok(continued.snapshot.effects.some(item => item.kind === 'depart' && item.record === 'a@2'));
        const archive = session.drainArchive();
        const moved = recordItems(archive).find(item => item.record === 'a@2');
        assert.deepEqual(moved.withdrawal, {evidence: 'a@2', because: 'a@2', sequence: 1, event: 'start'});
        const again = runtimes.candidate.restore(source, session.save());
        try { assert.equal(again.save(), session.save()); assert.deepEqual(again.snapshot(), session.snapshot()); } finally { again.close(); }
        artifact('rc15-to-candidate-restored-save.json', before);
        artifact('rc15-to-candidate-failed-continuation.json', failure);
        artifact('rc15-to-candidate-continued-save.json', session.save());
        artifact('rc15-to-candidate-archive.json', archive);
        return {restoredSaveSha256: sha(before), failed: failure, retained: withdrawal(JSON.parse(session.save())), departed: recordItems(archive).map(item => item.record)};
      } finally { session.close(); }
    });
  } catch (error) {
    rows.push({id: 'setup-or-precondition', pass: false, error: String(error.stack ?? error)});
  }
  const report = {schema: 'caveat-post-collection-probe-result/1', inventorySha256: sha(readFileSync(INVENTORY_PATH)), driverSha256: sha(readFileSync(HERE)), sourceSha256: sha(source), pass: rows.length === 14 && rows.every(row => row.pass), counts: {rows: rows.length, passed: rows.filter(row => row.pass).length, failed: rows.filter(row => !row.pass).length, expectedMutants: 10}, rows};
  artifact('result.json', report);
  console.log(JSON.stringify({pass: report.pass, counts: report.counts, output}));
  if (!report.pass) process.exitCode = 1;
}

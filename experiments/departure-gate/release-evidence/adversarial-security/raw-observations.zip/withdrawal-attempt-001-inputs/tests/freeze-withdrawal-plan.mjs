import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { cases } from './withdrawal-probes.mjs';
const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const files = ['tests/withdrawal-probes.mjs', 'tests/freeze-withdrawal-plan.mjs', ...new Set(cases.map(c => `fixtures/${c.fixture}`))];
const plan = {
  schema: 'caveat-new-withdrawal-plan/1', at: new Date().toISOString(),
  provenance: 'NEW W01-W20 synthetic probes. No original F-series reproduction claimed; original sources unavailable at freeze.',
  execution: 'Exactly 20 probes in both separately loaded frozen WASM cells (40 cell attempts). Each attempt has a fresh runtime instance; preserve failures and continue this finite inventory. No timing or performance inference.',
  command: 'node tests/withdrawal-probes.mjs --root . --out withdrawal-results-001.json',
  scope: 'Withdrawal save consistency, first-record authority, true reasons and own grounds/qualifications across live historical holders, rollback, restore and approved collection. Host trust limits are accepted controls, not authenticated history. Candidate-only archive behavior is not an rc15 API failure.',
  contracts: ['spec/caveat-withdrawal-0.1.md', 'spec/caveat-save-0.1.md', 'spec/caveat-departure-0.1.md', 'spec/caveat-lineage-compaction-0.1.md', 'docs/design/withdrawal-collector-draft.md'],
  priorCoverage: ['runtime/tests/withdrawal.rs', 'runtime/tests/withdrawal_collection.rs', 'runtime/tests/restore_capability.rs', 'experiments/departure-gate/withdrawal-fixtures/self-own-ground.cav', 'experiments/departure-gate/withdrawal-fixtures/later-history-read.cav', 'experiments/departure-gate/withdrawal-fixtures/reachable-chain.cav'],
  comparison: 'Both cells must individually meet each frozen expectation. Shared projections compare only reason records, live values, own grounds and qualifiers; W18/W19 lifecycle fields and archives are intentionally not forced equal between versions. Each cell must produce exact original/restored continuation and ordered archive equality where available.',
  rejection: 'Malformed saves must throw kind restore; arbitrary load/fatal/assertion errors never count as successful rejection. Each malformed case restores an unmodified positive-control save first.',
  evidence: 'Per-attempt source plus every save, snapshot, dispatch outcome, restore input/error and available archive drain retained as exclusive files. Append-only attempt ledger; output paths refuse overwrite. Outer recorder preserves stdout/stderr and verifies all cell bytes before/after.',
  limitations: 'Finite synthetic probes only. Known source-possible false historical guard and coordinated omission controls do not authenticate history. Required chain length is four cycles plus one continuation; no graph-size or adversarial completeness claim. Original F256/F358/F362/F363/F364 mapping waits for exact inputs.',
  cellsSha256: sha(readFileSync(path.join(root, 'cells.json'))),
  inputs: files.map(file => ({ file, sha256: sha(readFileSync(path.join(root, file))) })), cases,
};
writeFileSync(path.join(root, 'withdrawal-plan.json'), `${JSON.stringify(plan, null, 2)}\n`, { encoding: 'utf8', flag: 'wx' });
console.log(JSON.stringify({ cases: cases.length, cellAttempts: 2 * cases.length, planSha256: sha(readFileSync(path.join(root, 'withdrawal-plan.json'))), inputs: plan.inputs }, null, 2));

import assert from 'node:assert/strict';
import {readFileSync, writeFileSync, mkdirSync, existsSync} from 'node:fs';
import {resolve, dirname, join} from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';

const ROOT=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const sha=x=>createHash('sha256').update(x).digest('hex');
const copy=x=>structuredClone(x);
const inventoryFile='archive-marker-inventory-v2.json';
const markerMutants=[
  ['M01','unknown history',m=>m.history='absent'],
  ['M02','declared non-history',m=>m.history='sensor'],
  ['M03','from below one',m=>m.from=0],
  ['M04','inverted range',m=>m.from=m.through+1],
  ['M05','live occurrence endpoint',m=>m.through=2],
  ['M06','zero read',m=>m.read=0],
  ['M07','read exceeds departed range',m=>m.read=2],
  ['M08','zero departure sequence',m=>m.departed_at=0],
  ['M09','future departure sequence',m=>m.departed_at=999],
  ['M10','fractional range',m=>m.from=1.5],
  ['M11','malformed archive reference',m=>m.archive_ref='not-a-digest'],
];
const inventory={scope:'New repository-derived probes; not replicas of unavailable Muse F findings. Frozen expectations before first execution.',
 marker: [...markerMutants.map(([id,title])=>({id,title,expected:'candidate restore refusal; rc15 markers not applicable'})),
 {id:'M12',title:'duplicate same-history markers',expected:'candidate restore refusal'},
 {id:'M13',title:'grounds marker outside basis',expected:'candidate restore refusal'},
 {id:'M14',title:'well-formed missing archive root',expected:'candidate restore accepted; exact membership unavailable'},
 {id:'M15',title:'optional archive reference omitted',expected:'candidate restore accepted; conservative marker rendering'},
 {id:'M00',title:'authentic save and continued execution',expected:'both cells accepted; exact same-cell save/snapshot/continuation'}],
 archive:['complete','missing-reason-record','missing-reason-node','conflicting-reason-record','foreign-source-node','wrong-subject','missing-reason-field','absent-reason','future-withdrawal','zero-withdrawal','fractional-withdrawal','future-departure','inverted-retirement','invalid-relation-kind','unrelated-edge','malformed-nested-provenance','conflicting-leaf','identical-duplicates','consistent-payload-edit','reversed-conflicting-record','reversed-conflicting-leaf'].map((title,i)=>({id:`A${String(i).padStart(2,'0')}`,title,expected:['complete','identical-duplicates','consistent-payload-edit'].includes(title)?'complete supplied closure, unauthenticated':'dependent record unavailable without exact-looking payload'})),
 independentComponent:'Unrelated z@1 remains complete with value 7 for every archive mutation.',
 combinations:['immediate drain','delayed drain','saved/restored snapshot'],
 limits:['No agent/tool/prompt-injection test.','rc15 has no departure/archive API; actual retained withdrawals remain checked as approved lifecycle contrast.','Payload consistency is not authentication.','No performance claim.']};
if(process.argv.includes('--inventory')){
  const target=join(ROOT,inventoryFile);
  writeFileSync(target,JSON.stringify(inventory,null,2)+'\n',{flag:'wx'});
  console.log(JSON.stringify({inventory:target,sha256:sha(readFileSync(target))}));
} else {
 const output=resolve(process.argv[process.argv.indexOf('--out')+1]);
 assert.ok(process.argv.includes('--out')&&!existsSync(output));
 assert.deepEqual(JSON.parse(readFileSync(join(ROOT,inventoryFile),'utf8')),inventory);
 mkdirSync(output,{recursive:false});
 const results=[];
 const cellManifest=JSON.parse(readFileSync(join(ROOT,'cells.json'),'utf8'));
 function verifyCells(){for(const cell of cellManifest.cells)for(const file of cell.files){const bytes=readFileSync(join(ROOT,file.file));assert.equal(bytes.length,file.bytes);assert.equal(sha(bytes),file.sha256,file.file);}}
 verifyCells();
 const saveArtifact=(name,value)=>writeFileSync(join(output,name),typeof value==='string'?value:JSON.stringify(value,null,2)+'\n',{flag:'wx'});
 async function check(id,cell,label,expected,body){
   const row={id,cell,label,expected};
   try{row.observed=await body();row.pass=true;}catch(error){row.pass=false;row.error=String(error.stack??error);}
   results.push(row);saveArtifact(`${String(results.length).padStart(3,'0')}-${cell}-${id}.json`,row);
 }
 const accepted=(s,e)=>assert.equal(s.dispatch(e).outcome,'accepted',e);
 const allMarkers=x=>{
   const found=[];function walk(v){if(!v||typeof v!=='object')return;if(v.archive_status)found.push(v);for(const v2 of Object.values(v))if(v2&&typeof v2==='object')walk(v2);}walk(x);return found;
 };
 for(const cell of ['rc15','candidate']){
   const kit=join(ROOT,'cells',cell);
   const {loadRuntimeFromDirectory}=await import(pathToFileURL(join(kit,'lib/node.mjs')).href);
   const runtime=await loadRuntimeFromDirectory(join(kit,'runtime'));
   saveArtifact(`${cell}-loaded-runtime.json`,runtime.identity);
   const {explain,formatExplanation,dependents}=await import(pathToFileURL(join(kit,'lib/explain.mjs')).href);
   const source=readFileSync(join(ROOT,'fixtures/marker-journal.cav'),'utf8');
   const s=runtime.open(source);
   for(const event of ['record','advance','skip','decide'])accepted(s,event);
   const archive=s.drainArchive?.()??[], original=s.save(), snapshot=s.snapshot();
   saveArtifact(`${cell}-marker-save.json`,original);saveArtifact(`${cell}-marker-snapshot.json`,snapshot);saveArtifact(`${cell}-marker-archive.json`,archive);
   await check('M00',cell,'authentic save and continuation','accepted exact roundtrip',()=>{
     const r=runtime.restore(source,original);try{
       assert.equal(r.save(),original);assert.deepEqual(r.snapshot(),snapshot);assert.equal(r.undrained??0,0);
       accepted(s,'continue');accepted(r,'continue');assert.equal(r.save(),s.save());assert.deepEqual(r.snapshot(),s.snapshot());
       assert.deepEqual(r.drainArchive?.()??[],s.drainArchive?.()??[]);
       return {accepted:true,originalSha256:sha(original),continuedSha256:sha(s.save())};
     }finally{r.close();}
   });s.close();
   if(cell==='candidate'){
     const base=JSON.parse(original);
     const paths=[['commitment_grounds','trust'],['commitment_bases','trust','provenance']];
     const at=(obj,path)=>path.reduce((v,key)=>v[key],obj);
     assert.equal(at(base,paths[0]).departed.length,1);
     const invalids=markerMutants.map(([id,title,mutate])=>[id,title,doc=>{for(const path of paths)mutate(at(doc,path).departed[0]);}]);
     invalids.push(['M12','duplicate same-history markers',doc=>{for(const p of paths)at(doc,p).departed.push(copy(at(doc,p).departed[0]));}]);
     invalids.push(['M13','grounds outside basis',doc=>delete at(doc,paths[1]).departed]);
     for(const [id,title,mutate]of invalids)await check(id,cell,title,'restore refusal',()=>{
       const forged=copy(base);mutate(forged);const text=JSON.stringify(forged);saveArtifact(`${cell}-${id}-save.json`,text);
       let error;try{const r=runtime.restore(source,text);r.close();}catch(e){error={kind:e.kind,message:e.message};}
       assert.ok(error,'malformed save accepted');assert.equal(error.kind,'restore');return {refused:true,...error};
     });
     for(const [id,title,mutate]of [['M14','missing archive root',m=>m.archive_ref='f'.repeat(64)],['M15','optional reference removed',m=>delete m.archive_ref]])await check(id,cell,title,'restore accepted, conservative explanation',()=>{
       const forged=copy(base);for(const p of paths)mutate(at(forged,p).departed[0]);const text=JSON.stringify(forged);saveArtifact(`${cell}-${id}-save.json`,text);
       const r=runtime.restore(source,text);try{
         const report=explain(r.snapshot(),[],{archive});saveArtifact(`${cell}-${id}-report.json`,report);
         const relevant=allMarkers(report).filter(m=>m.history==='r'&&m.archive_ref===at(forged,paths[0]).departed[0].archive_ref);
         assert.ok(relevant.length);assert.ok(relevant.every(m=>m.archive_status==='unavailable'&&!m.records));
         assert.match(formatExplanation(report),/exact archive reconstruction unavailable/);
         return {restored:true,unavailableMarkers:relevant.length};
       }finally{r.close();}
     });
   }
   const nested=readFileSync(join(ROOT,'fixtures/nested-withdrawal.cav'),'utf8');
   for(const drain of ['immediate','delayed']){
     const n=runtime.open(nested), captured=[];accepted(n,'create');if(drain==='immediate')captured.push(...(n.drainArchive?.()??[]));accepted(n,'advance');captured.push(...(n.drainArchive?.()??[]));
     const ns=n.snapshot(), saved=n.save();const restored=runtime.restore(nested,saved);
     saveArtifact(`${cell}-${drain}-nested-save.json`,saved);saveArtifact(`${cell}-${drain}-nested-archive.json`,captured);
     if(cell==='rc15'){
       await check('A-rc15',cell,drain,'retained original withdrawal; no departure API',()=>{
         assert.ok(ns.withdrawals.some(w=>w.evidence==='a@2'&&w.because==='a@2'));
         assert.deepEqual(restored.snapshot(),ns);assert.equal(captured.length,0);
         return {withdrawal:ns.withdrawals.find(w=>w.evidence==='a@2'),archiveApplicable:false};
       });
     }else{
       const {archiveNodeId}=await import(pathToFileURL(join(kit,'lib/archive.mjs')).href);
       const variants=[
         ['A00',a=>a],
         ['A01',a=>a.filter(x=>!(x.kind!=='provenance'&&x.record==='a@2'))],
         ['A02',a=>a.filter(x=>!(x.kind==='provenance'&&x.record==='a@2'))],
         ['A03',a=>[...a,{...copy(a.find(x=>x.kind!=='provenance'&&x.record==='a@2')),retired_at:0}]],
         ['A04',a=>a.map(x=>x.kind==='provenance'&&x.record==='a@2'?{...x,source_id:'different-source'}:x)],
         ['A05',a=>{a.find(x=>x.withdrawal).withdrawal.evidence='r@1';return a;}],
         ['A06',a=>{delete a.find(x=>x.withdrawal).withdrawal.because;return a;}],
         ['A07',a=>{a.find(x=>x.withdrawal).withdrawal.because='absent';return a;}],
         ['A08',a=>{a.find(x=>x.withdrawal).withdrawal.sequence=999;return a;}],
         ['A09',a=>{a.find(x=>x.withdrawal).withdrawal.sequence=0;return a;}],
         ['A10',a=>{a.find(x=>x.withdrawal).withdrawal.sequence=1.5;return a;}],
         ['A11',a=>{for(const x of a)if(x.record==='a@2'){x.departed_at=999;if(x.kind==='provenance')x.id=archiveNodeId(x);}return a;}],
         ['A12',a=>{a.find(x=>x.kind!=='provenance'&&x.record==='a@2').retired_at=999;return a;}],
         ['A13',a=>{a.find(x=>x.kind!=='provenance'&&x.record==='a@2').relations.push(['a@2','invalid','seen']);return a;}],
         ['A14',a=>{a.find(x=>x.kind!=='provenance'&&x.record==='a@2').relations.push(['template','supports','seen']);return a;}],
         ['A15',a=>{a.find(x=>x.record==='r@1'&&x.reading).reading.provenance.evidence=null;return a;}],
         ['A16',a=>{const leaf=copy(a.find(x=>x.kind==='provenance'&&x.record==='a@2'));leaf.source_id='conflict';return [...a,leaf];}],
         ['A17',a=>[...a,...copy(a)].reverse()],
         ['A18',a=>{a.find(x=>x.record==='r@1'&&x.reading).reading.value=999;return a;}],
         ['A19',a=>[{...copy(a.find(x=>x.kind!=='provenance'&&x.record==='a@2')),retired_at:0},...a]],
         ['A20',a=>{const leaf=copy(a.find(x=>x.kind==='provenance'&&x.record==='a@2'));leaf.source_id='conflict';return [leaf,...a];}],
       ];
       for(const [where,snap]of [['live',ns],['restored',restored.snapshot()]])for(const [id,mutate]of variants){
         const def=inventory.archive.find(x=>x.id===id);
         await check(id,cell,`${drain}/${where}/${def.title}`,def.expected,()=>{
           const supplied=mutate(copy(captured));saveArtifact(`${drain}-${where}-${id}-archive.json`,supplied);
           const report=explain(snap,[],{archive:supplied});saveArtifact(`${drain}-${where}-${id}-report.json`,report);
           assert.equal(report.archive.authenticated,false);assert.equal(report.archive.scope,'provided records and their referenced closure');
           const row=report.archive.records.find(x=>x.record==='r@1');assert.ok(row);
           const independent=report.archive.records.find(x=>x.record==='z@1');assert.equal(independent?.status,'complete');assert.equal(independent.entry.reading.value,7);
           if(['A00','A17','A18'].includes(id)){
             assert.equal(row.status,'complete');assert.equal(row.entry.reading.value,id==='A18'?999:1);
             assert.ok(report.archive.withdrawals.some(w=>w.evidence==='a@2'&&w.because==='a@2'));
             assert.match(formatExplanation(report),/not authenticated or proven exhaustive/);
           }else{
             assert.equal(row.status,'unavailable');assert.equal(row.entry,undefined);
             assert.match(formatExplanation(report),/archive reconstruction unavailable/);
           }
           assert.deepEqual(report.evidence,explain(snap).evidence);assert.deepEqual(report.decisions,explain(snap).decisions);
           const query=dependents(snap,'a@2',{archive:supplied});assert.deepEqual(query.withdrawals,[]);
           assert.equal(n.save(),saved);assert.equal(restored.save(),saved);
           return {status:row.status,unresolved:row.unresolved,authenticated:report.archive.authenticated};
         });
       }
     }
     n.close();restored.close();
   }
 }
 verifyCells();
 const report={scope:inventory.scope,at:new Date().toISOString(),cases:results.length,passed:results.filter(x=>x.pass).length,failed:results.filter(x=>!x.pass).length,cellsManifestSha256:sha(readFileSync(join(ROOT,'cells.json'))),cellFilesStable:true,inventorySha256:sha(readFileSync(join(ROOT,inventoryFile))),scriptSha256:sha(readFileSync(fileURLToPath(import.meta.url))),results};
 saveArtifact('summary.json',report);console.log(JSON.stringify({cases:report.cases,passed:report.passed,failed:report.failed,out:output}));if(report.failed)process.exitCode=1;
}

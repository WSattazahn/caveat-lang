// CR12: compact save format for the Glowcap policy.
//
// Evidence ids are rebuilt from (verb, spot, life); caveats are one-letter
// flags; decision lists reference evidence by index. Only unfaded tastes keep
// a clock. Numbers round-trip exactly through JSON.
import type { Evidence, Kind, Slot, State } from './glowcap.ts';
import { LEVEL } from './glowcap.ts';

const VERBS = ['absorb', 'taste', 'witness'];
const CAVEAT_FLAGS: Record<string, string> = { tasted_in_dark: 'd', taste_faded: 'f', secondhand: 's' };

interface Saved {
  v: 1;
  g: number; // glow timer
  h: number; // heavy timer
  e: string[]; // evidence: <verb><kind><spot>.<life><flags>
  a: [number, number][]; // [evidence index, age] for unfaded tastes
  s: [number, number, number, number, number][]; // per spot: life, consumed, sinceConsumed, taste idx, consumedBy idx
  r: number[]; // sinceContradiction
  d: [number, number[], number[], string, [number, number[]][]]; // state, basis, reopenedBy, caveat flags, history
}

const DECISION_STATES = ['none', 'committed', 'reopened'] as const;

function flagsOf(caveats: readonly string[]): string {
  return caveats.map((c) => CAVEAT_FLAGS[c] ?? '').join('');
}

function caveatsFromFlags(flags: string): string[] {
  const out: string[] = [];
  for (const ch of flags) {
    const name = Object.keys(CAVEAT_FLAGS).find((k) => CAVEAT_FLAGS[k] === ch);
    if (name === undefined) throw new Error(`bad save: caveat flag ${ch}`);
    out.push(name);
  }
  return out;
}

export function encodeSave(st: State): Saved {
  const index = new Map<string, number>();
  st.evidence.forEach((ev, i) => index.set(ev.id, i));
  const idx = (id: string): number => {
    const i = index.get(id);
    if (i === undefined) throw new Error(`internal: unknown evidence ${id}`);
    return i;
  };
  const e = st.evidence.map((ev) => {
    const [verb, spot, life] = ev.id.split('_');
    return `${VERBS.indexOf(verb)}${ev.kind === 'glowcap' ? 'g' : 'd'}${LEVEL.indexOf(spot)}.${life ?? 1}${flagsOf(ev.caveats)}`;
  });
  const a: [number, number][] = [];
  st.evidence.forEach((ev, i) => {
    if (ev.age !== undefined) a.push([i, ev.age]);
  });
  const s = LEVEL.map((id): [number, number, number, number, number] => {
    const sl = st.slots[id];
    return [sl.life, sl.consumed ? 1 : 0, sl.sinceConsumed, sl.taste === undefined ? -1 : idx(sl.taste), sl.consumedBy === undefined ? -1 : idx(sl.consumedBy)];
  });
  const d = st.decision;
  return {
    v: 1,
    g: st.glow,
    h: st.heavy,
    e,
    a,
    s,
    r: st.sinceContradiction.map(idx),
    d: [
      DECISION_STATES.indexOf(d.state),
      d.basis.map(idx),
      d.reopenedBy.map(idx),
      flagsOf(d.caveats),
      d.history.map((h): [number, number[]] => [h.change === 'committed' ? 1 : 2, h.because.map(idx)]),
    ],
  };
}

export function decodeSave(raw: unknown): State {
  const sv = raw as Saved;
  if (sv === null || typeof sv !== 'object' || sv.v !== 1) throw new Error('bad save');
  const evidence: Evidence[] = sv.e.map((code) => {
    const m = /^(\d)([gd])(\d+)\.(\d+)([a-z]*)$/.exec(code);
    if (m === null) throw new Error(`bad save: evidence ${code}`);
    const verb = VERBS[Number(m[1])];
    const spot = LEVEL[Number(m[3])];
    const life = Number(m[4]);
    const kind: Kind = m[2] === 'g' ? 'glowcap' : 'duskcap';
    return { id: life === 1 ? `${verb}_${spot}` : `${verb}_${spot}_${life}`, kind, caveats: caveatsFromFlags(m[5]) };
  });
  for (const [i, age] of sv.a) evidence[i].age = age;
  const id = (i: number): string => evidence[i].id;
  const slots: Record<string, Slot> = {};
  LEVEL.forEach((spot, k) => {
    const [life, consumed, sinceConsumed, taste, consumedBy] = sv.s[k];
    const slot: Slot = { life, consumed: consumed === 1, sinceConsumed };
    if (taste >= 0) slot.taste = id(taste);
    if (consumedBy >= 0) slot.consumedBy = id(consumedBy);
    slots[spot] = slot;
  });
  const [ds, basis, reopenedBy, flags, history] = sv.d;
  return {
    ids: [...LEVEL],
    slots,
    evidence,
    glow: sv.g,
    heavy: sv.h,
    sinceContradiction: sv.r.map(id),
    decision: {
      state: DECISION_STATES[ds],
      basis: basis.map(id),
      reopenedBy: reopenedBy.map(id),
      caveats: caveatsFromFlags(flags),
      history: history.map(([c, b]) => ({ change: c === 1 ? ('committed' as const) : ('reopened' as const), because: b.map(id) })),
    },
  };
}

// Glowcap beat policy.

export type Kind = 'glowcap' | 'duskcap';

const KINDS: readonly Kind[] = ['glowcap', 'duskcap'];
const LEVEL: readonly string[] = ['cave', 'pool', 'ruin'];
const GLOW_SECONDS = 30;
const HEAVY_SECONDS = 20;

interface State {
  ids: string[];
  consumed: string[];
  tasted: Record<string, Kind>;
  absorptions: { id: string; kind: Kind }[];
  glow: number;
  heavy: number;
  decision: { state: 'none' | 'committed' | 'reopened'; basis: string[]; reopenedBy: string[] };
}

export interface GlowEvent {
  type: string;
  [key: string]: unknown;
}

function initialState(): State {
  return {
    ids: [...LEVEL],
    consumed: [],
    tasted: {},
    absorptions: [],
    glow: 0,
    heavy: 0,
    decision: { state: 'none', basis: [], reopenedBy: [] },
  };
}

function clone<T>(v: T): T {
  return JSON.parse(JSON.stringify(v)) as T;
}

function fail(msg: string): never {
  throw new Error(msg);
}

function beliefOf(s: State) {
  const supportedBy = s.absorptions.filter((a) => a.kind === 'glowcap').map((a) => `absorb_${a.id}`);
  const contradictedBy = s.absorptions.filter((a) => a.kind === 'duskcap').map((a) => `absorb_${a.id}`);
  const n = (k: number) => (k === 1 ? 'Based on one observation.' : `Based on ${k} observations.`);
  let state: 'none' | 'probably_safe' | 'probably_unsafe' | 'uncertain';
  let text = '';
  let note = '';
  if (supportedBy.length === 0 && contradictedBy.length === 0) state = 'none';
  else if (contradictedBy.length === 0) {
    state = 'probably_safe';
    text = 'Glowing mushrooms give you light.';
    note = n(supportedBy.length);
  } else if (supportedBy.length === 0) {
    state = 'probably_unsafe';
    text = 'Glowing mushrooms make you heavy.';
    note = n(contradictedBy.length);
  } else {
    state = 'uncertain';
    text = 'Not every glowing mushroom is safe. Taste before absorbing.';
  }
  return { state, text, note, supportedBy, contradictedBy };
}

function mushroomView(s: State, id: string, belief: ReturnType<typeof beliefOf>) {
  if (s.consumed.includes(id)) return { present: false, label: '', canAbsorb: false, canTaste: false, because: [] as string[] };
  const t = s.tasted[id];
  if (t === 'glowcap') return { present: true, label: 'Glowcap', canAbsorb: true, canTaste: false, because: [`taste_${id}`] };
  if (t === 'duskcap') return { present: true, label: 'Duskcap — avoid', canAbsorb: false, canTaste: false, because: [`taste_${id}`] };
  switch (belief.state) {
    case 'none':
      return { present: true, label: 'Glowing mushroom', canAbsorb: true, canTaste: true, because: [] as string[] };
    case 'probably_safe':
      return { present: true, label: 'Probably a glowcap', canAbsorb: true, canTaste: true, because: [...belief.supportedBy] };
    case 'probably_unsafe':
      return { present: true, label: 'Probably a duskcap', canAbsorb: true, canTaste: true, because: [...belief.contradictedBy] };
    default:
      return {
        present: true,
        label: 'Could be a duskcap — taste first',
        canAbsorb: true,
        canTaste: true,
        because: [...belief.supportedBy, ...belief.contradictedBy],
      };
  }
}

function render(s: State) {
  const belief = beliefOf(s);
  const mushrooms: Record<string, ReturnType<typeof mushroomView>> = {};
  for (const id of s.ids) mushrooms[id] = mushroomView(s, id, belief);
  return {
    slime: { glowing: s.glow > 0, heavy: s.heavy > 0 },
    mushrooms,
    belief,
    decision: clone(s.decision),
  };
}

function parseKind(v: unknown): Kind {
  if (typeof v !== 'string' || !(KINDS as readonly string[]).includes(v)) fail(`unknown kind ${String(v)}`);
  return v as Kind;
}

function parseId(s: State, v: unknown): string {
  if (typeof v !== 'string' || !s.ids.includes(v)) fail(`unknown id ${String(v)}`);
  return v;
}

function apply(s: State, e: GlowEvent): void {
  switch (e.type) {
    case 'absorb': {
      const id = parseId(s, e.id);
      const kind = parseKind(e.kind);
      if (s.consumed.includes(id)) fail(`${id} already consumed`);
      const view = mushroomView(s, id, beliefOf(s));
      if (!view.canAbsorb) fail(`${id} may not be absorbed`);
      const tasted = s.tasted[id];
      if (tasted !== undefined && tasted !== kind) fail(`${id} kind contradicts taste`);
      const before = beliefOf(s).state;
      s.consumed.push(id);
      s.absorptions.push({ id, kind });
      if (kind === 'glowcap') s.glow = GLOW_SECONDS;
      else s.heavy = HEAVY_SECONDS;
      const after = beliefOf(s);
      if (s.decision.state === 'none' && after.state === 'probably_safe' && before !== 'probably_safe') {
        s.decision = { state: 'committed', basis: [...after.supportedBy], reopenedBy: [] };
      } else if (s.decision.state !== 'none' && kind === 'duskcap') {
        s.decision.state = 'reopened';
        s.decision.reopenedBy.push(`absorb_${id}`);
      }
      return;
    }
    case 'taste': {
      const id = parseId(s, e.id);
      const kind = parseKind(e.kind);
      if (s.consumed.includes(id)) fail(`${id} already consumed`);
      if (s.tasted[id] !== undefined) fail(`${id} already tasted`);
      s.tasted[id] = kind;
      return;
    }
    case 'tick': {
      const dt = e.dt;
      if (typeof dt !== 'number' || !Number.isFinite(dt) || dt < 0 || dt > 0.1) fail(`dt out of range`);
      s.glow = Math.max(0, s.glow - dt);
      s.heavy = Math.max(0, s.heavy - dt);
      return;
    }
    default:
      fail(`unknown event type ${String(e.type)}`);
  }
}

export function createPolicy(saved?: unknown) {
  let state: State = saved === undefined ? initialState() : clone(saved as State);
  return {
    dispatch(event: GlowEvent): void {
      const next = clone(state);
      apply(next, event);
      state = next;
    },
    view() {
      return render(state);
    },
    save(): unknown {
      return clone(state);
    },
  };
}

// Glowcap beat policy.

export type Kind = 'glowcap' | 'duskcap';

const KINDS: readonly Kind[] = ['glowcap', 'duskcap'];
const LEVEL: readonly string[] = ['cave', 'pool', 'ruin', 'grove'];
const GLOW_SECONDS = 30;
const HEAVY_SECONDS = 20;
const HEAVY_MAX_SECONDS = 30;
const TASTE_FADE_SECONDS = 60;
const REGROW_SECONDS = 45;
/** CR10: declared capacity — lives per mushroom (the first plus 63 regrowths). */
export const LIVES_PER_MUSHROOM = 64;

interface Evidence {
  id: string; // absorb_<id>[_<life>], taste_<id>[_<life>] or witness_<id>[_<life>]
  kind: Kind;
  caveats: string[];
  age?: number; // tastes only: seconds of ticks since the taste
}

// One spot in the level; each life is a new mushroom in that spot.
interface Slot {
  life: number; // 1-based
  consumed: boolean;
  sinceConsumed: number; // seconds of ticks since consumed (CR10)
  taste?: string; // evidence id of this life's taste
}

interface State {
  ids: string[];
  slots: Record<string, Slot>;
  // Every observation in order: absorptions and tastes alike.
  evidence: Evidence[];
  glow: number;
  heavy: number;
  // CR7: glowcap observations since the most recent contradiction.
  sinceContradiction: string[];
  // caveats are frozen at commit time (CR5).
  decision: { state: 'none' | 'committed' | 'reopened'; basis: string[]; reopenedBy: string[]; caveats: string[]; history: { change: 'committed' | 'reopened'; because: string[] }[] };
}

export interface GlowEvent {
  type: string;
  [key: string]: unknown;
}

function initialState(): State {
  return {
    ids: [...LEVEL],
    slots: Object.fromEntries(LEVEL.map((id) => [id, { life: 1, consumed: false, sinceConsumed: 0 }])),
    evidence: [],
    glow: 0,
    heavy: 0,
    sinceContradiction: [],
    decision: { state: 'none', basis: [], reopenedBy: [], caveats: [], history: [] },
  };
}

function clone<T>(v: T): T {
  return JSON.parse(JSON.stringify(v)) as T;
}

function fail(msg: string): never {
  throw new Error(msg);
}

function evidenceId(s: State, verb: string, id: string): string {
  const life = s.slots[id].life;
  return life === 1 ? `${verb}_${id}` : `${verb}_${id}_${life}`;
}

function tastedKind(s: State, id: string): Kind | undefined {
  const t = s.slots[id].taste;
  return t === undefined ? undefined : s.evidence.find((e) => e.id === t)?.kind;
}

function consume(s: State, id: string): void {
  s.slots[id].consumed = true;
  s.slots[id].sinceConsumed = 0;
}

function caveatsOf(s: State, ids: readonly string[]): string[] {
  const out: string[] = [];
  for (const e of s.evidence) {
    if (!ids.includes(e.id)) continue;
    for (const c of e.caveats) if (!out.includes(c)) out.push(c);
  }
  return out;
}

function beliefOf(s: State) {
  const supportedBy = s.evidence.filter((a) => a.kind === 'glowcap').map((a) => a.id);
  const contradictedBy = s.evidence.filter((a) => a.kind === 'duskcap').map((a) => a.id);
  const n = (k: number) => (k === 1 ? 'Based on one observation.' : `Based on ${k} observations.`);
  let state: 'none' | 'probably_safe' | 'probably_unsafe' | 'uncertain';
  let text = '';
  let note = '';
  if (supportedBy.length === 0 && contradictedBy.length === 0) state = 'none';
  else if (contradictedBy.length === 0) {
    state = 'probably_safe';
    text = 'Glowing mushrooms give you light.';
    note = n(supportedBy.length);
  } else if (supportedBy.length === 0) {
    state = 'probably_unsafe';
    text = 'Glowing mushrooms make you heavy.';
    note = n(contradictedBy.length);
  } else {
    state = 'uncertain';
    text = 'Not every glowing mushroom is safe. Taste before absorbing.';
  }
  return { state, text, note, supportedBy, contradictedBy, caveats: caveatsOf(s, [...supportedBy, ...contradictedBy]) };
}

interface MushroomView {
  present: boolean;
  label: string;
  canAbsorb: boolean;
  canTaste: boolean;
  because: string[];
  caveats: string[];
}

function mushroomRow(s: State, id: string, belief: ReturnType<typeof beliefOf>): Omit<MushroomView, 'caveats'> {
  const slot = s.slots[id];
  if (slot.consumed) return { present: false, label: '', canAbsorb: false, canTaste: false, because: [] };
  const t = tastedKind(s, id);
  if (t !== undefined && slot.taste !== undefined) {
    const tasteId = slot.taste;
    const cav = caveatsOf(s, [tasteId]);
    const qualifier = cav.includes('taste_faded') ? ' (taste has faded)' : cav.includes('tasted_in_dark') ? ' (tasted in the dark)' : '';
    if (t === 'glowcap')
      return { present: true, label: qualifier ? `Probably a glowcap${qualifier}` : 'Glowcap', canAbsorb: true, canTaste: false, because: [tasteId] };
    return { present: true, label: qualifier ? `Probably a duskcap${qualifier}` : 'Duskcap — avoid', canAbsorb: false, canTaste: false, because: [tasteId] };
  }
  if (belief.contradictedBy.length >= 2)
    return { present: true, label: 'Too risky — taste first', canAbsorb: false, canTaste: true, because: [...belief.contradictedBy] };
  switch (belief.state) {
    case 'none':
      return { present: true, label: 'Glowing mushroom', canAbsorb: true, canTaste: true, because: [] };
    case 'probably_safe':
      return { present: true, label: 'Probably a glowcap', canAbsorb: true, canTaste: true, because: [...belief.supportedBy] };
    case 'probably_unsafe':
      return { present: true, label: 'Probably a duskcap', canAbsorb: true, canTaste: true, because: [...belief.contradictedBy] };
    default:
      return {
        present: true,
        label: 'Could be a duskcap — taste first',
        canAbsorb: true,
        canTaste: true,
        because: [...belief.contradictedBy], // CR4: cite the counterexample only
      };
  }
}

function mushroomView(s: State, id: string, belief: ReturnType<typeof beliefOf>): MushroomView {
  const row = mushroomRow(s, id, belief);
  return { ...row, caveats: caveatsOf(s, row.because) };
}

function render(s: State) {
  const belief = beliefOf(s);
  const mushrooms: Record<string, MushroomView> = {};
  for (const id of s.ids) mushrooms[id] = mushroomView(s, id, belief);
  return {
    slime: { glowing: s.glow > 0, heavy: s.heavy > 0, heavySeconds: s.heavy > 0 ? Math.ceil(s.heavy) : 0 },
    mushrooms,
    belief,
    decision: clone(s.decision),
  };
}

function parseKind(v: unknown): Kind {
  if (typeof v !== 'string' || !(KINDS as readonly string[]).includes(v)) fail(`unknown kind ${String(v)}`);
  return v as Kind;
}

function parseId(s: State, v: unknown): string {
  if (typeof v !== 'string' || !s.ids.includes(v)) fail(`unknown id ${String(v)}`);
  return v;
}

// Adds one observation and updates the trust decision.
function record(s: State, ev: Evidence): void {
  const before = beliefOf(s).state;
  s.evidence.push(ev);
  const after = beliefOf(s);
  if (ev.kind === 'duskcap') s.sinceContradiction = [];
  else s.sinceContradiction.push(ev.id);
  if (s.decision.state === 'reopened' && s.sinceContradiction.length >= 2) {
    const basis = s.sinceContradiction.slice(0, 2);
    s.decision = {
      state: 'committed',
      basis,
      reopenedBy: [],
      caveats: caveatsOf(s, basis),
      history: [...s.decision.history, { change: 'committed', because: [...basis] }],
    };
  } else if (s.decision.state === 'none' && after.state === 'probably_safe' && before !== 'probably_safe') {
    s.decision = {
      state: 'committed',
      basis: [...after.supportedBy],
      reopenedBy: [],
      caveats: after.caveats,
      history: [...s.decision.history, { change: 'committed', because: [...after.supportedBy] }],
    };
  } else if (s.decision.state !== 'none' && ev.kind === 'duskcap') {
    s.decision.state = 'reopened';
    s.decision.reopenedBy.push(ev.id);
    s.decision.history.push({ change: 'reopened', because: [ev.id] });
  }
}

function apply(s: State, e: GlowEvent): void {
  switch (e.type) {
    case 'absorb': {
      const id = parseId(s, e.id);
      const kind = parseKind(e.kind);
      if (s.slots[id].consumed) fail(`${id} already consumed`);
      const view = mushroomRow(s, id, beliefOf(s));
      if (!view.canAbsorb) fail(`${id} may not be absorbed`);
      const tasted = tastedKind(s, id);
      if (tasted !== undefined && tasted !== kind) fail(`${id} kind contradicts taste`);
      record(s, { id: evidenceId(s, 'absorb', id), kind, caveats: [] });
      consume(s, id);
      if (kind === 'glowcap') s.glow = GLOW_SECONDS;
      else s.heavy = s.heavy > 0 ? Math.min(HEAVY_MAX_SECONDS, s.heavy + HEAVY_SECONDS) : HEAVY_SECONDS;
      return;
    }
    case 'witness': {
      // CR9: another creature eats it; consumed, secondhand evidence, no timers.
      const id = parseId(s, e.id);
      const kind = parseKind(e.kind);
      if (s.slots[id].consumed) fail(`${id} already consumed`);
      const tasted = tastedKind(s, id);
      if (tasted !== undefined && tasted !== kind) fail(`${id} kind contradicts taste`);
      record(s, { id: evidenceId(s, 'witness', id), kind, caveats: ['secondhand'] });
      consume(s, id);
      return;
    }
    case 'taste': {
      const id = parseId(s, e.id);
      const kind = parseKind(e.kind);
      if (s.slots[id].consumed) fail(`${id} already consumed`);
      if (s.slots[id].taste !== undefined) fail(`${id} already tasted`);
      const evId = evidenceId(s, 'taste', id);
      s.slots[id].taste = evId;
      record(s, { id: evId, kind, caveats: s.glow > 0 ? [] : ['tasted_in_dark'], age: 0 });
      return;
    }
    case 'tick': {
      const dt = e.dt;
      if (typeof dt !== 'number' || !Number.isFinite(dt) || dt < 0 || dt > 0.1) fail(`dt out of range`);
      s.glow = Math.max(0, s.glow - dt);
      s.heavy = Math.max(0, s.heavy - dt);
      for (const ev of s.evidence) {
        if (ev.age === undefined) continue;
        ev.age += dt;
        if (ev.age >= TASTE_FADE_SECONDS && !ev.caveats.includes('taste_faded')) ev.caveats.push('taste_faded');
      }
      for (const id of s.ids) {
        const slot = s.slots[id];
        if (!slot.consumed || slot.life >= LIVES_PER_MUSHROOM) continue;
        slot.sinceConsumed += dt;
        if (slot.sinceConsumed >= REGROW_SECONDS) s.slots[id] = { life: slot.life + 1, consumed: false, sinceConsumed: 0 };
      }
      return;
    }
    default:
      fail(`unknown event type ${String(e.type)}`);
  }
}

export function createPolicy(saved?: unknown) {
  let state: State = saved === undefined ? initialState() : clone(saved as State);
  return {
    dispatch(event: GlowEvent): void {
      const next = clone(state);
      apply(next, event);
      state = next;
    },
    view() {
      return render(state);
    },
    save(): unknown {
      return clone(state);
    },
  };
}

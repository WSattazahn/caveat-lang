// Host glue for impl/glowcap.cav. It translates host events into the
// program's events and projects the program's view into the required shape.
// Every rule, label, decision and citation comes from the program: labels and
// flags from its bindings, `because` lists from its binding explanations, the
// trust decision's basis, its caveats and reopenings from its decision journal.
import { readFile } from 'node:fs/promises';
import { loadRuntimeFromDirectory } from 'caveat-lang/node';

const source = await readFile(new URL('./glowcap.cav', import.meta.url), 'utf8');
const runtime = await loadRuntimeFromDirectory();

// The mushrooms are the program's `mushroom` entities, read from the
// signature of its absorb event.
const mushrooms = (() => {
  const probe = runtime.open(source);
  const absorb = probe.snapshot().events.find((e) => e.name === 'absorb');
  probe.close();
  return absorb.parameters.find((p) => p.name === 'target').domain.entity.members;
})();

function translate(event) {
  const { type, ...payload } = event ?? {};
  if (type === 'absorb' || type === 'taste') {
    const { id, kind, ...rest } = payload;
    if (Object.keys(rest).length) throw new Error(`unexpected fields for ${type}`);
    return [type, { target: id, sort: kind }];
  }
  if (type === 'tick') return ['tick', payload];
  throw new Error(`unknown event type ${type}`);
}

const explained = (view, target, property, part) => [...(view.binding_explanations?.[target]?.[property]?.[part] ?? [])];
const cited = (view, target, property) => explained(view, target, property, 'evidence');
const caveatsOf = (view, target, property) => explained(view, target, property, 'caveats');

function project(view) {
  const b = view.bindings;
  const journal = view.decision_journal.filter((entry) => entry.decision === 'trust');
  let current = -1;
  journal.forEach((entry, i) => { if (entry.change === 'committed') current = i; });
  const basis = current < 0 ? [] : [...journal[current].because];
  const basisCaveats = current < 0 ? [] : [...journal[current].caveats];
  const reopenedBy = current < 0 ? [] : journal.slice(current + 1)
    .filter((entry) => entry.change === 'reopened').flatMap((entry) => entry.because);
  return {
    slime: { glowing: b.slime.glowing, heavy: b.slime.heavy },
    mushrooms: Object.fromEntries(mushrooms.map((m) => [m, {
      present: b[m].present,
      label: b[m].label,
      canAbsorb: b[m].can_absorb,
      canTaste: b[m].can_taste,
      because: cited(view, m, 'label'),
      caveats: caveatsOf(view, m, 'label'),
    }])),
    belief: {
      state: b.belief.state,
      text: b.belief.text,
      note: b.belief.note,
      supportedBy: cited(view, 'belief', 'supported'),
      contradictedBy: cited(view, 'belief', 'contradicted'),
      caveats: caveatsOf(view, 'belief', 'cited'),
    },
    decision: { state: b.decision.state, basis, reopenedBy, caveats: basisCaveats },
  };
}

export function createPolicy(saved) {
  const session = saved === undefined ? runtime.open(source) : runtime.restore(source, saved);
  return {
    dispatch(event) {
      const [name, payload] = translate(event);
      const outcome = session.dispatchView(name, payload);
      if (outcome.outcome !== 'accepted') {
        throw new Error(`${name} refused (${outcome.origin}/${outcome.code}): ${outcome.message}`);
      }
    },
    view() {
      return project(session.view());
    },
    save() {
      return session.save();
    },
  };
}

// Glowcap beat policy.
// State is plain JSON data; every dispatch works on a deep copy and only
// replaces the live state if the event is accepted (atomic rollback).

export type Kind = 'glowcap' | 'duskcap';

const KINDS: readonly string[] = ['glowcap', 'duskcap'];
const LEVEL: readonly string[] = ['cave', 'pool', 'ruin'];
const GLOW_SECONDS = 30;
const HEAVY_SECONDS = 20;
const MAX_DT = 0.1;

interface MushroomState {
  consumed: boolean;
  tasted: Kind | null;
}

interface Observation {
  evidence: string; // absorb_<id>
  kind: Kind;
}

interface State {
  glow: number;
  heavy: number;
  mushrooms: Record<string, MushroomState>;
  absorptions: Observation[]; // in order
  decision: { state: 'none' | 'committed' | 'reopened'; basis: string[]; reopenedBy: string[] };
}

export type BeliefState = 'none' | 'probably_safe' | 'probably_unsafe' | 'uncertain';

export interface MushroomView {
  present: boolean;
  label: string;
  canAbsorb: boolean;
  canTaste: boolean;
  because: string[];
}

export interface View {
  slime: { glowing: boolean; heavy: boolean };
  mushrooms: Record<string, MushroomView>;
  belief: { state: BeliefState; text: string; note: string; supportedBy: string[]; contradictedBy: string[] };
  decision: { state: 'none' | 'committed' | 'reopened'; basis: string[]; reopenedBy: string[] };
}

export interface Policy {
  dispatch(event: unknown): void;
  view(): View;
  save(): unknown;
}

function initialState(): State {
  const mushrooms: Record<string, MushroomState> = {};
  for (const id of LEVEL) mushrooms[id] = { consumed: false, tasted: null };
  return {
    glow: 0,
    heavy: 0,
    mushrooms,
    absorptions: [],
    decision: { state: 'none', basis: [], reopenedBy: [] },
  };
}

function clone<T>(v: T): T {
  return JSON.parse(JSON.stringify(v)) as T;
}

function fail(msg: string): never {
  throw new Error(msg);
}

function belief(s: State): View['belief'] {
  const supportedBy = s.absorptions.filter((o) => o.kind === 'glowcap').map((o) => o.evidence);
  const contradictedBy = s.absorptions.filter((o) => o.kind === 'duskcap').map((o) => o.evidence);
  const note = (n: number) => (n === 1 ? 'Based on one observation.' : `Based on ${n} observations.`);
  if (supportedBy.length && contradictedBy.length) {
    return {
      state: 'uncertain',
      text: 'Not every glowing mushroom is safe. Taste before absorbing.',
      note: '',
      supportedBy,
      contradictedBy,
    };
  }
  if (supportedBy.length) {
    return { state: 'probably_safe', text: 'Glowing mushrooms give you light.', note: note(supportedBy.length), supportedBy, contradictedBy };
  }
  if (contradictedBy.length) {
    return { state: 'probably_unsafe', text: 'Glowing mushrooms make you heavy.', note: note(contradictedBy.length), supportedBy, contradictedBy };
  }
  return { state: 'none', text: '', note: '', supportedBy, contradictedBy };
}

function mushroomView(s: State, id: string, b: View['belief']): MushroomView {
  const m = s.mushrooms[id]!;
  if (m.consumed) return { present: false, label: '', canAbsorb: false, canTaste: false, because: [] };
  if (m.tasted === 'glowcap') return { present: true, label: 'Glowcap', canAbsorb: true, canTaste: false, because: [`taste_${id}`] };
  if (m.tasted === 'duskcap') return { present: true, label: 'Duskcap — avoid', canAbsorb: false, canTaste: false, because: [`taste_${id}`] };
  switch (b.state) {
    case 'none':
      return { present: true, label: 'Glowing mushroom', canAbsorb: true, canTaste: true, because: [] };
    case 'probably_safe':
      return { present: true, label: 'Probably a glowcap', canAbsorb: true, canTaste: true, because: [...b.supportedBy] };
    case 'probably_unsafe':
      return { present: true, label: 'Probably a duskcap', canAbsorb: true, canTaste: true, because: [...b.contradictedBy] };
    case 'uncertain':
      return {
        present: true,
        label: 'Could be a duskcap — taste first',
        canAbsorb: true,
        canTaste: true,
        because: [...b.supportedBy, ...b.contradictedBy],
      };
  }
}

function render(s: State): View {
  const b = belief(s);
  const mushrooms: Record<string, MushroomView> = {};
  for (const id of Object.keys(s.mushrooms)) mushrooms[id] = mushroomView(s, id, b);
  return {
    slime: { glowing: s.glow > 0, heavy: s.heavy > 0 },
    mushrooms,
    belief: b,
    decision: clone(s.decision),
  };
}

function asRecord(event: unknown): Record<string, unknown> {
  if (typeof event !== 'object' || event === null) fail('event must be an object');
  return event as Record<string, unknown>;
}

function target(s: State, e: Record<string, unknown>): { id: string; kind: Kind; m: MushroomState } {
  const id = e['id'];
  const kind = e['kind'];
  if (typeof id !== 'string' || !Object.prototype.hasOwnProperty.call(s.mushrooms, id)) fail(`unknown mushroom: ${String(id)}`);
  if (typeof kind !== 'string' || !KINDS.includes(kind)) fail(`unknown kind: ${String(kind)}`);
  const m = s.mushrooms[id]!;
  if (m.consumed) fail(`mushroom consumed: ${id}`);
  return { id, kind: kind as Kind, m };
}

function apply(s: State, event: unknown): void {
  const e = asRecord(event);
  switch (e['type']) {
    case 'absorb': {
      const { id, kind, m } = target(s, e);
      const before = render(s);
      if (!before.mushrooms[id]!.canAbsorb) fail(`cannot absorb ${id}`);
      if (m.tasted !== null && m.tasted !== kind) fail(`kind contradicts taste of ${id}`);
      m.consumed = true;
      const evidence = `absorb_${id}`;
      s.absorptions.push({ evidence, kind });
      if (kind === 'glowcap') s.glow = GLOW_SECONDS;
      else s.heavy = HEAVY_SECONDS;
      // Decision update.
      const d = s.decision;
      if (d.state === 'none') {
        const b = belief(s);
        if (b.state === 'probably_safe') {
          d.state = 'committed';
          d.basis = [...b.supportedBy];
        }
      } else if (kind === 'duskcap') {
        d.state = 'reopened';
        d.reopenedBy.push(evidence);
      }
      return;
    }
    case 'taste': {
      const { id, kind, m } = target(s, e);
      if (m.tasted !== null) fail(`already tasted: ${id}`);
      m.tasted = kind;
      return;
    }
    case 'tick': {
      const dt = e['dt'];
      if (typeof dt !== 'number' || !Number.isFinite(dt) || dt < 0 || dt > MAX_DT) fail(`dt out of range: ${String(dt)}`);
      s.glow = Math.max(0, s.glow - dt);
      s.heavy = Math.max(0, s.heavy - dt);
      return;
    }
    default:
      fail(`unknown event type: ${String(e['type'])}`);
  }
}

export function createPolicy(saved?: unknown): Policy {
  let state: State = saved === undefined ? initialState() : clone(saved as State);
  return {
    dispatch(event: unknown): void {
      const next = clone(state);
      apply(next, event);
      state = next;
    },
    view(): View {
      return render(state);
    },
    save(): unknown {
      return clone(state);
    },
  };
}

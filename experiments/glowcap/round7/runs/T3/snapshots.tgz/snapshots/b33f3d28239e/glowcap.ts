// Glowcap beat policy.
// State is plain JSON data; every dispatch works on a deep copy and only
// replaces the live state if the event is accepted (atomic rollback).
// The view is always derived from state; only the decision is stored,
// because its basis is frozen at commit time.

export type Kind = 'glowcap' | 'duskcap';

const KINDS: readonly string[] = ['glowcap', 'duskcap'];
const LEVEL: readonly string[] = ['cave', 'pool', 'ruin', 'grove'];
const GLOW_SECONDS = 30;
const HEAVY_SECONDS = 20;
const HEAVY_MAX = 30; // CR8
const MAX_DT = 0.1;
const TOO_RISKY_AFTER = 2; // CR2
const DARK = 'tasted_in_dark'; // CR3
const FADED = 'taste_faded'; // CR5
const FADE_SECONDS = 60; // CR5
const RECOVER_AFTER = 2; // CR7
const SECONDHAND = 'secondhand'; // CR9
const REGROW_SECONDS = 45; // CR10
/** CR10: declared capacity of lives per mushroom (the request requires at least 64). */
export const MAX_LIVES = 1024;

interface MushroomState {
  consumed: boolean;
  tasted: Kind | null; // for the current life
  life: number; // CR10: 1-based life number
  sinceConsumed: number; // CR10: seconds of ticks since consumed (0 while present)
  consumedBy: string | null; // CR11: evidence that consumed the current life
}

/** CR10: evidence id for a mushroom's current life. */
function evidenceId(verb: 'absorb' | 'taste' | 'witness', id: string, m: MushroomState): string {
  return m.life === 1 ? `${verb}_${id}` : `${verb}_${id}_${m.life}`;
}

function consume(m: MushroomState, by: string): void {
  m.consumed = true;
  m.sinceConsumed = 0;
  m.consumedBy = by;
}

// One piece of evidence about glowing mushrooms in general (absorptions, tastes (CR3), witnesses (CR9)).
interface Evidence {
  id: string; // absorb_<id> / taste_<id> / witness_<id>
  kind: Kind;
  caveats: string[];
  age?: number; // CR5: seconds of ticks since a taste (tastes only)
}

type DecisionState = 'none' | 'committed' | 'reopened';

export interface HistoryEntry {
  change: 'committed' | 'reopened';
  because: string[];
}

interface State {
  glow: number;
  heavy: number;
  mushrooms: Record<string, MushroomState>;
  evidence: Evidence[]; // in order of arrival
  decision: { state: DecisionState; basis: string[]; reopenedBy: string[]; caveats: string[]; history: HistoryEntry[] }; // caveats frozen at commit (CR5)
}

export type BeliefState = 'none' | 'probably_safe' | 'probably_unsafe' | 'uncertain';

export interface MushroomView {
  present: boolean;
  label: string;
  canAbsorb: boolean;
  canTaste: boolean;
  because: string[];
  caveats: string[];
  why: { absorb: WhyNot; taste: WhyNot }; // CR11
}

export interface WhyNot {
  reason: string;
  because: string[];
  caveats: string[];
}

export interface BeliefView {
  state: BeliefState;
  text: string;
  note: string;
  supportedBy: string[];
  contradictedBy: string[];
  caveats: string[];
}

export interface DecisionView {
  state: DecisionState;
  basis: string[];
  reopenedBy: string[];
  caveats: string[];
  history: HistoryEntry[]; // CR6, ordered
}

export interface View {
  slime: { glowing: boolean; heavy: boolean; heavySeconds: number };
  mushrooms: Record<string, MushroomView>;
  belief: BeliefView;
  decision: DecisionView;
}

export interface Policy {
  dispatch(event: unknown): void;
  view(): View;
  save(): unknown;
}

function initialState(): State {
  const mushrooms: Record<string, MushroomState> = {};
  for (const id of LEVEL) mushrooms[id] = { consumed: false, tasted: null, life: 1, sinceConsumed: 0, consumedBy: null };
  return {
    glow: 0,
    heavy: 0,
    mushrooms,
    evidence: [],
    decision: { state: 'none', basis: [], reopenedBy: [], caveats: [], history: [] },
  };
}

function clone<T>(v: T): T {
  return JSON.parse(JSON.stringify(v)) as T;
}

function fail(msg: string): never {
  throw new Error(msg);
}

/** Union of the caveats carried by the cited evidence. */
function caveatsOf(s: State, cited: readonly string[]): string[] {
  const out = new Set<string>();
  for (const e of s.evidence) if (cited.includes(e.id)) for (const c of e.caveats) out.add(c);
  return [...out];
}

function belief(s: State): BeliefView {
  const supportedBy = s.evidence.filter((e) => e.kind === 'glowcap').map((e) => e.id);
  const contradictedBy = s.evidence.filter((e) => e.kind === 'duskcap').map((e) => e.id);
  const caveats = caveatsOf(s, [...supportedBy, ...contradictedBy]);
  const note = (n: number) => (n === 1 ? 'Based on one observation.' : `Based on ${n} observations.`);
  if (supportedBy.length && contradictedBy.length) {
    return {
      state: 'uncertain',
      text: 'Not every glowing mushroom is safe. Taste before absorbing.',
      note: '',
      supportedBy,
      contradictedBy,
      caveats,
    };
  }
  if (supportedBy.length) {
    return { state: 'probably_safe', text: 'Glowing mushrooms give you light.', note: note(supportedBy.length), supportedBy, contradictedBy, caveats };
  }
  if (contradictedBy.length) {
    return { state: 'probably_unsafe', text: 'Glowing mushrooms make you heavy.', note: note(contradictedBy.length), supportedBy, contradictedBy, caveats };
  }
  return { state: 'none', text: '', note: '', supportedBy, contradictedBy, caveats };
}

/** CR11: why each action is unavailable ('' / [] when allowed). */
function whyNot(s: State, id: string, b: BeliefView): { absorb: WhyNot; taste: WhyNot } {
  const m = s.mushrooms[id]!;
  const w = (reason: string, because: string[]): WhyNot => ({ reason, because, caveats: caveatsOf(s, because) });
  const allowed = w('', []);
  if (m.consumed) {
    const by = m.consumedBy === null ? [] : [m.consumedBy];
    return { absorb: w('Already eaten', by), taste: w('Already eaten', [...by]) };
  }
  const taste = m.tasted !== null ? [evidenceId('taste', id, m)] : null;
  let absorb = allowed;
  if (m.tasted === 'duskcap') absorb = w('Known duskcap', [...taste!]);
  else if (m.tasted === null && b.contradictedBy.length >= TOO_RISKY_AFTER) absorb = w('Too risky untasted', [...b.contradictedBy]);
  return { absorb, taste: taste ? w('Already tasted', [...taste]) : w('', []) };
}

function mushroomView(s: State, id: string, b: BeliefView): MushroomView {
  const m = s.mushrooms[id]!;
  const why = whyNot(s, id, b);
  const mk = (present: boolean, label: string, canAbsorb: boolean, canTaste: boolean, because: string[]): MushroomView => ({
    present,
    label,
    canAbsorb,
    canTaste,
    because,
    caveats: caveatsOf(s, because),
    why,
  });
  if (m.consumed) return mk(false, '', false, false, []);
  if (m.tasted !== null) {
    const because = [evidenceId('taste', id, m)];
    const cav = caveatsOf(s, because);
    const qualifier = cav.includes(FADED) ? ' (taste has faded)' : cav.includes(DARK) ? ' (tasted in the dark)' : null;
    if (m.tasted === 'glowcap') return mk(true, qualifier ? `Probably a glowcap${qualifier}` : 'Glowcap', true, false, because);
    return mk(true, qualifier ? `Probably a duskcap${qualifier}` : 'Duskcap — avoid', false, false, because);
  }
  // CR2: twice bitten.
  if (b.contradictedBy.length >= TOO_RISKY_AFTER) return mk(true, 'Too risky — taste first', false, true, [...b.contradictedBy]);
  switch (b.state) {
    case 'none':
      return mk(true, 'Glowing mushroom', true, true, []);
    case 'probably_safe':
      return mk(true, 'Probably a glowcap', true, true, [...b.supportedBy]);
    case 'probably_unsafe':
      return mk(true, 'Probably a duskcap', true, true, [...b.contradictedBy]);
    case 'uncertain':
      return mk(true, 'Could be a duskcap — taste first', true, true, [...b.contradictedBy]); // CR4: cite the counterexample
  }
}

function render(s: State): View {
  const b = belief(s);
  const mushrooms: Record<string, MushroomView> = {};
  for (const id of Object.keys(s.mushrooms)) mushrooms[id] = mushroomView(s, id, b);
  const d = s.decision;
  return {
    slime: { glowing: s.glow > 0, heavy: s.heavy > 0, heavySeconds: s.heavy > 0 ? Math.ceil(s.heavy) : 0 },
    mushrooms,
    belief: b,
    decision: { state: d.state, basis: [...d.basis], reopenedBy: [...d.reopenedBy], caveats: [...d.caveats], history: clone(d.history) },
  };
}

function asRecord(event: unknown): Record<string, unknown> {
  if (typeof event !== 'object' || event === null) fail('event must be an object');
  return event as Record<string, unknown>;
}

function target(s: State, e: Record<string, unknown>): { id: string; kind: Kind; m: MushroomState } {
  const id = e['id'];
  const kind = e['kind'];
  if (typeof id !== 'string' || !Object.prototype.hasOwnProperty.call(s.mushrooms, id)) fail(`unknown mushroom: ${String(id)}`);
  if (typeof kind !== 'string' || !KINDS.includes(kind)) fail(`unknown kind: ${String(kind)}`);
  const m = s.mushrooms[id]!;
  if (m.consumed) fail(`mushroom consumed: ${id}`);
  return { id, kind: kind as Kind, m };
}

/** Record general evidence and update the trust decision. */
function observe(s: State, ev: Evidence): void {
  s.evidence.push(ev);
  const d = s.decision;
  const commit = (basis: string[]): void => {
    d.state = 'committed';
    d.basis = basis;
    d.reopenedBy = [];
    d.caveats = caveatsOf(s, basis);
    d.history.push({ change: 'committed', because: [...basis] });
  };
  if (d.state === 'none') {
    const b = belief(s);
    if (b.state === 'probably_safe') commit([...b.supportedBy]);
  } else if (d.state === 'reopened' && ev.kind === 'glowcap') {
    // CR7: the second glowcap observation since the most recent contradiction recommits.
    const since: string[] = [];
    for (let i = s.evidence.length - 1; i >= 0 && s.evidence[i]!.kind === 'glowcap'; i--) since.unshift(s.evidence[i]!.id);
    if (since.length === RECOVER_AFTER) commit(since);
  } else if (ev.kind === 'duskcap') {
    d.state = 'reopened';
    d.reopenedBy.push(ev.id);
    d.history.push({ change: 'reopened', because: [ev.id] });
  }
}

function apply(s: State, event: unknown): void {
  const e = asRecord(event);
  switch (e['type']) {
    case 'absorb': {
      const { id, kind, m } = target(s, e);
      if (!mushroomView(s, id, belief(s)).canAbsorb) fail(`cannot absorb ${id}`);
      if (m.tasted !== null && m.tasted !== kind) fail(`kind contradicts taste of ${id}`);
      const evId = evidenceId('absorb', id, m);
      consume(m, evId);
      if (kind === 'glowcap') s.glow = GLOW_SECONDS;
      else s.heavy = s.heavy > 0 ? Math.min(HEAVY_MAX, s.heavy + HEAVY_SECONDS) : HEAVY_SECONDS; // CR8: stacks
      observe(s, { id: evId, kind, caveats: [] });
      return;
    }
    case 'witness': {
      // CR9: another creature eats it; no effect on the slime's timers, no canAbsorb gate.
      const { id, kind, m } = target(s, e);
      if (m.tasted !== null && m.tasted !== kind) fail(`kind contradicts taste of ${id}`);
      const evId = evidenceId('witness', id, m);
      consume(m, evId);
      observe(s, { id: evId, kind, caveats: [SECONDHAND] });
      return;
    }
    case 'taste': {
      const { id, kind, m } = target(s, e);
      if (m.tasted !== null) fail(`already tasted: ${id}`);
      m.tasted = kind;
      observe(s, { id: evidenceId('taste', id, m), kind, caveats: s.glow > 0 ? [] : [DARK], age: 0 });
      return;
    }
    case 'tick': {
      const dt = e['dt'];
      if (typeof dt !== 'number' || !Number.isFinite(dt) || dt < 0 || dt > MAX_DT) fail(`dt out of range: ${String(dt)}`);
      s.glow = Math.max(0, s.glow - dt);
      s.heavy = Math.max(0, s.heavy - dt);
      for (const ev of s.evidence) {
        if (ev.age === undefined) continue;
        ev.age += dt;
        if (ev.age >= FADE_SECONDS) {
          if (!ev.caveats.includes(FADED)) ev.caveats.push(FADED);
          delete ev.age; // faded for good; stop the clock (keeps saves small)
        }
      }
      // CR10: regrowth, unless the mushroom has used its last life.
      for (const m of Object.values(s.mushrooms)) {
        if (!m.consumed || m.life >= MAX_LIVES) continue;
        m.sinceConsumed += dt;
        if (m.sinceConsumed >= REGROW_SECONDS) {
          m.life += 1;
          m.consumed = false;
          m.tasted = null;
          m.sinceConsumed = 0;
          m.consumedBy = null;
        }
      }
      return;
    }
    default:
      fail(`unknown event type: ${String(e['type'])}`);
  }
}

// ---------------------------------------------------------------------------
// CR12: compact save format.
// Evidence is stored as short strings, e.g. "t1.2dD@12.5" = taste of LEVEL[1]
// in life 2, duskcap, caveat tasted_in_dark, 12.5 s since tasting (only while
// unfaded). The decision refers to evidence by its index in the log.

const SAVE_VERSION = 1;
const VERBS: Record<string, 'absorb' | 'taste' | 'witness'> = { a: 'absorb', t: 'taste', w: 'witness' };
const CAVEAT_CODES: Record<string, string> = { D: DARK, F: FADED, S: SECONDHAND };
const EVIDENCE_RE = /^(absorb|taste|witness)_([a-z]+)(?:_(\d+))?$/;
const CODE_RE = /^([atw])(\d+)\.(\d+)([gd])([DFS]*)(?:@(.+))?$/;

interface SaveV1 {
  v: number;
  t: [number, number]; // glow, heavy
  m: [number, number, string, number, number][]; // per LEVEL: life, consumed, tasted (g/d/-), sinceConsumed, consumedBy index
  e: string[];
  d: { s: string; b: number[]; r: number[]; c: string; h: string };
}

function codeOf(map: Record<string, string>, value: string): string {
  for (const [k, v] of Object.entries(map)) if (v === value) return k;
  return fail(`cannot encode ${value}`);
}

function encode(s: State): SaveV1 {
  const index = new Map<string, number>();
  s.evidence.forEach((ev, i) => index.set(ev.id, i));
  const ref = (id: string): number => index.get(id) ?? fail(`unknown evidence ${id}`);
  const caveatCodes = (cs: string[]) => cs.map((c) => codeOf(CAVEAT_CODES, c)).join('');
  const e = s.evidence.map((ev) => {
    const [, verb, mid, life] = EVIDENCE_RE.exec(ev.id) ?? fail(`bad evidence id ${ev.id}`);
    const age = ev.age === undefined ? '' : `@${ev.age}`;
    return `${verb![0]}${LEVEL.indexOf(mid!)}.${life ?? 1}${ev.kind[0]}${caveatCodes(ev.caveats)}${age}`;
  });
  const m = LEVEL.map((id): [number, number, string, number, number] => {
    const x = s.mushrooms[id]!;
    return [x.life, x.consumed ? 1 : 0, x.tasted ? x.tasted[0]! : '-', x.sinceConsumed, x.consumedBy === null ? -1 : ref(x.consumedBy)];
  });
  const d = s.decision;
  const h = d.history.map((h) => `${h.change[0]}${h.because.map(ref).join(',')}`).join(';');
  return {
    v: SAVE_VERSION,
    t: [s.glow, s.heavy],
    m,
    e,
    d: { s: d.state[0]!, b: d.basis.map(ref), r: d.reopenedBy.map(ref), c: caveatCodes(d.caveats), h },
  };
}

function decode(saved: unknown): State {
  const x = saved as SaveV1;
  if (typeof x !== 'object' || x === null || x.v !== SAVE_VERSION) fail('unsupported save');
  const kindOf = (c: string): Kind => (c === 'g' ? 'glowcap' : c === 'd' ? 'duskcap' : fail(`bad kind ${c}`));
  const caveats = (codes: string) => [...codes].map((c) => CAVEAT_CODES[c] ?? fail(`bad caveat ${c}`));
  const evidence: Evidence[] = x.e.map((code) => {
    const [, v, mi, life, k, cs, age] = CODE_RE.exec(code) ?? fail(`bad evidence ${code}`);
    const mid = LEVEL[Number(mi)] ?? fail(`bad mushroom ${mi}`);
    const n = Number(life);
    const id = n === 1 ? `${VERBS[v!]}_${mid}` : `${VERBS[v!]}_${mid}_${n}`;
    const ev: Evidence = { id, kind: kindOf(k!), caveats: caveats(cs!) };
    if (age !== undefined) ev.age = Number(age);
    return ev;
  });
  const id = (i: number): string => evidence[i]?.id ?? fail(`bad evidence index ${i}`);
  const mushrooms: Record<string, MushroomState> = {};
  LEVEL.forEach((mid, i) => {
    const [life, consumed, tasted, sinceConsumed, by] = x.m[i] ?? fail(`missing mushroom ${mid}`);
    mushrooms[mid] = {
      life,
      consumed: consumed === 1,
      tasted: tasted === '-' ? null : kindOf(tasted),
      sinceConsumed,
      consumedBy: by < 0 ? null : id(by),
    };
  });
  const states: Record<string, DecisionState> = { n: 'none', c: 'committed', r: 'reopened' };
  const history: HistoryEntry[] = x.d.h === ''
    ? []
    : x.d.h.split(';').map((part) => ({
        change: part[0] === 'c' ? 'committed' : part[0] === 'r' ? 'reopened' : fail(`bad history ${part}`),
        because: part.slice(1).split(',').map((i) => id(Number(i))),
      }));
  return {
    glow: x.t[0],
    heavy: x.t[1],
    mushrooms,
    evidence,
    decision: {
      state: states[x.d.s] ?? fail(`bad decision ${x.d.s}`),
      basis: x.d.b.map(id),
      reopenedBy: x.d.r.map(id),
      caveats: caveats(x.d.c),
      history,
    },
  };
}

export function createPolicy(saved?: unknown): Policy {
  let state: State = saved === undefined ? initialState() : decode(clone(saved));
  return {
    dispatch(event: unknown): void {
      const next = clone(state);
      apply(next, event);
      state = next;
    },
    view(): View {
      return render(state);
    },
    save(): unknown {
      return encode(state);
    },
  };
}

// Glowcap beat policy.
// State is plain JSON data; every dispatch works on a deep copy and only
// replaces the live state if the event is accepted (atomic rollback).
// The view is always derived from state; only the decision is stored,
// because its basis is frozen at commit time.

export type Kind = 'glowcap' | 'duskcap';

const KINDS: readonly string[] = ['glowcap', 'duskcap'];
const LEVEL: readonly string[] = ['cave', 'pool', 'ruin', 'grove'];
const GLOW_SECONDS = 30;
const HEAVY_SECONDS = 20;
const MAX_DT = 0.1;
const TOO_RISKY_AFTER = 2; // CR2
const DARK = 'tasted_in_dark'; // CR3
const FADED = 'taste_faded'; // CR5
const FADE_SECONDS = 60; // CR5
const RECOVER_AFTER = 2; // CR7

interface MushroomState {
  consumed: boolean;
  tasted: Kind | null;
}

// One piece of evidence about glowing mushrooms in general (CR3: absorptions and tastes).
interface Evidence {
  id: string; // absorb_<id> / taste_<id>
  kind: Kind;
  caveats: string[];
  age?: number; // CR5: seconds of ticks since a taste (tastes only)
}

type DecisionState = 'none' | 'committed' | 'reopened';

export interface HistoryEntry {
  change: 'committed' | 'reopened';
  because: string[];
}

interface State {
  glow: number;
  heavy: number;
  mushrooms: Record<string, MushroomState>;
  evidence: Evidence[]; // in order of arrival
  decision: { state: DecisionState; basis: string[]; reopenedBy: string[]; caveats: string[]; history: HistoryEntry[] }; // caveats frozen at commit (CR5)
}

export type BeliefState = 'none' | 'probably_safe' | 'probably_unsafe' | 'uncertain';

export interface MushroomView {
  present: boolean;
  label: string;
  canAbsorb: boolean;
  canTaste: boolean;
  because: string[];
  caveats: string[];
}

export interface BeliefView {
  state: BeliefState;
  text: string;
  note: string;
  supportedBy: string[];
  contradictedBy: string[];
  caveats: string[];
}

export interface DecisionView {
  state: DecisionState;
  basis: string[];
  reopenedBy: string[];
  caveats: string[];
  history: HistoryEntry[]; // CR6, ordered
}

export interface View {
  slime: { glowing: boolean; heavy: boolean };
  mushrooms: Record<string, MushroomView>;
  belief: BeliefView;
  decision: DecisionView;
}

export interface Policy {
  dispatch(event: unknown): void;
  view(): View;
  save(): unknown;
}

function initialState(): State {
  const mushrooms: Record<string, MushroomState> = {};
  for (const id of LEVEL) mushrooms[id] = { consumed: false, tasted: null };
  return {
    glow: 0,
    heavy: 0,
    mushrooms,
    evidence: [],
    decision: { state: 'none', basis: [], reopenedBy: [], caveats: [], history: [] },
  };
}

function clone<T>(v: T): T {
  return JSON.parse(JSON.stringify(v)) as T;
}

function fail(msg: string): never {
  throw new Error(msg);
}

/** Union of the caveats carried by the cited evidence. */
function caveatsOf(s: State, cited: readonly string[]): string[] {
  const out = new Set<string>();
  for (const e of s.evidence) if (cited.includes(e.id)) for (const c of e.caveats) out.add(c);
  return [...out];
}

function belief(s: State): BeliefView {
  const supportedBy = s.evidence.filter((e) => e.kind === 'glowcap').map((e) => e.id);
  const contradictedBy = s.evidence.filter((e) => e.kind === 'duskcap').map((e) => e.id);
  const caveats = caveatsOf(s, [...supportedBy, ...contradictedBy]);
  const note = (n: number) => (n === 1 ? 'Based on one observation.' : `Based on ${n} observations.`);
  if (supportedBy.length && contradictedBy.length) {
    return {
      state: 'uncertain',
      text: 'Not every glowing mushroom is safe. Taste before absorbing.',
      note: '',
      supportedBy,
      contradictedBy,
      caveats,
    };
  }
  if (supportedBy.length) {
    return { state: 'probably_safe', text: 'Glowing mushrooms give you light.', note: note(supportedBy.length), supportedBy, contradictedBy, caveats };
  }
  if (contradictedBy.length) {
    return { state: 'probably_unsafe', text: 'Glowing mushrooms make you heavy.', note: note(contradictedBy.length), supportedBy, contradictedBy, caveats };
  }
  return { state: 'none', text: '', note: '', supportedBy, contradictedBy, caveats };
}

function mushroomView(s: State, id: string, b: BeliefView): MushroomView {
  const m = s.mushrooms[id]!;
  const mk = (present: boolean, label: string, canAbsorb: boolean, canTaste: boolean, because: string[]): MushroomView => ({
    present,
    label,
    canAbsorb,
    canTaste,
    because,
    caveats: caveatsOf(s, because),
  });
  if (m.consumed) return mk(false, '', false, false, []);
  if (m.tasted !== null) {
    const because = [`taste_${id}`];
    const cav = caveatsOf(s, because);
    const qualifier = cav.includes(FADED) ? ' (taste has faded)' : cav.includes(DARK) ? ' (tasted in the dark)' : null;
    if (m.tasted === 'glowcap') return mk(true, qualifier ? `Probably a glowcap${qualifier}` : 'Glowcap', true, false, because);
    return mk(true, qualifier ? `Probably a duskcap${qualifier}` : 'Duskcap — avoid', false, false, because);
  }
  // CR2: twice bitten.
  if (b.contradictedBy.length >= TOO_RISKY_AFTER) return mk(true, 'Too risky — taste first', false, true, [...b.contradictedBy]);
  switch (b.state) {
    case 'none':
      return mk(true, 'Glowing mushroom', true, true, []);
    case 'probably_safe':
      return mk(true, 'Probably a glowcap', true, true, [...b.supportedBy]);
    case 'probably_unsafe':
      return mk(true, 'Probably a duskcap', true, true, [...b.contradictedBy]);
    case 'uncertain':
      return mk(true, 'Could be a duskcap — taste first', true, true, [...b.contradictedBy]); // CR4: cite the counterexample
  }
}

function render(s: State): View {
  const b = belief(s);
  const mushrooms: Record<string, MushroomView> = {};
  for (const id of Object.keys(s.mushrooms)) mushrooms[id] = mushroomView(s, id, b);
  const d = s.decision;
  return {
    slime: { glowing: s.glow > 0, heavy: s.heavy > 0 },
    mushrooms,
    belief: b,
    decision: { state: d.state, basis: [...d.basis], reopenedBy: [...d.reopenedBy], caveats: [...d.caveats], history: clone(d.history) },
  };
}

function asRecord(event: unknown): Record<string, unknown> {
  if (typeof event !== 'object' || event === null) fail('event must be an object');
  return event as Record<string, unknown>;
}

function target(s: State, e: Record<string, unknown>): { id: string; kind: Kind; m: MushroomState } {
  const id = e['id'];
  const kind = e['kind'];
  if (typeof id !== 'string' || !Object.prototype.hasOwnProperty.call(s.mushrooms, id)) fail(`unknown mushroom: ${String(id)}`);
  if (typeof kind !== 'string' || !KINDS.includes(kind)) fail(`unknown kind: ${String(kind)}`);
  const m = s.mushrooms[id]!;
  if (m.consumed) fail(`mushroom consumed: ${id}`);
  return { id, kind: kind as Kind, m };
}

/** Record general evidence and update the trust decision. */
function observe(s: State, ev: Evidence): void {
  s.evidence.push(ev);
  const d = s.decision;
  const commit = (basis: string[]): void => {
    d.state = 'committed';
    d.basis = basis;
    d.reopenedBy = [];
    d.caveats = caveatsOf(s, basis);
    d.history.push({ change: 'committed', because: [...basis] });
  };
  if (d.state === 'none') {
    const b = belief(s);
    if (b.state === 'probably_safe') commit([...b.supportedBy]);
  } else if (d.state === 'reopened' && ev.kind === 'glowcap') {
    // CR7: the second glowcap observation since the most recent contradiction recommits.
    const since: string[] = [];
    for (let i = s.evidence.length - 1; i >= 0 && s.evidence[i]!.kind === 'glowcap'; i--) since.unshift(s.evidence[i]!.id);
    if (since.length === RECOVER_AFTER) commit(since);
  } else if (ev.kind === 'duskcap') {
    d.state = 'reopened';
    d.reopenedBy.push(ev.id);
    d.history.push({ change: 'reopened', because: [ev.id] });
  }
}

function apply(s: State, event: unknown): void {
  const e = asRecord(event);
  switch (e['type']) {
    case 'absorb': {
      const { id, kind, m } = target(s, e);
      if (!mushroomView(s, id, belief(s)).canAbsorb) fail(`cannot absorb ${id}`);
      if (m.tasted !== null && m.tasted !== kind) fail(`kind contradicts taste of ${id}`);
      m.consumed = true;
      if (kind === 'glowcap') s.glow = GLOW_SECONDS;
      else s.heavy = HEAVY_SECONDS;
      observe(s, { id: `absorb_${id}`, kind, caveats: [] });
      return;
    }
    case 'taste': {
      const { id, kind, m } = target(s, e);
      if (m.tasted !== null) fail(`already tasted: ${id}`);
      m.tasted = kind;
      observe(s, { id: `taste_${id}`, kind, caveats: s.glow > 0 ? [] : [DARK], age: 0 });
      return;
    }
    case 'tick': {
      const dt = e['dt'];
      if (typeof dt !== 'number' || !Number.isFinite(dt) || dt < 0 || dt > MAX_DT) fail(`dt out of range: ${String(dt)}`);
      s.glow = Math.max(0, s.glow - dt);
      s.heavy = Math.max(0, s.heavy - dt);
      for (const ev of s.evidence) {
        if (ev.age === undefined) continue;
        ev.age += dt;
        if (ev.age >= FADE_SECONDS && !ev.caveats.includes(FADED)) ev.caveats.push(FADED);
      }
      return;
    }
    default:
      fail(`unknown event type: ${String(e['type'])}`);
  }
}

export function createPolicy(saved?: unknown): Policy {
  let state: State = saved === undefined ? initialState() : clone(saved as State);
  return {
    dispatch(event: unknown): void {
      const next = clone(state);
      apply(next, event);
      state = next;
    },
    view(): View {
      return render(state);
    },
    save(): unknown {
      return clone(state);
    },
  };
}

// Host glue: loads impl/glowcap.cav, translates host events into the
// program's events, and projects the program's view into the required shape.
// Every game decision (what is allowed, what is shown, why) is in the source.
import { readFile } from 'node:fs/promises';
import { loadRuntimeFromDirectory } from 'caveat-lang/node';

const source = await readFile(new URL('./glowcap.cav', import.meta.url), 'utf8');
const runtime = await loadRuntimeFromDirectory();
// The mushrooms are the program's `mushroom` entities, as its absorb event declares them.
const mushrooms = (() => {
  const probe = runtime.open(source);
  try {
    const absorb = probe.snapshot().events.find((e) => e.name === 'absorb');
    return absorb.parameters.find((p) => p.name === 'target').domain.entity.members;
  } finally { probe.close(); }
})();

export const ready = Promise.resolve();

const translate = {
  absorb: (e) => ['absorb', { target: e.id, sort: e.kind }],
  witness: (e) => ['witness', { target: e.id, sort: e.kind }],
  taste: (e) => ['taste', { target: e.id, sort: e.kind }],
  tick: (e) => ['tick', { dt: e.dt }],
};

// The runtime names a renewed occurrence `absorb_cave@2`; the view calls that life `absorb_cave_2`.
const life = (evidence) => evidence.replace(/@(\d+)$/, '_$1');

function project(view) {
  const b = view.bindings;
  const explained = (target, property) => view.binding_explanations[target]?.[property] ?? { evidence: [], caveats: [] };
  const cites = (target, property) => explained(target, property).evidence.map(life);
  const caveatsOf = (...cited) => [...new Set(cited.flatMap(([t, p]) => explained(t, p).caveats))];
  const current = view.decision_series.trust?.current ?? null;
  const reopenedBy = view.decision_journal
    .filter((j) => j.commitment === current && j.change === 'reopened')
    .flatMap((j) => j.because.map(life));
  return {
    slime: { glowing: b.slime.glowing, heavy: b.slime.heavy, heavySeconds: b.slime.heavySeconds },
    mushrooms: Object.fromEntries(mushrooms.map((id) => [id, {
      present: b[id].present,
      label: b[id].label,
      canAbsorb: b[id].canAbsorb,
      canTaste: b[id].canTaste,
      because: cites(id, 'label'),
      caveats: caveatsOf([id, 'label']),
    }])),
    belief: {
      state: b.belief.state,
      text: b.belief.text,
      note: b.belief.note,
      supportedBy: cites('belief', 'supportedBy'),
      contradictedBy: cites('belief', 'contradictedBy'),
      caveats: caveatsOf(['belief', 'supportedBy'], ['belief', 'contradictedBy']),
    },
    decision: {
      state: b.decision.state,
      basis: current ? view.commitment_grounds[current].evidence.map(life) : [],
      reopenedBy,
      caveats: current ? [...view.commitment_grounds[current].caveats] : [],
      // The runtime's decision journal, in order.
      history: view.decision_journal.filter((j) => j.decision === 'trust')
        .map((j) => ({ change: j.change, because: j.because.map(life) })),
    },
  };
}

export function createPolicy(saved) {
  const session = saved === undefined ? runtime.open(source) : runtime.restore(source, saved);
  let view = session.view();
  return {
    dispatch(event) {
      const make = translate[event?.type];
      if (!make) throw new Error(`unknown event type ${JSON.stringify(event?.type)}`);
      const [name, payload] = make(event);
      const outcome = session.dispatchView(name, payload);
      if (outcome.outcome !== 'accepted') {
        throw new Error(`${name} rejected (${outcome.origin}/${outcome.code}): ${outcome.message}`);
      }
      view = outcome.view;
    },
    view: () => project(view),
    save: () => session.save(),
  };
}

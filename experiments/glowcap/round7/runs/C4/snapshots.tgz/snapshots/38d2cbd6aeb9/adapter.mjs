// Host glue: translates events into the Caveat program's events and its view
// into the required shape. Every game decision is made in glowcap.cav.
import { readFile } from 'node:fs/promises';
import { loadRuntimeFromDirectory } from 'caveat-lang/node';

const source = await readFile(new URL('./glowcap.cav', import.meta.url), 'utf8');
const runtime = await loadRuntimeFromDirectory();
const MUSHROOMS = (() => {
  const s = runtime.open(source);
  const ids = s.snapshot().world.entities.filter((e) => e.kind === 'mushroom').map((e) => e.id);
  s.close();
  return ids;
})();

function translate(event) {
  const { type, ...p } = event ?? {};
  if (type === 'absorb' || type === 'taste' || type === 'witness') {
    if (Object.keys(p).sort().join() !== 'id,kind') throw new Error(`bad ${type} payload`);
    return [type, { target: p.id, sort: p.kind }];
  }
  if (type === 'tick') {
    if (Object.keys(p).join() !== 'dt') throw new Error('bad tick payload');
    return ['tick', { dt: p.dt }];
  }
  throw new Error(`unknown event ${type}`);
}

const evidence = (expl, target, prop) => [...(expl[target]?.[prop]?.evidence ?? [])];
const caveats = (expl, target, prop) => [...(expl[target]?.[prop]?.caveats ?? [])];

function project(v) {
  const b = v.bindings, x = v.binding_explanations;
  const mushrooms = {};
  for (const id of MUSHROOMS) {
    mushrooms[id] = {
      present: b[id].present,
      label: b[id].label,
      canAbsorb: b[id].can_absorb,
      canTaste: b[id].can_taste,
      because: evidence(x, id, 'label'),
      caveats: caveats(x, id, 'label'),
    };
  }
  const series = v.decision_series.trust;
  const current = series?.current;
  const journal = v.decision_journal.filter((e) => e.decision === 'trust');
  const committed = journal.find((e) => e.commitment === current && e.change === 'committed');
  const grounds = current ? v.commitment_grounds[current] : undefined;
  return {
    slime: { glowing: b.slime.glowing, heavy: b.slime.heavy, heavySeconds: b.slime.heavy_seconds },
    mushrooms,
    belief: {
      state: b.belief.state,
      text: b.belief.text,
      note: b.belief.note,
      supportedBy: evidence(x, 'belief', 'supported'),
      contradictedBy: evidence(x, 'belief', 'contradicted'),
      caveats: caveats(x, 'belief', 'evidence'),
    },
    decision: {
      state: b.decision.state,
      basis: [...(committed?.because ?? grounds?.evidence ?? [])],
      caveats: [...(grounds?.caveats ?? [])],
      reopenedBy: journal
        .filter((e) => e.commitment === current && e.change === 'reopened')
        .flatMap((e) => e.because),
      history: journal.map((e) => ({ change: e.change, because: [...e.because] })),
    },
  };
}

export function createPolicy(saved) {
  const session = saved === undefined ? runtime.open(source) : runtime.restore(source, saved.caveat);
  let view = project(session.view());
  return {
    dispatch(event) {
      const [name, payload] = translate(event);
      const outcome = session.dispatchView(name, payload);
      if (outcome.outcome !== 'accepted') {
        throw new Error(`${name} rejected (${outcome.origin}/${outcome.code}): ${outcome.message}`);
      }
      view = project(outcome.view);
    },
    view: () => structuredClone(view),
    save: () => ({ caveat: session.save() }),
  };
}

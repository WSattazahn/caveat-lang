// Host glue: translates host events into the program's events and the
// program's view into the required view shape. The game's rules live in
// glowcap.cav; this file only renames and projects.
import { readFileSync } from 'node:fs';
import { loadRuntimeFromDirectory } from 'caveat-lang/node';

const source = readFileSync(new URL('./glowcap.cav', import.meta.url), 'utf8');
const runtime = await loadRuntimeFromDirectory();
export const ready = Promise.resolve();

// Mushroom ids, as the program declares them (static world).
const MUSHROOMS = runtime.open(source).snapshot().world.entities
  .filter((e) => e.kind === 'mushroom').map((e) => e.id);

function translate(event) {
  const { type, ...rest } = event ?? {};
  if (type === 'absorb' || type === 'taste') {
    if (Object.keys(rest).some((k) => k !== 'id' && k !== 'kind')) throw new Error(`unexpected field in ${type}`);
    return [type, { target: rest.id, sort: rest.kind }];
  }
  if (type === 'tick') return ['tick', rest];
  throw new Error(`unknown event type ${JSON.stringify(type)}`);
}

// What a displayed value cites (its explanation), as evidence or caveat names.
const cites = (v, target, prop, field = 'evidence') => [...(v.binding_explanations[target]?.[prop]?.[field] ?? [])];

function project(v) {
  const b = v.bindings;
  const mushrooms = {};
  for (const id of MUSHROOMS) {
    mushrooms[id] = {
      present: b[id].present,
      label: b[id].label,
      canAbsorb: b[id].can_absorb,
      canTaste: b[id].can_taste,
      because: cites(v, id, 'label'),
      caveats: cites(v, id, 'label', 'caveats'),
    };
  }
  const journal = v.decision_journal.filter((e) => e.decision === 'trust');
  const committed = journal.find((e) => e.change === 'committed');
  const grounds = committed ? v.commitment_grounds[committed.commitment] : { evidence: [], caveats: [] };
  return {
    slime: { glowing: b.slime.glowing, heavy: b.slime.heavy },
    mushrooms,
    belief: {
      state: b.belief.state,
      text: b.belief.text,
      note: b.belief.note,
      supportedBy: cites(v, 'belief', 'supported'),
      contradictedBy: cites(v, 'belief', 'contradicted'),
      caveats: cites(v, 'belief', 'observations', 'caveats'),
    },
    decision: {
      state: b.decision.state,
      basis: [...grounds.evidence],
      caveats: [...grounds.caveats],
      reopenedBy: journal.filter((e) => e.change === 'reopened').flatMap((e) => e.because),
    },
  };
}

export function createPolicy(saved) {
  const session = saved === undefined ? runtime.open(source) : runtime.restore(source, saved);
  let current = project(session.view());
  return {
    dispatch(event) {
      const [name, payload] = translate(event);
      const outcome = session.dispatchView(name, payload);
      if (outcome.outcome !== 'accepted') {
        throw new Error(`${name} rejected (${outcome.origin}/${outcome.code}): ${outcome.message}`);
      }
      current = project(outcome.view);
    },
    view() {
      return structuredClone(current);
    },
    save() {
      return session.save();
    },
  };
}

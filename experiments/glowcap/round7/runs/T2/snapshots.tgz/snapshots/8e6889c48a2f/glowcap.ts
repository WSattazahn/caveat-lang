// Glowcap beat policy.

type Kind = 'glowcap' | 'duskcap';

interface Mushroom {
  consumed: boolean;
  tasted: Kind | null;
}

interface State {
  glow: number;
  heavy: number;
  mushrooms: Record<string, Mushroom>;
  supportedBy: string[];
  contradictedBy: string[];
  decision: { state: 'none' | 'committed' | 'reopened'; basis: string[]; reopenedBy: string[] };
}

const LEVEL = ['cave', 'pool', 'ruin'];
const KINDS: readonly string[] = ['glowcap', 'duskcap'];

function initial(): State {
  const mushrooms: Record<string, Mushroom> = {};
  for (const id of LEVEL) mushrooms[id] = { consumed: false, tasted: null };
  return {
    glow: 0,
    heavy: 0,
    mushrooms,
    supportedBy: [],
    contradictedBy: [],
    decision: { state: 'none', basis: [], reopenedBy: [] },
  };
}

function beliefState(s: State): string {
  const sup = s.supportedBy.length > 0;
  const con = s.contradictedBy.length > 0;
  if (sup && con) return 'uncertain';
  if (sup) return 'probably_safe';
  if (con) return 'probably_unsafe';
  return 'none';
}

function note(n: number): string {
  return n === 1 ? 'Based on one observation.' : `Based on ${n} observations.`;
}

function canAbsorb(s: State, m: Mushroom): boolean {
  if (m.consumed) return false;
  if (m.tasted === 'duskcap') return false;
  return true;
}

function fail(msg: string): never {
  throw new Error(msg);
}

function lookup(s: State, ev: Record<string, unknown>): [string, Mushroom, Kind] {
  const id = ev.id;
  const kind = ev.kind;
  if (typeof id !== 'string' || !Object.hasOwn(s.mushrooms, id)) fail(`unknown mushroom ${String(id)}`);
  if (typeof kind !== 'string' || !KINDS.includes(kind)) fail(`unknown kind ${String(kind)}`);
  const m = s.mushrooms[id]!;
  if (m.consumed) fail(`mushroom ${id} consumed`);
  return [id, m, kind as Kind];
}

function apply(s: State, ev: Record<string, unknown>): void {
  switch (ev.type) {
    case 'absorb': {
      const [id, m, kind] = lookup(s, ev);
      if (!canAbsorb(s, m)) fail(`cannot absorb ${id}`);
      if (m.tasted !== null && m.tasted !== kind) fail(`kind contradicts taste of ${id}`);
      m.consumed = true;
      const evId = `absorb_${id}`;
      if (kind === 'glowcap') {
        s.glow = 30;
        s.supportedBy.push(evId);
        if (s.decision.state === 'none' && beliefState(s) === 'probably_safe') {
          s.decision.state = 'committed';
          s.decision.basis = [...s.supportedBy];
        }
      } else {
        s.heavy = 20;
        s.contradictedBy.push(evId);
        if (s.decision.state !== 'none') {
          s.decision.state = 'reopened';
          s.decision.reopenedBy.push(evId);
        }
      }
      return;
    }
    case 'taste': {
      const [id, m, kind] = lookup(s, ev);
      if (m.tasted !== null) fail(`mushroom ${id} already tasted`);
      m.tasted = kind;
      return;
    }
    case 'tick': {
      const dt = ev.dt;
      if (typeof dt !== 'number' || !Number.isFinite(dt) || dt < 0 || dt > 0.1) fail(`dt out of range`);
      s.glow = Math.max(0, s.glow - dt);
      s.heavy = Math.max(0, s.heavy - dt);
      return;
    }
    default:
      fail(`unknown event type ${String(ev.type)}`);
  }
}

function render(s: State) {
  const bs = beliefState(s);
  const mushrooms: Record<string, unknown> = {};
  for (const [id, m] of Object.entries(s.mushrooms)) {
    let v;
    if (m.consumed) v = { present: false, label: '', canAbsorb: false, canTaste: false, because: [] };
    else if (m.tasted === 'glowcap')
      v = { present: true, label: 'Glowcap', canAbsorb: true, canTaste: false, because: [`taste_${id}`] };
    else if (m.tasted === 'duskcap')
      v = { present: true, label: 'Duskcap — avoid', canAbsorb: false, canTaste: false, because: [`taste_${id}`] };
    else {
      const label =
        bs === 'none' ? 'Glowing mushroom'
        : bs === 'probably_safe' ? 'Probably a glowcap'
        : bs === 'probably_unsafe' ? 'Probably a duskcap'
        : 'Could be a duskcap — taste first';
      const because =
        bs === 'probably_safe' ? [...s.supportedBy]
        : bs === 'probably_unsafe' ? [...s.contradictedBy]
        : bs === 'uncertain' ? [...s.supportedBy, ...s.contradictedBy]
        : [];
      v = { present: true, label, canAbsorb: true, canTaste: true, because };
    }
    mushrooms[id] = v;
  }
  const text =
    bs === 'probably_safe' ? 'Glowing mushrooms give you light.'
    : bs === 'probably_unsafe' ? 'Glowing mushrooms make you heavy.'
    : bs === 'uncertain' ? 'Not every glowing mushroom is safe. Taste before absorbing.'
    : '';
  const n =
    bs === 'probably_safe' ? note(s.supportedBy.length)
    : bs === 'probably_unsafe' ? note(s.contradictedBy.length)
    : '';
  return {
    slime: { glowing: s.glow > 0, heavy: s.heavy > 0 },
    mushrooms,
    belief: { state: bs, text, note: n, supportedBy: [...s.supportedBy], contradictedBy: [...s.contradictedBy] },
    decision: {
      state: s.decision.state,
      basis: [...s.decision.basis],
      reopenedBy: [...s.decision.reopenedBy],
    },
  };
}

export function createPolicy(saved?: unknown) {
  let state: State = saved === undefined ? initial() : (structuredClone(saved) as State);
  return {
    dispatch(event: Record<string, unknown>): void {
      if (event === null || typeof event !== 'object') fail('event must be an object');
      const next = structuredClone(state);
      apply(next, event);
      state = next;
    },
    view() {
      return render(state);
    },
    save(): unknown {
      return structuredClone(state);
    },
  };
}

// Glowcap beat policy.

type Kind = 'glowcap' | 'duskcap';

interface Mushroom {
  consumed: boolean;
  tasted: Kind | null;
}

interface State {
  glow: number;
  heavy: number;
  mushrooms: Record<string, Mushroom>;
  supportedBy: string[];
  contradictedBy: string[];
  // Caveats attached to each piece of evidence, keyed by evidence id.
  evidenceCaveats: Record<string, string[]>;
  // CR5: seconds elapsed (in ticks) since each taste that has not yet faded.
  tasteAges: Record<string, number>;
  decision: {
    state: 'none' | 'committed' | 'reopened';
    basis: string[];
    reopenedBy: string[];
    // Caveats the basis carried at commit time (frozen).
    caveats: string[];
  };
}

const LEVEL = ['cave', 'pool', 'ruin', 'grove'];
const TASTE_FADE_SECONDS = 60;
const EPS = 1e-9;
const KINDS: readonly string[] = ['glowcap', 'duskcap'];

function initial(): State {
  const mushrooms: Record<string, Mushroom> = {};
  for (const id of LEVEL) mushrooms[id] = { consumed: false, tasted: null };
  return {
    glow: 0,
    heavy: 0,
    mushrooms,
    supportedBy: [],
    contradictedBy: [],
    evidenceCaveats: {},
    tasteAges: {},
    decision: { state: 'none', basis: [], reopenedBy: [], caveats: [] },
  };
}

function beliefState(s: State): string {
  const sup = s.supportedBy.length > 0;
  const con = s.contradictedBy.length > 0;
  if (sup && con) return 'uncertain';
  if (sup) return 'probably_safe';
  if (con) return 'probably_unsafe';
  return 'none';
}

function note(n: number): string {
  return n === 1 ? 'Based on one observation.' : `Based on ${n} observations.`;
}

interface MushroomView {
  present: boolean;
  label: string;
  canAbsorb: boolean;
  canTaste: boolean;
  because: string[];
  caveats: string[];
}

function caveatsOf(s: State, evidence: readonly string[]): string[] {
  const out = new Set<string>();
  for (const e of evidence) for (const c of s.evidenceCaveats[e] ?? []) out.add(c);
  return [...out];
}

function mushroomView(s: State, id: string, m: Mushroom): MushroomView {
  const v = mushroomViewBase(s, id, m);
  return { ...v, caveats: caveatsOf(s, v.because) };
}

function mushroomViewBase(s: State, id: string, m: Mushroom): Omit<MushroomView, 'caveats'> {
  if (m.consumed) return { present: false, label: '', canAbsorb: false, canTaste: false, because: [] };
  const tasteCaveats = s.evidenceCaveats[`taste_${id}`] ?? [];
  const qualifier = tasteCaveats.includes('taste_faded') ? ' (taste has faded)'
    : tasteCaveats.includes('tasted_in_dark') ? ' (tasted in the dark)'
    : '';
  if (m.tasted === 'glowcap')
    return { present: true, label: qualifier ? `Probably a glowcap${qualifier}` : 'Glowcap', canAbsorb: true, canTaste: false, because: [`taste_${id}`] };
  if (m.tasted === 'duskcap')
    return {
      present: true,
      label: qualifier ? `Probably a duskcap${qualifier}` : 'Duskcap — avoid', canAbsorb: false, canTaste: false, because: [`taste_${id}`] };
  // CR2: twice bitten — unknown mushrooms are too risky to absorb.
  if (s.contradictedBy.length >= 2)
    return {
      present: true,
      label: 'Too risky — taste first',
      canAbsorb: false,
      canTaste: true,
      because: [...s.contradictedBy],
    };
  const bs = beliefState(s);
  const label =
    bs === 'none' ? 'Glowing mushroom'
    : bs === 'probably_safe' ? 'Probably a glowcap'
    : bs === 'probably_unsafe' ? 'Probably a duskcap'
    : 'Could be a duskcap — taste first';
  const because =
    bs === 'probably_safe' ? [...s.supportedBy]
    : bs === 'probably_unsafe' ? [...s.contradictedBy]
    : bs === 'uncertain' ? [...s.contradictedBy] // CR4: cite the counterexample only
    : [];
  return { present: true, label, canAbsorb: true, canTaste: true, because };
}

function fail(msg: string): never {
  throw new Error(msg);
}

function lookup(s: State, ev: Record<string, unknown>): [string, Mushroom, Kind] {
  const id = ev.id;
  const kind = ev.kind;
  if (typeof id !== 'string' || !Object.hasOwn(s.mushrooms, id)) fail(`unknown mushroom ${String(id)}`);
  if (typeof kind !== 'string' || !KINDS.includes(kind)) fail(`unknown kind ${String(kind)}`);
  const m = s.mushrooms[id]!;
  if (m.consumed) fail(`mushroom ${id} consumed`);
  return [id, m, kind as Kind];
}

// Record a piece of evidence about the kind of glowing mushrooms and update the trust decision.
function observe(s: State, evId: string, kind: Kind, caveats: string[]): void {
  if (caveats.length > 0) s.evidenceCaveats[evId] = caveats;
  if (kind === 'glowcap') {
    s.supportedBy.push(evId);
    if (s.decision.state === 'none' && beliefState(s) === 'probably_safe') {
      s.decision.state = 'committed';
      s.decision.basis = [...s.supportedBy];
      s.decision.caveats = caveatsOf(s, s.decision.basis);
    }
  } else {
    s.contradictedBy.push(evId);
    if (s.decision.state !== 'none') {
      s.decision.state = 'reopened';
      s.decision.reopenedBy.push(evId);
    }
  }
}

function apply(s: State, ev: Record<string, unknown>): void {
  switch (ev.type) {
    case 'absorb': {
      const [id, m, kind] = lookup(s, ev);
      if (!mushroomView(s, id, m).canAbsorb) fail(`cannot absorb ${id}`);
      if (m.tasted !== null && m.tasted !== kind) fail(`kind contradicts taste of ${id}`);
      m.consumed = true;
      if (kind === 'glowcap') s.glow = 30;
      else s.heavy = 20;
      observe(s, `absorb_${id}`, kind, []);
      return;
    }
    case 'taste': {
      const [id, m, kind] = lookup(s, ev);
      if (m.tasted !== null) fail(`mushroom ${id} already tasted`);
      m.tasted = kind;
      observe(s, `taste_${id}`, kind, s.glow > 0 ? [] : ['tasted_in_dark']);
      s.tasteAges[`taste_${id}`] = 0;
      return;
    }
    case 'tick': {
      const dt = ev.dt;
      if (typeof dt !== 'number' || !Number.isFinite(dt) || dt < 0 || dt > 0.1) fail(`dt out of range`);
      s.glow = Math.max(0, s.glow - dt);
      s.heavy = Math.max(0, s.heavy - dt);
      for (const evId of Object.keys(s.tasteAges)) {
        const age = s.tasteAges[evId]! + dt;
        if (age >= TASTE_FADE_SECONDS - EPS) {
          delete s.tasteAges[evId];
          s.evidenceCaveats[evId] = [...(s.evidenceCaveats[evId] ?? []), 'taste_faded'];
        } else {
          s.tasteAges[evId] = age;
        }
      }
      return;
    }
    default:
      fail(`unknown event type ${String(ev.type)}`);
  }
}

function render(s: State) {
  const bs = beliefState(s);
  const mushrooms: Record<string, MushroomView> = {};
  for (const [id, m] of Object.entries(s.mushrooms)) mushrooms[id] = mushroomView(s, id, m);
  const text =
    bs === 'probably_safe' ? 'Glowing mushrooms give you light.'
    : bs === 'probably_unsafe' ? 'Glowing mushrooms make you heavy.'
    : bs === 'uncertain' ? 'Not every glowing mushroom is safe. Taste before absorbing.'
    : '';
  const n =
    bs === 'probably_safe' ? note(s.supportedBy.length)
    : bs === 'probably_unsafe' ? note(s.contradictedBy.length)
    : '';
  return {
    slime: { glowing: s.glow > 0, heavy: s.heavy > 0 },
    mushrooms,
    belief: { state: bs, text, note: n, supportedBy: [...s.supportedBy], contradictedBy: [...s.contradictedBy],
      caveats: caveatsOf(s, [...s.supportedBy, ...s.contradictedBy]),
    },
    decision: {
      state: s.decision.state,
      basis: [...s.decision.basis],
      reopenedBy: [...s.decision.reopenedBy],
      caveats: [...s.decision.caveats],
    },
  };
}

export function createPolicy(saved?: unknown) {
  let state: State = saved === undefined ? initial() : (structuredClone(saved) as State);
  return {
    dispatch(event: Record<string, unknown>): void {
      if (event === null || typeof event !== 'object') fail('event must be an object');
      const next = structuredClone(state);
      apply(next, event);
      state = next;
    },
    view() {
      return render(state);
    },
    save(): unknown {
      return structuredClone(state);
    },
  };
}

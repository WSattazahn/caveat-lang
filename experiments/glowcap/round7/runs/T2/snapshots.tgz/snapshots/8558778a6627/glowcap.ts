// Glowcap beat policy.

type Kind = 'glowcap' | 'duskcap';

interface Mushroom {
  consumed: boolean;
  tasted: Kind | null;
  // CR10: which life this mushroom is on (1 = original), and seconds since it was consumed.
  life: number;
  sinceConsumed: number;
  // CR11: the evidence that consumed the current life ('' while present).
  consumedBy: string;
}

interface State {
  glow: number;
  heavy: number;
  mushrooms: Record<string, Mushroom>;
  supportedBy: string[];
  contradictedBy: string[];
  // Caveats attached to each piece of evidence, keyed by evidence id.
  evidenceCaveats: Record<string, string[]>;
  // CR5: seconds elapsed (in ticks) since each taste that has not yet faded.
  tasteAges: Record<string, number>;
  decision: {
    state: 'none' | 'committed' | 'reopened';
    basis: string[];
    reopenedBy: string[];
    // Caveats the basis carried at commit time (frozen).
    caveats: string[];
    // CR6: each change to trust, in order.
    history: { change: 'committed' | 'reopened'; because: string[] }[];
  };
  // CR7: glowcap observations since the most recent contradiction, in order.
  supportSinceContradiction: string[];
}

const LEVEL = ['cave', 'pool', 'ruin', 'grove'];
const TASTE_FADE_SECONDS = 60;
const REGROW_SECONDS = 45;
// CR10: declared capacity of lives per mushroom (spec requires at least 64).
export const MAX_LIVES = 1024;

// Evidence id for an observation of a mushroom in a given life.
function evidenceId(prefix: string, id: string, life: number): string {
  return life === 1 ? `${prefix}_${id}` : `${prefix}_${id}_${life}`;
}

function consume(m: Mushroom, by: string): void {
  m.consumed = true;
  m.sinceConsumed = 0;
  m.consumedBy = by;
}
const EPS = 1e-9;
const KINDS: readonly string[] = ['glowcap', 'duskcap'];

function initial(): State {
  const mushrooms: Record<string, Mushroom> = {};
  for (const id of LEVEL) mushrooms[id] = { consumed: false, tasted: null, life: 1, sinceConsumed: 0, consumedBy: '' };
  return {
    glow: 0,
    heavy: 0,
    mushrooms,
    supportedBy: [],
    contradictedBy: [],
    evidenceCaveats: {},
    tasteAges: {},
    decision: { state: 'none', basis: [], reopenedBy: [], caveats: [], history: [] },
    supportSinceContradiction: [],
  };
}

function beliefState(s: State): string {
  const sup = s.supportedBy.length > 0;
  const con = s.contradictedBy.length > 0;
  if (sup && con) return 'uncertain';
  if (sup) return 'probably_safe';
  if (con) return 'probably_unsafe';
  return 'none';
}

function note(n: number): string {
  return n === 1 ? 'Based on one observation.' : `Based on ${n} observations.`;
}

interface MushroomView {
  present: boolean;
  label: string;
  canAbsorb: boolean;
  canTaste: boolean;
  because: string[];
  caveats: string[];
  why: { absorb: WhyNot; taste: WhyNot };
}

interface WhyNot {
  reason: string;
  because: string[];
  caveats: string[];
}

function caveatsOf(s: State, evidence: readonly string[]): string[] {
  const out = new Set<string>();
  for (const e of evidence) for (const c of s.evidenceCaveats[e] ?? []) out.add(c);
  return [...out];
}

function mushroomView(s: State, id: string, m: Mushroom): MushroomView {
  const v = mushroomViewBase(s, id, m);
  return { ...v, caveats: caveatsOf(s, v.because), why: whyNot(s, id, m) };
}

// CR11: why an action is unavailable (first matching rule), or '' when allowed.
function whyNot(s: State, id: string, m: Mushroom): { absorb: WhyNot; taste: WhyNot } {
  const mk = (reason: string, because: string[]): WhyNot => ({ reason, because, caveats: caveatsOf(s, because) });
  const allowed = mk('', []);
  if (m.consumed) {
    return { absorb: mk('Already eaten', [m.consumedBy]), taste: mk('Already eaten', [m.consumedBy]) };
  }
  const tasteId = evidenceId('taste', id, m.life);
  const absorb =
    m.tasted === 'duskcap' ? mk('Known duskcap', [tasteId])
    : m.tasted === null && s.contradictedBy.length >= 2 ? mk('Too risky untasted', [...s.contradictedBy])
    : allowed;
  const taste = m.tasted !== null ? mk('Already tasted', [tasteId]) : allowed;
  return { absorb, taste };
}

function mushroomViewBase(s: State, id: string, m: Mushroom): Omit<MushroomView, 'caveats' | 'why'> {
  if (m.consumed) return { present: false, label: '', canAbsorb: false, canTaste: false, because: [] };
  const tasteId = evidenceId('taste', id, m.life);
  const tasteCaveats = s.evidenceCaveats[tasteId] ?? [];
  const qualifier = tasteCaveats.includes('taste_faded') ? ' (taste has faded)'
    : tasteCaveats.includes('tasted_in_dark') ? ' (tasted in the dark)'
    : '';
  if (m.tasted === 'glowcap')
    return { present: true, label: qualifier ? `Probably a glowcap${qualifier}` : 'Glowcap', canAbsorb: true, canTaste: false, because: [tasteId] };
  if (m.tasted === 'duskcap')
    return {
      present: true,
      label: qualifier ? `Probably a duskcap${qualifier}` : 'Duskcap — avoid', canAbsorb: false, canTaste: false, because: [tasteId] };
  // CR2: twice bitten — unknown mushrooms are too risky to absorb.
  if (s.contradictedBy.length >= 2)
    return {
      present: true,
      label: 'Too risky — taste first',
      canAbsorb: false,
      canTaste: true,
      because: [...s.contradictedBy],
    };
  const bs = beliefState(s);
  const label =
    bs === 'none' ? 'Glowing mushroom'
    : bs === 'probably_safe' ? 'Probably a glowcap'
    : bs === 'probably_unsafe' ? 'Probably a duskcap'
    : 'Could be a duskcap — taste first';
  const because =
    bs === 'probably_safe' ? [...s.supportedBy]
    : bs === 'probably_unsafe' ? [...s.contradictedBy]
    : bs === 'uncertain' ? [...s.contradictedBy] // CR4: cite the counterexample only
    : [];
  return { present: true, label, canAbsorb: true, canTaste: true, because };
}

function fail(msg: string): never {
  throw new Error(msg);
}

function lookup(s: State, ev: Record<string, unknown>): [string, Mushroom, Kind] {
  const id = ev.id;
  const kind = ev.kind;
  if (typeof id !== 'string' || !Object.hasOwn(s.mushrooms, id)) fail(`unknown mushroom ${String(id)}`);
  if (typeof kind !== 'string' || !KINDS.includes(kind)) fail(`unknown kind ${String(kind)}`);
  const m = s.mushrooms[id]!;
  if (m.consumed) fail(`mushroom ${id} consumed`);
  return [id, m, kind as Kind];
}

// Record a piece of evidence about the kind of glowing mushrooms and update the trust decision.
function observe(s: State, evId: string, kind: Kind, caveats: string[]): void {
  if (caveats.length > 0) s.evidenceCaveats[evId] = caveats;
  if (kind === 'glowcap') {
    s.supportedBy.push(evId);
    s.supportSinceContradiction.push(evId);
    if (s.decision.state === 'none' && beliefState(s) === 'probably_safe') {
      commit(s, [...s.supportedBy]);
    } else if (s.decision.state === 'reopened' && s.supportSinceContradiction.length >= 2) {
      commit(s, s.supportSinceContradiction.slice(0, 2));
    }
  } else {
    s.contradictedBy.push(evId);
    s.supportSinceContradiction = [];
    if (s.decision.state !== 'none') {
      s.decision.state = 'reopened';
      s.decision.reopenedBy.push(evId);
      s.decision.history.push({ change: 'reopened', because: [evId] });
    }
  }
}

function commit(s: State, basis: string[]): void {
  s.decision.state = 'committed';
  s.decision.basis = basis;
  s.decision.reopenedBy = [];
  s.decision.caveats = caveatsOf(s, basis);
  s.decision.history.push({ change: 'committed', because: [...basis] });
}

// Lower a timer by dt, not below 0; snap float residue to 0.
function countDown(t: number, dt: number): number {
  const r = t - dt;
  return r <= EPS ? 0 : r;
}

function apply(s: State, ev: Record<string, unknown>): void {
  switch (ev.type) {
    case 'absorb': {
      const [id, m, kind] = lookup(s, ev);
      if (!mushroomView(s, id, m).canAbsorb) fail(`cannot absorb ${id}`);
      if (m.tasted !== null && m.tasted !== kind) fail(`kind contradicts taste of ${id}`);
      consume(m, evidenceId('absorb', id, m.life));
      if (kind === 'glowcap') s.glow = 30;
      else s.heavy = s.heavy > 0 ? Math.min(30, s.heavy + 20) : 20; // CR8: heaviness stacks
      observe(s, evidenceId('absorb', id, m.life), kind, []);
      return;
    }
    case 'witness': {
      // CR9: another creature eats it; the slime's timers are untouched.
      const [id, m, kind] = lookup(s, ev);
      if (m.tasted !== null && m.tasted !== kind) fail(`kind contradicts taste of ${id}`);
      consume(m, evidenceId('witness', id, m.life));
      observe(s, evidenceId('witness', id, m.life), kind, ['secondhand']);
      return;
    }
    case 'taste': {
      const [id, m, kind] = lookup(s, ev);
      if (m.tasted !== null) fail(`mushroom ${id} already tasted`);
      m.tasted = kind;
      const tasteId = evidenceId('taste', id, m.life);
      observe(s, tasteId, kind, s.glow > 0 ? [] : ['tasted_in_dark']);
      s.tasteAges[tasteId] = 0;
      return;
    }
    case 'tick': {
      const dt = ev.dt;
      if (typeof dt !== 'number' || !Number.isFinite(dt) || dt < 0 || dt > 0.1) fail(`dt out of range`);
      s.glow = countDown(s.glow, dt);
      s.heavy = countDown(s.heavy, dt);
      // CR10: consumed mushrooms with lives left regrow after 45 s.
      for (const m of Object.values(s.mushrooms)) {
        if (!m.consumed || m.life >= MAX_LIVES) continue;
        m.sinceConsumed += dt;
        if (m.sinceConsumed >= REGROW_SECONDS - EPS) {
          m.consumed = false;
          m.tasted = null;
          m.life += 1;
          m.sinceConsumed = 0;
          m.consumedBy = '';
        }
      }
      for (const evId of Object.keys(s.tasteAges)) {
        const age = s.tasteAges[evId]! + dt;
        if (age >= TASTE_FADE_SECONDS - EPS) {
          delete s.tasteAges[evId];
          s.evidenceCaveats[evId] = [...(s.evidenceCaveats[evId] ?? []), 'taste_faded'];
        } else {
          s.tasteAges[evId] = age;
        }
      }
      return;
    }
    default:
      fail(`unknown event type ${String(ev.type)}`);
  }
}

function render(s: State) {
  const bs = beliefState(s);
  const mushrooms: Record<string, MushroomView> = {};
  for (const [id, m] of Object.entries(s.mushrooms)) mushrooms[id] = mushroomView(s, id, m);
  const text =
    bs === 'probably_safe' ? 'Glowing mushrooms give you light.'
    : bs === 'probably_unsafe' ? 'Glowing mushrooms make you heavy.'
    : bs === 'uncertain' ? 'Not every glowing mushroom is safe. Taste before absorbing.'
    : '';
  const n =
    bs === 'probably_safe' ? note(s.supportedBy.length)
    : bs === 'probably_unsafe' ? note(s.contradictedBy.length)
    : '';
  return {
    slime: {
      glowing: s.glow > 0,
      heavy: s.heavy > 0,
      heavySeconds: s.heavy > 0 ? Math.max(1, Math.ceil(s.heavy - EPS)) : 0,
    },
    mushrooms,
    belief: { state: bs, text, note: n, supportedBy: [...s.supportedBy], contradictedBy: [...s.contradictedBy],
      caveats: caveatsOf(s, [...s.supportedBy, ...s.contradictedBy]),
    },
    decision: {
      state: s.decision.state,
      basis: [...s.decision.basis],
      reopenedBy: [...s.decision.reopenedBy],
      caveats: [...s.decision.caveats],
      history: s.decision.history.map((h) => ({ change: h.change, because: [...h.because] })),
    },
  };
}

// ---------------------------------------------------------------------------
// CR12: compact save format.
// Evidence ids become short tokens: prefix letter (a/t/w) + level index, plus
// "_<life>" from life 2 (e.g. absorb_cave -> "a0", taste_grove_3 -> "t3_3").
// Caveats become one letter each, in order (d/f/s).

const PREFIXES: Record<string, string> = { absorb: 'a', taste: 't', witness: 'w' };
const PREFIX_OF: Record<string, string> = { a: 'absorb', t: 'taste', w: 'witness' };
const CAVEAT_CODES: Record<string, string> = { tasted_in_dark: 'd', taste_faded: 'f', secondhand: 's' };
const CAVEAT_OF: Record<string, string> = { d: 'tasted_in_dark', f: 'taste_faded', s: 'secondhand' };
const EVIDENCE_RE = /^(absorb|taste|witness)_([a-z]+)(?:_(\d+))?$/;
const TOKEN_RE = /^([atw])(\d+)(?:_(\d+))?$/;

function enc(evId: string): string {
  const m = EVIDENCE_RE.exec(evId);
  if (!m) fail(`cannot encode evidence ${evId}`);
  const idx = LEVEL.indexOf(m[2]!);
  if (idx < 0) fail(`cannot encode evidence ${evId}`);
  return `${PREFIXES[m[1]!]}${idx}${m[3] ? `_${m[3]}` : ''}`;
}

function dec(token: unknown): string {
  if (typeof token !== 'string') fail('bad save: evidence token');
  const m = TOKEN_RE.exec(token);
  const id = m ? LEVEL[Number(m[2])] : undefined;
  if (!m || id === undefined) fail(`bad save: evidence token ${token}`);
  return `${PREFIX_OF[m[1]!]}_${id}${m[3] ? `_${m[3]}` : ''}`;
}

const encCaveats = (cs: string[]): string => cs.map((c) => CAVEAT_CODES[c] ?? fail(`cannot encode caveat ${c}`)).join('');
const decCaveats = (code: unknown): string[] => {
  if (typeof code !== 'string') fail('bad save: caveats');
  return [...code].map((c) => CAVEAT_OF[c] ?? fail(`bad save: caveat ${c}`));
};
const encList = (xs: string[]): string => xs.map(enc).join(' ');
const decList = (x: unknown): string[] => {
  if (typeof x !== 'string') fail('bad save: list');
  return x === '' ? [] : x.split(' ').map(dec);
};
const num = (x: unknown): number => {
  if (typeof x !== 'number' || !Number.isFinite(x)) fail('bad save: number');
  return x;
};

const SAVE_VERSION = 1;
const DECISION_STATES = ['none', 'committed', 'reopened'] as const;
const TASTED = [null, 'glowcap', 'duskcap'] as const;

function encode(s: State): unknown {
  return {
    v: SAVE_VERSION,
    g: s.glow,
    h: s.heavy,
    // per level mushroom: [consumed, tasted, life, sinceConsumed, consumedBy]
    m: LEVEL.map((id) => {
      const m = s.mushrooms[id]!;
      return [m.consumed ? 1 : 0, TASTED.indexOf(m.tasted), m.life, m.sinceConsumed, m.consumedBy ? enc(m.consumedBy) : ''];
    }),
    s: encList(s.supportedBy),
    c: encList(s.contradictedBy),
    // "token:codes" separated by spaces; witness evidence is implied 'secondhand' and omitted.
    k: Object.entries(s.evidenceCaveats)
      .filter(([e, cs]) => !(e.startsWith('witness_') && cs.length === 1 && cs[0] === 'secondhand'))
      .map(([e, cs]) => `${enc(e)}:${encCaveats(cs)}`)
      .join(' '),
    t: Object.entries(s.tasteAges).map(([e, age]) => [enc(e), age]),
    d: [
      DECISION_STATES.indexOf(s.decision.state),
      encList(s.decision.basis),
      encList(s.decision.reopenedBy),
      encCaveats(s.decision.caveats),
      s.decision.history.map((h) => `${h.change === 'committed' ? 'c' : 'r'}${encList(h.because)}`),
    ],
    r: encList(s.supportSinceContradiction),
  };
}

function decode(saved: unknown): State {
  const o = saved as Record<string, unknown> | null;
  if (o === null || typeof o !== 'object' || o.v !== SAVE_VERSION) fail('bad save: version');
  const ms = o.m as unknown[];
  if (!Array.isArray(ms) || ms.length !== LEVEL.length) fail('bad save: mushrooms');
  const mushrooms: Record<string, Mushroom> = {};
  LEVEL.forEach((id, i) => {
    const row = ms[i] as unknown[];
    if (!Array.isArray(row) || row.length !== 5) fail('bad save: mushroom');
    const tasted = TASTED[num(row[1])];
    if (tasted === undefined) fail('bad save: tasted');
    mushrooms[id] = {
      consumed: row[0] === 1,
      tasted,
      life: num(row[2]),
      sinceConsumed: num(row[3]),
      consumedBy: row[4] === '' ? '' : dec(row[4]),
    };
  });
  const pairs = (x: unknown): unknown[][] => {
    if (!Array.isArray(x) || !x.every((p) => Array.isArray(p) && p.length === 2)) fail('bad save: pairs');
    return x as unknown[][];
  };
  const evidenceCaveats: Record<string, string[]> = {};
  if (typeof o.k !== 'string') fail('bad save: caveats');
  for (const ev of [...decList(o.s), ...decList(o.c)]) if (ev.startsWith('witness_')) evidenceCaveats[ev] = ['secondhand'];
  for (const entry of o.k === '' ? [] : o.k.split(' ')) {
    const [e, cs] = entry.split(':');
    evidenceCaveats[dec(e)] = decCaveats(cs);
  }
  const tasteAges: Record<string, number> = {};
  for (const [e, age] of pairs(o.t)) tasteAges[dec(e)] = num(age);
  const d = o.d as unknown[];
  if (!Array.isArray(d) || d.length !== 5 || !Array.isArray(d[4])) fail('bad save: decision');
  const state = DECISION_STATES[num(d[0])];
  if (state === undefined) fail('bad save: decision state');
  const history = (d[4] as unknown[]).map((h) => {
    if (typeof h !== 'string' || (h[0] !== 'c' && h[0] !== 'r')) fail('bad save: history');
    return { change: h[0] === 'c' ? ('committed' as const) : ('reopened' as const), because: decList(h.slice(1)) };
  });
  return {
    glow: num(o.g),
    heavy: num(o.h),
    mushrooms,
    supportedBy: decList(o.s),
    contradictedBy: decList(o.c),
    evidenceCaveats,
    tasteAges,
    decision: {
      state,
      basis: decList(d[1]),
      reopenedBy: decList(d[2]),
      caveats: decCaveats(d[3]),
      history,
    },
    supportSinceContradiction: decList(o.r),
  };
}

export function createPolicy(saved?: unknown) {
  let state: State = saved === undefined ? initial() : decode(saved);
  return {
    dispatch(event: Record<string, unknown>): void {
      if (event === null || typeof event !== 'object') fail('event must be an object');
      const next = structuredClone(state);
      apply(next, event);
      state = next;
    },
    view() {
      return render(state);
    },
    save(): unknown {
      return encode(state);
    },
  };
}

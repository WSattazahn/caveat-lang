// Glowcap beat policy.

type Kind = 'glowcap' | 'duskcap';

interface Mushroom {
  consumed: boolean;
  tasted: Kind | null;
  // CR10: which life this mushroom is on (1 = original), and seconds since it was consumed.
  life: number;
  sinceConsumed: number;
}

interface State {
  glow: number;
  heavy: number;
  mushrooms: Record<string, Mushroom>;
  supportedBy: string[];
  contradictedBy: string[];
  // Caveats attached to each piece of evidence, keyed by evidence id.
  evidenceCaveats: Record<string, string[]>;
  // CR5: seconds elapsed (in ticks) since each taste that has not yet faded.
  tasteAges: Record<string, number>;
  decision: {
    state: 'none' | 'committed' | 'reopened';
    basis: string[];
    reopenedBy: string[];
    // Caveats the basis carried at commit time (frozen).
    caveats: string[];
    // CR6: each change to trust, in order.
    history: { change: 'committed' | 'reopened'; because: string[] }[];
  };
  // CR7: glowcap observations since the most recent contradiction, in order.
  supportSinceContradiction: string[];
}

const LEVEL = ['cave', 'pool', 'ruin', 'grove'];
const TASTE_FADE_SECONDS = 60;
const REGROW_SECONDS = 45;
// CR10: declared capacity of lives per mushroom (spec requires at least 64).
export const MAX_LIVES = 1024;

// Evidence id for an observation of a mushroom in a given life.
function evidenceId(prefix: string, id: string, life: number): string {
  return life === 1 ? `${prefix}_${id}` : `${prefix}_${id}_${life}`;
}

function consume(m: Mushroom): void {
  m.consumed = true;
  m.sinceConsumed = 0;
}
const EPS = 1e-9;
const KINDS: readonly string[] = ['glowcap', 'duskcap'];

function initial(): State {
  const mushrooms: Record<string, Mushroom> = {};
  for (const id of LEVEL) mushrooms[id] = { consumed: false, tasted: null, life: 1, sinceConsumed: 0 };
  return {
    glow: 0,
    heavy: 0,
    mushrooms,
    supportedBy: [],
    contradictedBy: [],
    evidenceCaveats: {},
    tasteAges: {},
    decision: { state: 'none', basis: [], reopenedBy: [], caveats: [], history: [] },
    supportSinceContradiction: [],
  };
}

function beliefState(s: State): string {
  const sup = s.supportedBy.length > 0;
  const con = s.contradictedBy.length > 0;
  if (sup && con) return 'uncertain';
  if (sup) return 'probably_safe';
  if (con) return 'probably_unsafe';
  return 'none';
}

function note(n: number): string {
  return n === 1 ? 'Based on one observation.' : `Based on ${n} observations.`;
}

interface MushroomView {
  present: boolean;
  label: string;
  canAbsorb: boolean;
  canTaste: boolean;
  because: string[];
  caveats: string[];
}

function caveatsOf(s: State, evidence: readonly string[]): string[] {
  const out = new Set<string>();
  for (const e of evidence) for (const c of s.evidenceCaveats[e] ?? []) out.add(c);
  return [...out];
}

function mushroomView(s: State, id: string, m: Mushroom): MushroomView {
  const v = mushroomViewBase(s, id, m);
  return { ...v, caveats: caveatsOf(s, v.because) };
}

function mushroomViewBase(s: State, id: string, m: Mushroom): Omit<MushroomView, 'caveats'> {
  if (m.consumed) return { present: false, label: '', canAbsorb: false, canTaste: false, because: [] };
  const tasteId = evidenceId('taste', id, m.life);
  const tasteCaveats = s.evidenceCaveats[tasteId] ?? [];
  const qualifier = tasteCaveats.includes('taste_faded') ? ' (taste has faded)'
    : tasteCaveats.includes('tasted_in_dark') ? ' (tasted in the dark)'
    : '';
  if (m.tasted === 'glowcap')
    return { present: true, label: qualifier ? `Probably a glowcap${qualifier}` : 'Glowcap', canAbsorb: true, canTaste: false, because: [tasteId] };
  if (m.tasted === 'duskcap')
    return {
      present: true,
      label: qualifier ? `Probably a duskcap${qualifier}` : 'Duskcap — avoid', canAbsorb: false, canTaste: false, because: [tasteId] };
  // CR2: twice bitten — unknown mushrooms are too risky to absorb.
  if (s.contradictedBy.length >= 2)
    return {
      present: true,
      label: 'Too risky — taste first',
      canAbsorb: false,
      canTaste: true,
      because: [...s.contradictedBy],
    };
  const bs = beliefState(s);
  const label =
    bs === 'none' ? 'Glowing mushroom'
    : bs === 'probably_safe' ? 'Probably a glowcap'
    : bs === 'probably_unsafe' ? 'Probably a duskcap'
    : 'Could be a duskcap — taste first';
  const because =
    bs === 'probably_safe' ? [...s.supportedBy]
    : bs === 'probably_unsafe' ? [...s.contradictedBy]
    : bs === 'uncertain' ? [...s.contradictedBy] // CR4: cite the counterexample only
    : [];
  return { present: true, label, canAbsorb: true, canTaste: true, because };
}

function fail(msg: string): never {
  throw new Error(msg);
}

function lookup(s: State, ev: Record<string, unknown>): [string, Mushroom, Kind] {
  const id = ev.id;
  const kind = ev.kind;
  if (typeof id !== 'string' || !Object.hasOwn(s.mushrooms, id)) fail(`unknown mushroom ${String(id)}`);
  if (typeof kind !== 'string' || !KINDS.includes(kind)) fail(`unknown kind ${String(kind)}`);
  const m = s.mushrooms[id]!;
  if (m.consumed) fail(`mushroom ${id} consumed`);
  return [id, m, kind as Kind];
}

// Record a piece of evidence about the kind of glowing mushrooms and update the trust decision.
function observe(s: State, evId: string, kind: Kind, caveats: string[]): void {
  if (caveats.length > 0) s.evidenceCaveats[evId] = caveats;
  if (kind === 'glowcap') {
    s.supportedBy.push(evId);
    s.supportSinceContradiction.push(evId);
    if (s.decision.state === 'none' && beliefState(s) === 'probably_safe') {
      commit(s, [...s.supportedBy]);
    } else if (s.decision.state === 'reopened' && s.supportSinceContradiction.length >= 2) {
      commit(s, s.supportSinceContradiction.slice(0, 2));
    }
  } else {
    s.contradictedBy.push(evId);
    s.supportSinceContradiction = [];
    if (s.decision.state !== 'none') {
      s.decision.state = 'reopened';
      s.decision.reopenedBy.push(evId);
      s.decision.history.push({ change: 'reopened', because: [evId] });
    }
  }
}

function commit(s: State, basis: string[]): void {
  s.decision.state = 'committed';
  s.decision.basis = basis;
  s.decision.reopenedBy = [];
  s.decision.caveats = caveatsOf(s, basis);
  s.decision.history.push({ change: 'committed', because: [...basis] });
}

// Lower a timer by dt, not below 0; snap float residue to 0.
function countDown(t: number, dt: number): number {
  const r = t - dt;
  return r <= EPS ? 0 : r;
}

function apply(s: State, ev: Record<string, unknown>): void {
  switch (ev.type) {
    case 'absorb': {
      const [id, m, kind] = lookup(s, ev);
      if (!mushroomView(s, id, m).canAbsorb) fail(`cannot absorb ${id}`);
      if (m.tasted !== null && m.tasted !== kind) fail(`kind contradicts taste of ${id}`);
      consume(m);
      if (kind === 'glowcap') s.glow = 30;
      else s.heavy = s.heavy > 0 ? Math.min(30, s.heavy + 20) : 20; // CR8: heaviness stacks
      observe(s, evidenceId('absorb', id, m.life), kind, []);
      return;
    }
    case 'witness': {
      // CR9: another creature eats it; the slime's timers are untouched.
      const [id, m, kind] = lookup(s, ev);
      if (m.tasted !== null && m.tasted !== kind) fail(`kind contradicts taste of ${id}`);
      consume(m);
      observe(s, evidenceId('witness', id, m.life), kind, ['secondhand']);
      return;
    }
    case 'taste': {
      const [id, m, kind] = lookup(s, ev);
      if (m.tasted !== null) fail(`mushroom ${id} already tasted`);
      m.tasted = kind;
      const tasteId = evidenceId('taste', id, m.life);
      observe(s, tasteId, kind, s.glow > 0 ? [] : ['tasted_in_dark']);
      s.tasteAges[tasteId] = 0;
      return;
    }
    case 'tick': {
      const dt = ev.dt;
      if (typeof dt !== 'number' || !Number.isFinite(dt) || dt < 0 || dt > 0.1) fail(`dt out of range`);
      s.glow = countDown(s.glow, dt);
      s.heavy = countDown(s.heavy, dt);
      // CR10: consumed mushrooms with lives left regrow after 45 s.
      for (const m of Object.values(s.mushrooms)) {
        if (!m.consumed || m.life >= MAX_LIVES) continue;
        m.sinceConsumed += dt;
        if (m.sinceConsumed >= REGROW_SECONDS - EPS) {
          m.consumed = false;
          m.tasted = null;
          m.life += 1;
          m.sinceConsumed = 0;
        }
      }
      for (const evId of Object.keys(s.tasteAges)) {
        const age = s.tasteAges[evId]! + dt;
        if (age >= TASTE_FADE_SECONDS - EPS) {
          delete s.tasteAges[evId];
          s.evidenceCaveats[evId] = [...(s.evidenceCaveats[evId] ?? []), 'taste_faded'];
        } else {
          s.tasteAges[evId] = age;
        }
      }
      return;
    }
    default:
      fail(`unknown event type ${String(ev.type)}`);
  }
}

function render(s: State) {
  const bs = beliefState(s);
  const mushrooms: Record<string, MushroomView> = {};
  for (const [id, m] of Object.entries(s.mushrooms)) mushrooms[id] = mushroomView(s, id, m);
  const text =
    bs === 'probably_safe' ? 'Glowing mushrooms give you light.'
    : bs === 'probably_unsafe' ? 'Glowing mushrooms make you heavy.'
    : bs === 'uncertain' ? 'Not every glowing mushroom is safe. Taste before absorbing.'
    : '';
  const n =
    bs === 'probably_safe' ? note(s.supportedBy.length)
    : bs === 'probably_unsafe' ? note(s.contradictedBy.length)
    : '';
  return {
    slime: {
      glowing: s.glow > 0,
      heavy: s.heavy > 0,
      heavySeconds: s.heavy > 0 ? Math.max(1, Math.ceil(s.heavy - EPS)) : 0,
    },
    mushrooms,
    belief: { state: bs, text, note: n, supportedBy: [...s.supportedBy], contradictedBy: [...s.contradictedBy],
      caveats: caveatsOf(s, [...s.supportedBy, ...s.contradictedBy]),
    },
    decision: {
      state: s.decision.state,
      basis: [...s.decision.basis],
      reopenedBy: [...s.decision.reopenedBy],
      caveats: [...s.decision.caveats],
      history: s.decision.history.map((h) => ({ change: h.change, because: [...h.because] })),
    },
  };
}

export function createPolicy(saved?: unknown) {
  let state: State = saved === undefined ? initial() : (structuredClone(saved) as State);
  return {
    dispatch(event: Record<string, unknown>): void {
      if (event === null || typeof event !== 'object') fail('event must be an object');
      const next = structuredClone(state);
      apply(next, event);
      state = next;
    },
    view() {
      return render(state);
    },
    save(): unknown {
      return structuredClone(state);
    },
  };
}

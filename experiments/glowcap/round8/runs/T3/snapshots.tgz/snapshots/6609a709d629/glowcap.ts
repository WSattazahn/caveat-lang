// Glowcap beat policy.
type Kind = 'glowcap' | 'duskcap';
const KINDS: readonly string[] = ['glowcap', 'duskcap'];
const LEVEL: readonly string[] = ['cave', 'pool', 'ruin', 'grove'];
const GLOW_TIME = 30;
const HEAVY_TIME = 20;
const HEAVY_MAX = 30;
const TASTE_FADE = 60;
const REGROW_TIME = 45;
// Declared capacity: each mushroom has at most this many lives (CR10 requires >= 64).
export const MAX_LIVES = 1024;
const EPS = 1e-9;

// tasted refers to the current life only; consumedAge counts ticks since consumption (for regrowth).
interface MushroomState { life: number; consumed: boolean; consumedAge: number; consumedBy: string; tasted: Kind | null }
interface HistoryEntry { change: 'committed' | 'reopened'; because: string[] }

interface State {
  glow: number;
  heavy: number;
  mushrooms: Record<string, MushroomState>;
  supportedBy: string[];
  contradictedBy: string[];
  // caveats carried by each evidence id (absent = none)
  caveats: Record<string, string[]>;
  // seconds since each taste that has not faded yet, keyed by evidence id
  tasteAges: Record<string, number>;
  // basisCaveats: caveats the basis carried when committed (frozen)
  decision: {
    state: 'none' | 'committed' | 'reopened';
    basis: string[];
    basisCaveats: string[];
    reopenedBy: string[];
    history: HistoryEntry[];
    // glowcap observations since the most recent contradiction (for CR7 recovery)
    sinceContradiction: string[];
  };
}

export interface GlowEvent { type: string; [k: string]: unknown }

function initial(): State {
  const mushrooms: Record<string, MushroomState> = {};
  for (const id of LEVEL) mushrooms[id] = { life: 1, consumed: false, consumedAge: 0, consumedBy: '', tasted: null };
  return { glow: 0, heavy: 0, mushrooms, supportedBy: [], contradictedBy: [], caveats: {}, tasteAges: {}, decision: { state: 'none', basis: [], basisCaveats: [], reopenedBy: [], history: [], sinceContradiction: [] } };
}

function beliefState(s: State): 'none' | 'probably_safe' | 'probably_unsafe' | 'uncertain' {
  const sup = s.supportedBy.length > 0, con = s.contradictedBy.length > 0;
  if (sup && con) return 'uncertain';
  if (sup) return 'probably_safe';
  if (con) return 'probably_unsafe';
  return 'none';
}

// Evidence id for an observation of a mushroom's given life: absorb_cave, absorb_cave_2, ...
function evId(what: 'absorb' | 'taste' | 'witness', id: string, life: number): string {
  return life === 1 ? `${what}_${id}` : `${what}_${id}_${life}`;
}

function note(n: number): string { return n === 1 ? 'Based on one observation.' : `Based on ${n} observations.`; }

function caveatsOf(s: State, evidence: readonly string[]): string[] {
  const out = new Set<string>();
  for (const ev of evidence) for (const c of s.caveats[ev] ?? []) out.add(c);
  return [...out];
}

interface Why { reason: string; because: string[]; caveats: string[] }
interface MushroomView {
  present: boolean; label: string; canAbsorb: boolean; canTaste: boolean; because: string[]; caveats: string[];
  why: { absorb: Why; taste: Why };
}

function mushroomView(s: State, id: string): MushroomView {
  const v = mushroomRow(s, id);
  return { ...v, caveats: caveatsOf(s, v.because), why: whyNot(s, id) };
}

function why(s: State, reason: string, because: string[]): Why {
  return { reason, because, caveats: caveatsOf(s, because) };
}

// CR11: first matching reason an action is unavailable; '' when it is allowed.
function whyNot(s: State, id: string): { absorb: Why; taste: Why } {
  const m = s.mushrooms[id];
  if (m.consumed) return { absorb: why(s, 'Already eaten', [m.consumedBy]), taste: why(s, 'Already eaten', [m.consumedBy]) };
  const tasteEv = evId('taste', id, m.life);
  const absorb = m.tasted === 'duskcap' ? why(s, 'Known duskcap', [tasteEv])
    : m.tasted === null && s.contradictedBy.length >= 2 ? why(s, 'Too risky untasted', [...s.contradictedBy])
    : why(s, '', []);
  const taste = m.tasted !== null ? why(s, 'Already tasted', [tasteEv]) : why(s, '', []);
  return { absorb, taste };
}

function mushroomRow(s: State, id: string) {
  const m = s.mushrooms[id];
  if (m.consumed) return { present: false, label: '', canAbsorb: false, canTaste: false, because: [] as string[] };
  const tasteEv = evId('taste', id, m.life);
  const tc = m.tasted !== null ? (s.caveats[tasteEv] ?? []) : [];
  const qual = tc.includes('taste_faded') ? ' (taste has faded)' : tc.includes('tasted_in_dark') ? ' (tasted in the dark)' : null;
  if (m.tasted === 'glowcap') return { present: true, label: qual !== null ? `Probably a glowcap${qual}` : 'Glowcap', canAbsorb: true, canTaste: false, because: [tasteEv] };
  if (m.tasted === 'duskcap') return { present: true, label: qual !== null ? `Probably a duskcap${qual}` : 'Duskcap — avoid', canAbsorb: false, canTaste: false, because: [tasteEv] };
  if (s.contradictedBy.length >= 2) return { present: true, label: 'Too risky — taste first', canAbsorb: false, canTaste: true, because: [...s.contradictedBy] };
  switch (beliefState(s)) {
    case 'none': return { present: true, label: 'Glowing mushroom', canAbsorb: true, canTaste: true, because: [] as string[] };
    case 'probably_safe': return { present: true, label: 'Probably a glowcap', canAbsorb: true, canTaste: true, because: [...s.supportedBy] };
    case 'probably_unsafe': return { present: true, label: 'Probably a duskcap', canAbsorb: true, canTaste: true, because: [...s.contradictedBy] };
    case 'uncertain': return { present: true, label: 'Could be a duskcap — taste first', canAbsorb: true, canTaste: true, because: [...s.contradictedBy] };
  }
}

// Whole seconds rounded up; tolerance absorbs float drift from summed dt.
function heavySeconds(t: number): number {
  return t > 0 ? Math.max(1, Math.ceil(t - 1e-9)) : 0;
}

function render(s: State) {
  const bs = beliefState(s);
  const belief = {
    state: bs,
    text: bs === 'none' ? '' : bs === 'probably_safe' ? 'Glowing mushrooms give you light.'
      : bs === 'probably_unsafe' ? 'Glowing mushrooms make you heavy.' : 'Not every glowing mushroom is safe. Taste before absorbing.',
    note: bs === 'probably_safe' ? note(s.supportedBy.length) : bs === 'probably_unsafe' ? note(s.contradictedBy.length) : '',
    supportedBy: [...s.supportedBy],
    contradictedBy: [...s.contradictedBy],
    caveats: caveatsOf(s, [...s.supportedBy, ...s.contradictedBy]),
  };
  const mushrooms: Record<string, MushroomView> = {};
  for (const id of LEVEL) mushrooms[id] = mushroomView(s, id);
  return {
    slime: { glowing: s.glow > 0, heavy: s.heavy > 0, heavySeconds: heavySeconds(s.heavy) },
    mushrooms,
    belief,
    decision: { state: s.decision.state, basis: [...s.decision.basis], reopenedBy: [...s.decision.reopenedBy], caveats: [...s.decision.basisCaveats], history: s.decision.history.map((h) => ({ change: h.change, because: [...h.because] })) },
  };
}

function fail(msg: string): never { throw new Error(msg); }

function target(s: State, e: GlowEvent): { id: string; kind: Kind; m: MushroomState } {
  const id = e.id, kind = e.kind;
  if (typeof id !== 'string' || !Object.hasOwn(s.mushrooms, id)) fail(`unknown mushroom ${String(id)}`);
  if (typeof kind !== 'string' || !KINDS.includes(kind)) fail(`unknown kind ${String(kind)}`);
  const m = s.mushrooms[id];
  if (m.consumed) fail(`${id} already consumed`);
  return { id, kind: kind as Kind, m };
}

// Record one piece of evidence about glowing mushrooms and update the trust decision.
function addEvidence(s: State, ev: string, kind: Kind, caveats: string[]): void {
  if (caveats.length > 0) s.caveats[ev] = [...caveats];
  if (kind === 'glowcap') s.supportedBy.push(ev); else s.contradictedBy.push(ev);
  const d = s.decision;
  if (kind === 'duskcap') d.sinceContradiction = [];
  else d.sinceContradiction.push(ev);
  if (d.state === 'none' && beliefState(s) === 'probably_safe') {
    commit(s, [...s.supportedBy]);
  } else if (d.state === 'reopened' && d.sinceContradiction.length >= 2) {
    commit(s, d.sinceContradiction.slice(0, 2));
  } else if (d.state !== 'none' && kind === 'duskcap') {
    d.state = 'reopened';
    d.reopenedBy.push(ev);
    d.history.push({ change: 'reopened', because: [ev] });
  }
}

function commit(s: State, basis: string[]): void {
  const d = s.decision;
  d.state = 'committed';
  d.basis = basis;
  d.basisCaveats = caveatsOf(s, basis);
  d.reopenedBy = [];
  d.history.push({ change: 'committed', because: [...basis] });
}

function consume(m: MushroomState, by: string): void {
  m.consumed = true;
  m.consumedBy = by;
  m.consumedAge = 0;
}

function apply(s: State, e: GlowEvent): void {
  if (e === null || typeof e !== 'object') fail('event must be an object');
  switch (e.type) {
    case 'absorb': {
      const { id, kind, m } = target(s, e);
      if (!mushroomView(s, id).canAbsorb) fail(`${id} cannot be absorbed`);
      if (m.tasted !== null && m.tasted !== kind) fail(`${id} kind contradicts its taste`);
      const ev = evId('absorb', id, m.life);
      consume(m, ev);
      if (kind === 'glowcap') s.glow = GLOW_TIME;
      else s.heavy = s.heavy > 0 ? Math.min(HEAVY_MAX, s.heavy + HEAVY_TIME) : HEAVY_TIME;
      addEvidence(s, ev, kind, []);
      return;
    }
    case 'witness': {
      const { id, kind, m } = target(s, e);
      if (m.tasted !== null && m.tasted !== kind) fail(`${id} kind contradicts its taste`);
      const ev = evId('witness', id, m.life);
      consume(m, ev);
      addEvidence(s, ev, kind, ['secondhand']);
      return;
    }
    case 'taste': {
      const { id, kind, m } = target(s, e);
      if (m.tasted !== null) fail(`${id} already tasted`);
      m.tasted = kind;
      const ev = evId('taste', id, m.life);
      s.tasteAges[ev] = 0;
      addEvidence(s, ev, kind, s.glow > 0 ? [] : ['tasted_in_dark']);
      return;
    }
    case 'tick': {
      const dt = e.dt;
      if (typeof dt !== 'number' || !Number.isFinite(dt) || dt < 0 || dt > 0.1) fail(`dt out of range`);
      s.glow = Math.max(0, s.glow - dt);
      s.heavy = Math.max(0, s.heavy - dt);
      for (const ev of Object.keys(s.tasteAges)) {
        const age = s.tasteAges[ev] + dt;
        if (age >= TASTE_FADE - EPS) {
          s.caveats[ev] = [...(s.caveats[ev] ?? []), 'taste_faded'];
          delete s.tasteAges[ev];
        } else s.tasteAges[ev] = age;
      }
      for (const id of LEVEL) {
        const m = s.mushrooms[id];
        if (!m.consumed || m.life >= MAX_LIVES) continue;
        m.consumedAge += dt;
        if (m.consumedAge >= REGROW_TIME - EPS) {
          m.life += 1;
          m.consumed = false;
          m.consumedAge = 0;
          m.consumedBy = '';
          m.tasted = null;
        }
      }
      return;
    }
    default: fail(`unknown event type ${String(e.type)}`);
  }
}

export function createPolicy(saved?: unknown) {
  let state: State = saved === undefined ? initial() : (structuredClone(saved) as State);
  return {
    dispatch(event: GlowEvent): void {
      const next = structuredClone(state);
      apply(next, event);
      state = next;
    },
    view() { return render(state); },
    save(): unknown { return structuredClone(state); },
  };
}

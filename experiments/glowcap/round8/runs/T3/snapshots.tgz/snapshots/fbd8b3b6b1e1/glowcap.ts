// Glowcap beat policy.
type Kind = 'glowcap' | 'duskcap';
const KINDS: readonly string[] = ['glowcap', 'duskcap'];
const LEVEL: readonly string[] = ['cave', 'pool', 'ruin', 'grove'];
const GLOW_TIME = 30;
const HEAVY_TIME = 20;

interface MushroomState { consumed: boolean; tasted: Kind | null }
interface State {
  glow: number;
  heavy: number;
  mushrooms: Record<string, MushroomState>;
  supportedBy: string[];
  contradictedBy: string[];
  decision: { state: 'none' | 'committed' | 'reopened'; basis: string[]; reopenedBy: string[] };
}

export interface GlowEvent { type: string; [k: string]: unknown }

function initial(): State {
  const mushrooms: Record<string, MushroomState> = {};
  for (const id of LEVEL) mushrooms[id] = { consumed: false, tasted: null };
  return { glow: 0, heavy: 0, mushrooms, supportedBy: [], contradictedBy: [], decision: { state: 'none', basis: [], reopenedBy: [] } };
}

function beliefState(s: State): 'none' | 'probably_safe' | 'probably_unsafe' | 'uncertain' {
  const sup = s.supportedBy.length > 0, con = s.contradictedBy.length > 0;
  if (sup && con) return 'uncertain';
  if (sup) return 'probably_safe';
  if (con) return 'probably_unsafe';
  return 'none';
}

function note(n: number): string { return n === 1 ? 'Based on one observation.' : `Based on ${n} observations.`; }

function mushroomView(s: State, id: string) {
  const m = s.mushrooms[id];
  if (m.consumed) return { present: false, label: '', canAbsorb: false, canTaste: false, because: [] as string[] };
  if (m.tasted === 'glowcap') return { present: true, label: 'Glowcap', canAbsorb: true, canTaste: false, because: [`taste_${id}`] };
  if (m.tasted === 'duskcap') return { present: true, label: 'Duskcap — avoid', canAbsorb: false, canTaste: false, because: [`taste_${id}`] };
  switch (beliefState(s)) {
    case 'none': return { present: true, label: 'Glowing mushroom', canAbsorb: true, canTaste: true, because: [] as string[] };
    case 'probably_safe': return { present: true, label: 'Probably a glowcap', canAbsorb: true, canTaste: true, because: [...s.supportedBy] };
    case 'probably_unsafe': return { present: true, label: 'Probably a duskcap', canAbsorb: true, canTaste: true, because: [...s.contradictedBy] };
    case 'uncertain': return { present: true, label: 'Could be a duskcap — taste first', canAbsorb: true, canTaste: true, because: [...s.supportedBy, ...s.contradictedBy] };
  }
}

function render(s: State) {
  const bs = beliefState(s);
  const belief = {
    state: bs,
    text: bs === 'none' ? '' : bs === 'probably_safe' ? 'Glowing mushrooms give you light.'
      : bs === 'probably_unsafe' ? 'Glowing mushrooms make you heavy.' : 'Not every glowing mushroom is safe. Taste before absorbing.',
    note: bs === 'probably_safe' ? note(s.supportedBy.length) : bs === 'probably_unsafe' ? note(s.contradictedBy.length) : '',
    supportedBy: [...s.supportedBy],
    contradictedBy: [...s.contradictedBy],
  };
  const mushrooms: Record<string, ReturnType<typeof mushroomView>> = {};
  for (const id of LEVEL) mushrooms[id] = mushroomView(s, id);
  return {
    slime: { glowing: s.glow > 0, heavy: s.heavy > 0 },
    mushrooms,
    belief,
    decision: { state: s.decision.state, basis: [...s.decision.basis], reopenedBy: [...s.decision.reopenedBy] },
  };
}

function fail(msg: string): never { throw new Error(msg); }

function target(s: State, e: GlowEvent): { id: string; kind: Kind; m: MushroomState } {
  const id = e.id, kind = e.kind;
  if (typeof id !== 'string' || !Object.hasOwn(s.mushrooms, id)) fail(`unknown mushroom ${String(id)}`);
  if (typeof kind !== 'string' || !KINDS.includes(kind)) fail(`unknown kind ${String(kind)}`);
  const m = s.mushrooms[id];
  if (m.consumed) fail(`${id} already consumed`);
  return { id, kind: kind as Kind, m };
}

function apply(s: State, e: GlowEvent): void {
  if (e === null || typeof e !== 'object') fail('event must be an object');
  switch (e.type) {
    case 'absorb': {
      const { id, kind, m } = target(s, e);
      if (!mushroomView(s, id).canAbsorb) fail(`${id} cannot be absorbed`);
      if (m.tasted !== null && m.tasted !== kind) fail(`${id} kind contradicts its taste`);
      m.consumed = true;
      const ev = `absorb_${id}`;
      if (kind === 'glowcap') { s.glow = GLOW_TIME; s.supportedBy.push(ev); }
      else { s.heavy = HEAVY_TIME; s.contradictedBy.push(ev); }
      if (s.decision.state === 'none' && beliefState(s) === 'probably_safe') {
        s.decision.state = 'committed';
        s.decision.basis = [...s.supportedBy];
      } else if (s.decision.state !== 'none' && kind === 'duskcap') {
        s.decision.state = 'reopened';
        s.decision.reopenedBy.push(ev);
      }
      return;
    }
    case 'taste': {
      const { id, kind, m } = target(s, e);
      if (m.tasted !== null) fail(`${id} already tasted`);
      m.tasted = kind;
      return;
    }
    case 'tick': {
      const dt = e.dt;
      if (typeof dt !== 'number' || !Number.isFinite(dt) || dt < 0 || dt > 0.1) fail(`dt out of range`);
      s.glow = Math.max(0, s.glow - dt);
      s.heavy = Math.max(0, s.heavy - dt);
      return;
    }
    default: fail(`unknown event type ${String(e.type)}`);
  }
}

export function createPolicy(saved?: unknown) {
  let state: State = saved === undefined ? initial() : (structuredClone(saved) as State);
  return {
    dispatch(event: GlowEvent): void {
      const next = structuredClone(state);
      apply(next, event);
      state = next;
    },
    view() { return render(state); },
    save(): unknown { return structuredClone(state); },
  };
}

// Host glue for impl/glowcap.cav. It translates host events into the
// program's events and the program's view into the required view shape.
// Every game decision (what is accepted, labels, belief, trust) is the
// program's; the adapter only renames fields and copies explanations.
import { readFileSync } from 'node:fs';
import { loadRuntimeFromDirectory } from 'caveat-lang/node';

const source = readFileSync(new URL('./glowcap.cav', import.meta.url), 'utf8');
const runtime = await loadRuntimeFromDirectory();
const face = runtime.interface(source);
const mushrooms = face.events.find((e) => e.name === 'absorb')
  .parameters.find((p) => p.name === 'target').members;

function toProgram(event) {
  switch (event.type) {
    case 'absorb':
    case 'taste':
    case 'witness':
      return [event.type, { target: event.id, sort: event.kind }];
    case 'tick':
      return ['tick', { dt: event.dt }];
    default:
      return [event.type, {}];
  }
}

const cited = (explanations, target, property, field) =>
  [...(explanations[target]?.[property]?.[field] ?? [])];
const evidence = (ex, target, property) => cited(ex, target, property, 'evidence');
const caveats = (ex, target, property) => cited(ex, target, property, 'caveats');

function project(v) {
  const b = v.bindings;
  const ex = v.binding_explanations;
  const out = {
    slime: { glowing: b.slime.glowing, heavy: b.slime.heavy, heavySeconds: b.slime.heavy_seconds },
    mushrooms: {},
    belief: {
      state: b.belief.state,
      text: b.belief.text,
      note: b.belief.note,
      supportedBy: evidence(ex, 'belief', 'supported_by'),
      contradictedBy: evidence(ex, 'belief', 'contradicted_by'),
      caveats: caveats(ex, 'belief', 'cited'),
    },
    decision: { state: b.decision.state, basis: [], reopenedBy: [], caveats: [], history: [] },
  };
  for (const id of mushrooms) {
    out.mushrooms[id] = {
      present: b[id].present,
      label: b[id].label,
      canAbsorb: b[id].can_absorb,
      canTaste: b[id].can_taste,
      because: evidence(ex, id, 'label'),
      caveats: caveats(ex, id, 'label'),
    };
  }
  const journal = v.decision_journal.filter((j) => j.decision === 'trust');
  // The current commitment is the latest `committed` entry; what follows it reopened it.
  const last = journal.map((j) => j.change).lastIndexOf('committed');
  if (last >= 0) {
    out.decision.basis = [...journal[last].because];
    out.decision.caveats = [...journal[last].caveats];
    out.decision.reopenedBy = journal.slice(last + 1).flatMap((j) => j.because);
  }
  out.decision.history = journal.map((j) => ({ change: j.change, because: [...j.because] }));
  return out;
}

export function createPolicy(saved) {
  const session = saved === undefined ? runtime.open(source) : runtime.restore(source, saved);
  let current = project(session.view());
  return {
    dispatch(event) {
      const [name, payload] = toProgram(event);
      let outcome;
      try {
        outcome = session.dispatchView(name, payload);
      } catch (error) {
        throw new Error(`event not handled: ${error.message}`);
      }
      if (outcome.outcome !== 'accepted') {
        throw new Error(`rejected (${outcome.origin}/${outcome.code}): ${outcome.message}`);
      }
      current = project(outcome.view);
    },
    view() {
      return structuredClone(current);
    },
    save() {
      return session.save();
    },
  };
}

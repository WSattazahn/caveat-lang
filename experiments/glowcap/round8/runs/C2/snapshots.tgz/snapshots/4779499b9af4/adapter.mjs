// Host glue for impl/glowcap.cav. It translates host events into the
// program's events and the program's view into the required view shape.
// Every game decision (what is accepted, labels, belief, trust) is the
// program's; the adapter only renames fields and copies explanations.
import { readFileSync } from 'node:fs';
import { loadRuntimeFromDirectory } from 'caveat-lang/node';

const source = readFileSync(new URL('./glowcap.cav', import.meta.url), 'utf8');
const runtime = await loadRuntimeFromDirectory();
const face = runtime.interface(source);
const mushrooms = face.events.find((e) => e.name === 'absorb')
  .parameters.find((p) => p.name === 'target').members;

function toProgram(event) {
  switch (event.type) {
    case 'absorb':
    case 'taste':
    case 'witness':
      return [event.type, { target: event.id, sort: event.kind }];
    case 'tick':
      return ['tick', { dt: event.dt }];
    default:
      return [event.type, {}];
  }
}

const cited = (explanations, target, property, field) =>
  [...(explanations[target]?.[property]?.[field] ?? [])];
// The runtime names a renewed occurrence `absorb_cave@2`; the view calls it `absorb_cave_2`.
const occurrence = (name) => name.replace(/@(\d+)$/, '_$1');
const names = (list) => list.map(occurrence);
const evidence = (ex, target, property) => names(cited(ex, target, property, 'evidence'));
const caveats = (ex, target, property) => cited(ex, target, property, 'caveats');

function project(v) {
  const b = v.bindings;
  const ex = v.binding_explanations;
  const out = {
    slime: { glowing: b.slime.glowing, heavy: b.slime.heavy, heavySeconds: b.slime.heavy_seconds },
    mushrooms: {},
    belief: {
      state: b.belief.state,
      text: b.belief.text,
      note: b.belief.note,
      supportedBy: evidence(ex, 'belief', 'supported_by'),
      contradictedBy: evidence(ex, 'belief', 'contradicted_by'),
      caveats: caveats(ex, 'belief', 'cited'),
    },
    decision: { state: b.decision.state, basis: [], reopenedBy: [], caveats: [], history: [] },
  };
  for (const id of mushrooms) {
    out.mushrooms[id] = {
      present: b[id].present,
      label: b[id].label,
      canAbsorb: b[id].can_absorb,
      canTaste: b[id].can_taste,
      because: evidence(ex, id, 'label'),
      caveats: caveats(ex, id, 'label'),
      why: {
        absorb: { reason: b[id].why_absorb, because: evidence(ex, id, 'why_absorb'), caveats: caveats(ex, id, 'why_absorb') },
        taste: { reason: b[id].why_taste, because: evidence(ex, id, 'why_taste'), caveats: caveats(ex, id, 'why_taste') },
      },
    };
  }
  const journal = v.decision_journal.filter((j) => j.decision === 'trust');
  // The revision in force: its frozen grounds (View 0.2 lists them in
  // first-observed order) and the contradictions that reopened it.
  const current = v.decision_series.trust?.current;
  if (current) {
    const grounds = v.commitment_grounds[current];
    out.decision.basis = names(grounds?.evidence ?? []);
    out.decision.caveats = [...(grounds?.caveats ?? [])];
    out.decision.reopenedBy = names(journal
      .filter((j) => j.commitment === current && j.change === 'reopened')
      .flatMap((j) => j.because));
  }
  // The journal keeps its six most recent entries (journal window 6).
  out.decision.history = journal.map((j) => ({ change: j.change, because: names(j.because) }));
  return out;
}

export function createPolicy(saved) {
  // A save is the runtime's save as a JSON value (not a string holding JSON).
  const session = saved === undefined ? runtime.open(source) : runtime.restore(source, JSON.stringify(saved));
  const view = () => project(session.view({ schema: '0.2' }));
  let current = view();
  return {
    dispatch(event) {
      const [name, payload] = toProgram(event);
      let outcome;
      try {
        outcome = session.dispatchView(name, payload);
      } catch (error) {
        throw new Error(`event not handled: ${error.message}`);
      }
      if (outcome.outcome !== 'accepted') {
        throw new Error(`rejected (${outcome.origin}/${outcome.code}): ${outcome.message}`);
      }
      current = view();
    },
    view() {
      return structuredClone(current);
    },
    save() {
      const t = JSON.parse(session.save());
      if (process.env.C2_SIZE) { console.error('SAVE BYTES', JSON.stringify(t).length); const o = t; for (const [k, v] of Object.entries(o)) console.error('  ', k, JSON.stringify(v).length); if (process.env.C2_SIZE === '2') console.error(JSON.stringify(o, null, 1)); }
      return t;
    },
  };
}

// Host glue for impl/glowcap.cav. It translates host events into the
// program's events and the program's view into the required view shape.
// Every game decision (what is accepted, labels, belief, trust) is the
// program's; the adapter only renames fields and copies explanations.
import { readFileSync } from 'node:fs';
import { loadRuntimeFromDirectory } from 'caveat-lang/node';

const source = readFileSync(new URL('./glowcap.cav', import.meta.url), 'utf8');
const runtime = await loadRuntimeFromDirectory();
const face = runtime.interface(source);
const mushrooms = face.events.find((e) => e.name === 'absorb')
  .parameters.find((p) => p.name === 'target').members;

function toProgram(event) {
  switch (event.type) {
    case 'absorb':
    case 'taste':
      return [event.type, { target: event.id, sort: event.kind }];
    case 'tick':
      return ['tick', { dt: event.dt }];
    default:
      return [event.type, {}];
  }
}

const evidence = (explanations, target, property) =>
  [...(explanations[target]?.[property]?.evidence ?? [])];

function project(v) {
  const b = v.bindings;
  const ex = v.binding_explanations;
  const out = {
    slime: { glowing: b.slime.glowing, heavy: b.slime.heavy },
    mushrooms: {},
    belief: {
      state: b.belief.state,
      text: b.belief.text,
      note: b.belief.note,
      supportedBy: evidence(ex, 'belief', 'supported_by'),
      contradictedBy: evidence(ex, 'belief', 'contradicted_by'),
    },
    decision: { state: b.decision.state, basis: [], reopenedBy: [] },
  };
  for (const id of mushrooms) {
    out.mushrooms[id] = {
      present: b[id].present,
      label: b[id].label,
      canAbsorb: b[id].can_absorb,
      canTaste: b[id].can_taste,
      because: evidence(ex, id, 'label'),
    };
  }
  const journal = v.decision_journal.filter((j) => j.decision === 'trust');
  const committed = journal.find((j) => j.change === 'committed');
  if (committed) out.decision.basis = [...(v.commitment_grounds[committed.commitment]?.evidence ?? [])];
  out.decision.reopenedBy = journal.filter((j) => j.change === 'reopened').flatMap((j) => j.because);
  return out;
}

export function createPolicy(saved) {
  const session = saved === undefined ? runtime.open(source) : runtime.restore(source, saved);
  let current = project(session.view());
  return {
    dispatch(event) {
      const [name, payload] = toProgram(event);
      let outcome;
      try {
        outcome = session.dispatchView(name, payload);
      } catch (error) {
        throw new Error(`event not handled: ${error.message}`);
      }
      if (outcome.outcome !== 'accepted') {
        throw new Error(`rejected (${outcome.origin}/${outcome.code}): ${outcome.message}`);
      }
      current = project(outcome.view);
    },
    view() {
      return structuredClone(current);
    },
    save() {
      return session.save();
    },
  };
}

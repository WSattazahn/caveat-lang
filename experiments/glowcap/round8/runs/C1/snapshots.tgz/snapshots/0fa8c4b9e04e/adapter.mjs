// Host glue for impl/glowcap.cav. It translates host events into the program's
// events and projects the program's view into the required shape. Every game
// decision (what is accepted, labels, belief, trust) is made by the program.
import { readFileSync } from 'node:fs';
import { loadRuntimeFromDirectory } from 'caveat-lang/node';

const source = readFileSync(new URL('./glowcap.cav', import.meta.url), 'utf8');
const runtime = await loadRuntimeFromDirectory();
export const ready = Promise.resolve();

// The mushrooms are the program's entities of kind `mushroom`.
const probe = runtime.open(source);
const MUSHROOMS = probe.snapshot().world.entities.filter((e) => e.kind === 'mushroom').map((e) => e.id);
probe.close();

function toProgramEvent(event) {
  const { type, ...rest } = event ?? {};
  if (type === 'absorb' || type === 'taste') {
    const { id, kind, ...extra } = rest;
    return [type, { target: id, sort: kind, ...extra }];
  }
  return [type, rest];
}

const evidence = (explanations, target, property) => [...(explanations[target]?.[property]?.evidence ?? [])];

function project(view) {
  const b = view.bindings;
  const ex = view.binding_explanations;
  const mushrooms = {};
  for (const id of MUSHROOMS) {
    mushrooms[id] = {
      present: b[id].present,
      label: b[id].label,
      canAbsorb: b[id].can_absorb,
      canTaste: b[id].can_taste,
      because: evidence(ex, id, 'label'),
    };
  }
  const series = view.decision_series.trust;
  const current = series?.current ?? null;
  const journal = view.decision_journal.filter((e) => e.decision === 'trust' && e.commitment === current);
  return {
    slime: { glowing: b.slime.glowing, heavy: b.slime.heavy },
    mushrooms,
    belief: {
      state: b.belief.state,
      text: b.belief.text,
      note: b.belief.note,
      supportedBy: evidence(ex, 'belief', 'supported_by'),
      contradictedBy: evidence(ex, 'belief', 'contradicted_by'),
    },
    decision: {
      state: b.decision.state,
      basis: journal.filter((e) => e.change === 'committed').flatMap((e) => e.because),
      reopenedBy: journal.filter((e) => e.change === 'reopened').flatMap((e) => e.because),
    },
  };
}

export function createPolicy(saved) {
  const session = saved === undefined ? runtime.open(source) : runtime.restore(source, saved);
  return {
    dispatch(event) {
      const [name, payload] = toProgramEvent(event);
      const outcome = session.dispatch(name, payload);
      if (outcome.outcome !== 'accepted') {
        throw new Error(`${name} rejected (${outcome.origin}/${outcome.code}): ${outcome.message}`);
      }
    },
    view() {
      return project(session.view({ schema: '0.2' }));
    },
    save() {
      return session.save();
    },
  };
}

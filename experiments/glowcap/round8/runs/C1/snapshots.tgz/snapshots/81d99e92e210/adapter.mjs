// Host glue for impl/glowcap.cav. It translates host events into the program's
// events and projects the program's view into the required shape. Every game
// decision (what is accepted, labels, belief, trust) is made by the program.
import { readFileSync, writeFileSync } from 'node:fs';
import { loadRuntimeFromDirectory } from 'caveat-lang/node';

const source = readFileSync(new URL('./glowcap.cav', import.meta.url), 'utf8');
const runtime = await loadRuntimeFromDirectory();
export const ready = Promise.resolve();

// The mushrooms are the program's entities of kind `mushroom`.
const probe = runtime.open(source);
const MUSHROOMS = probe.snapshot().world.entities.filter((e) => e.kind === 'mushroom').map((e) => e.id);
probe.close();

function toProgramEvent(event) {
  const { type, ...rest } = event ?? {};
  if (type === 'absorb' || type === 'taste' || type === 'witness') {
    const { id, kind, ...extra } = rest;
    return [type, { target: id, sort: kind, ...extra }];
  }
  return [type, rest];
}

// The runtime names a later life's occurrence `absorb_cave@2`; the view calls it `absorb_cave_2`.
const name = (occurrence) => occurrence.replace(/@(\d+)$/, '_$1');
const names = (list) => list.map(name);
const evidence = (explanations, target, property) => names(explanations[target]?.[property]?.evidence ?? []);
const caveats = (explanations, ...cited) => [...new Set(cited.flatMap(([t, p]) => explanations[t]?.[p]?.caveats ?? []))];

function project(view) {
  const b = view.bindings;
  const ex = view.binding_explanations;
  const mushrooms = {};
  for (const id of MUSHROOMS) {
    mushrooms[id] = {
      present: b[id].present,
      label: b[id].label,
      canAbsorb: b[id].can_absorb,
      canTaste: b[id].can_taste,
      because: evidence(ex, id, 'label'),
      caveats: caveats(ex, [id, 'label']),
      why: {
        absorb: { reason: b[id].why_absorb, because: evidence(ex, id, 'why_absorb'), caveats: caveats(ex, [id, 'why_absorb']) },
        taste: { reason: b[id].why_taste, because: evidence(ex, id, 'why_taste'), caveats: caveats(ex, [id, 'why_taste']) },
      },
    };
  }
  const series = view.decision_series.trust;
  const current = series?.current ?? null;
  const journal = view.decision_journal.filter((e) => e.decision === 'trust' && e.commitment === current);
  const committed = journal.filter((e) => e.change === 'committed');
  return {
    slime: { glowing: b.slime.glowing, heavy: b.slime.heavy, heavySeconds: b.slime.heavy_seconds },
    mushrooms,
    belief: {
      state: b.belief.state,
      text: b.belief.text,
      note: b.belief.note,
      supportedBy: evidence(ex, 'belief', 'supported_by'),
      contradictedBy: evidence(ex, 'belief', 'contradicted_by'),
      caveats: caveats(ex, ['belief', 'supported_by'], ['belief', 'contradicted_by']),
    },
    decision: {
      state: b.decision.state,
      basis: names(committed.flatMap((e) => e.because)),
      // The caveats the basis carried when it was committed (the journal keeps them frozen).
      caveats: [...new Set(committed.flatMap((e) => e.caveats))],
      reopenedBy: names(journal.filter((e) => e.change === 'reopened').flatMap((e) => e.because)),
      // The runtime's decision journal for trust, in order.
      history: view.decision_journal.filter((e) => e.decision === 'trust')
        .map((e) => ({ change: e.change, because: names(e.because) })),
    },
  };
}

export function createPolicy(saved) {
  const session = saved === undefined ? runtime.open(source) : runtime.restore(source, saved);
  return {
    dispatch(event) {
      const [eventName, payload] = toProgramEvent(event);
      const outcome = session.dispatch(eventName, payload);
      if (outcome.outcome !== 'accepted') {
        throw new Error(`${eventName} rejected (${outcome.origin}/${outcome.code}): ${outcome.message}`);
      }
    },
    view() {
      return project(session.view({ schema: '0.2' }));
    },
    save() {
      if (process.env.C1_DUMP) writeFileSync(process.env.C1_DUMP, session.save());
      return session.save();
    },
  };
}

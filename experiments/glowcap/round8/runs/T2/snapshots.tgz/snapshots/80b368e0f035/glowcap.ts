// Glowcap beat policy. State is plain JSON data; the view is derived from it.

type Kind = 'glowcap' | 'duskcap';

interface MushroomState {
  consumed: boolean;
  tasted: Kind | null;
}

interface State {
  glow: number;
  heavy: number;
  mushrooms: Record<string, MushroomState>;
  // Absorptions in order; evidence id is absorb_<id>.
  absorptions: { id: string; kind: Kind }[];
  decision: { state: 'none' | 'committed' | 'reopened'; basis: string[]; reopenedBy: string[] };
}

const LEVEL = ['cave', 'pool', 'ruin'];
const GLOW_SECONDS = 30;
const HEAVY_SECONDS = 20;

function initialState(): State {
  const mushrooms: Record<string, MushroomState> = {};
  for (const id of LEVEL) mushrooms[id] = { consumed: false, tasted: null };
  return {
    glow: 0,
    heavy: 0,
    mushrooms,
    absorptions: [],
    decision: { state: 'none', basis: [], reopenedBy: [] },
  };
}

function clone<T>(v: T): T {
  return JSON.parse(JSON.stringify(v)) as T;
}

function isKind(k: unknown): k is Kind {
  return k === 'glowcap' || k === 'duskcap';
}

function evidence(s: State) {
  const supportedBy = s.absorptions.filter((a) => a.kind === 'glowcap').map((a) => `absorb_${a.id}`);
  const contradictedBy = s.absorptions.filter((a) => a.kind === 'duskcap').map((a) => `absorb_${a.id}`);
  const all = s.absorptions.map((a) => `absorb_${a.id}`);
  return { supportedBy, contradictedBy, all };
}

type BeliefState = 'none' | 'probably_safe' | 'probably_unsafe' | 'uncertain';

function beliefState(sup: number, con: number): BeliefState {
  if (sup === 0 && con === 0) return 'none';
  if (con === 0) return 'probably_safe';
  if (sup === 0) return 'probably_unsafe';
  return 'uncertain';
}

function observations(n: number): string {
  return n === 1 ? 'Based on one observation.' : `Based on ${n} observations.`;
}

function canAbsorb(s: State, id: string): boolean {
  const m = s.mushrooms[id];
  if (m.consumed) return false;
  if (m.tasted === 'duskcap') return false;
  return true;
}

function viewOf(s: State) {
  const { supportedBy, contradictedBy, all } = evidence(s);
  const bs = beliefState(supportedBy.length, contradictedBy.length);
  let text = '';
  let note = '';
  if (bs === 'probably_safe') {
    text = 'Glowing mushrooms give you light.';
    note = observations(supportedBy.length);
  } else if (bs === 'probably_unsafe') {
    text = 'Glowing mushrooms make you heavy.';
    note = observations(contradictedBy.length);
  } else if (bs === 'uncertain') {
    text = 'Not every glowing mushroom is safe. Taste before absorbing.';
  }

  const mushrooms: Record<string, { present: boolean; label: string; canAbsorb: boolean; canTaste: boolean; because: string[] }> = {};
  for (const id of Object.keys(s.mushrooms)) {
    const m = s.mushrooms[id];
    if (m.consumed) {
      mushrooms[id] = { present: false, label: '', canAbsorb: false, canTaste: false, because: [] };
    } else if (m.tasted === 'glowcap') {
      mushrooms[id] = { present: true, label: 'Glowcap', canAbsorb: true, canTaste: false, because: [`taste_${id}`] };
    } else if (m.tasted === 'duskcap') {
      mushrooms[id] = { present: true, label: 'Duskcap — avoid', canAbsorb: false, canTaste: false, because: [`taste_${id}`] };
    } else {
      const label =
        bs === 'none'
          ? 'Glowing mushroom'
          : bs === 'probably_safe'
            ? 'Probably a glowcap'
            : bs === 'probably_unsafe'
              ? 'Probably a duskcap'
              : 'Could be a duskcap — taste first';
      const because = bs === 'none' ? [] : bs === 'probably_safe' ? supportedBy : bs === 'probably_unsafe' ? contradictedBy : all;
      mushrooms[id] = { present: true, label, canAbsorb: true, canTaste: true, because: [...because] };
    }
  }

  return {
    slime: { glowing: s.glow > 0, heavy: s.heavy > 0 },
    mushrooms,
    belief: { state: bs, text, note, supportedBy, contradictedBy },
    decision: { state: s.decision.state, basis: [...s.decision.basis], reopenedBy: [...s.decision.reopenedBy] },
  };
}

function requireMushroom(s: State, id: unknown): MushroomState {
  if (typeof id !== 'string' || !Object.prototype.hasOwnProperty.call(s.mushrooms, id)) {
    throw new Error(`unknown mushroom: ${String(id)}`);
  }
  return s.mushrooms[id];
}

// Applies an event to s in place; throws on rejection (caller discards s).
function apply(s: State, event: Record<string, unknown>): void {
  switch (event.type) {
    case 'absorb': {
      const id = event.id as string;
      const m = requireMushroom(s, event.id);
      const kind = event.kind;
      if (!isKind(kind)) throw new Error(`unknown kind: ${String(kind)}`);
      if (m.consumed) throw new Error(`${id} already consumed`);
      if (!canAbsorb(s, id)) throw new Error(`${id} may not be absorbed`);
      if (m.tasted !== null && m.tasted !== kind) throw new Error(`${id} was tasted as ${m.tasted}`);
      const before = evidence(s);
      const beforeState = beliefState(before.supportedBy.length, before.contradictedBy.length);
      m.consumed = true;
      s.absorptions.push({ id, kind });
      if (kind === 'glowcap') s.glow = GLOW_SECONDS;
      else s.heavy = HEAVY_SECONDS;
      const after = evidence(s);
      const afterState = beliefState(after.supportedBy.length, after.contradictedBy.length);
      if (s.decision.state === 'none' && beforeState !== 'probably_safe' && afterState === 'probably_safe') {
        // Basis: the evidence that made the belief probably_safe (frozen).
        s.decision = { state: 'committed', basis: [...after.supportedBy], reopenedBy: [] };
      } else if (s.decision.state !== 'none' && kind === 'duskcap') {
        s.decision.state = 'reopened';
        s.decision.reopenedBy.push(`absorb_${id}`);
      }
      return;
    }
    case 'taste': {
      const id = event.id as string;
      const m = requireMushroom(s, event.id);
      const kind = event.kind;
      if (!isKind(kind)) throw new Error(`unknown kind: ${String(kind)}`);
      if (m.consumed) throw new Error(`${id} already consumed`);
      if (m.tasted !== null) throw new Error(`${id} already tasted`);
      m.tasted = kind;
      return;
    }
    case 'tick': {
      const dt = event.dt;
      if (typeof dt !== 'number' || !Number.isFinite(dt) || dt < 0 || dt > 0.1) {
        throw new Error(`dt out of range: ${String(dt)}`);
      }
      s.glow = Math.max(0, s.glow - dt);
      s.heavy = Math.max(0, s.heavy - dt);
      return;
    }
    default:
      throw new Error(`unknown event type: ${String(event.type)}`);
  }
}

export function createPolicy(saved?: unknown) {
  let state: State = saved === undefined ? initialState() : clone(saved as State);
  return {
    dispatch(event: unknown): void {
      if (typeof event !== 'object' || event === null) throw new Error('event must be an object');
      const next = clone(state);
      apply(next, event as Record<string, unknown>);
      state = next;
    },
    view() {
      return viewOf(state);
    },
    save(): unknown {
      return clone(state);
    },
  };
}

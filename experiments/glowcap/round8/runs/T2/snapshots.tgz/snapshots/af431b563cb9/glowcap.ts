// Glowcap beat policy. State is plain JSON data; the view is derived from it.

type Kind = 'glowcap' | 'duskcap';

interface MushroomState {
  consumed: boolean;
  tasted: Kind | null;
}

// One piece of evidence about glowing mushrooms, in the order it was observed.
interface Evidence {
  id: string; // absorb_<mushroom> or taste_<mushroom>
  kind: Kind; // glowcap supports the belief, duskcap contradicts it
  caveats: string[];
  age?: number; // tastes only: seconds of ticks since the taste
}

interface State {
  glow: number;
  heavy: number;
  mushrooms: Record<string, MushroomState>;
  evidence: Evidence[];
  decision: {
    state: 'none' | 'committed' | 'reopened';
    basis: string[];
    reopenedBy: string[];
    caveats: string[]; // caveats the basis carried when committed (frozen)
    history: { change: 'committed' | 'reopened'; because: string[] }[];
  };
}

const LEVEL = ['cave', 'pool', 'ruin', 'grove'];
const GLOW_SECONDS = 30;
const HEAVY_SECONDS = 20;
const TASTED_IN_DARK = 'tasted_in_dark';
const TASTE_FADED = 'taste_faded';
const TASTE_FADE_SECONDS = 60;

function initialState(): State {
  const mushrooms: Record<string, MushroomState> = {};
  for (const id of LEVEL) mushrooms[id] = { consumed: false, tasted: null };
  return {
    glow: 0,
    heavy: 0,
    mushrooms,
    evidence: [],
    decision: { state: 'none', basis: [], reopenedBy: [], caveats: [], history: [] },
  };
}

function clone<T>(v: T): T {
  return JSON.parse(JSON.stringify(v)) as T;
}

function isKind(k: unknown): k is Kind {
  return k === 'glowcap' || k === 'duskcap';
}

function split(s: State) {
  const supportedBy = s.evidence.filter((e) => e.kind === 'glowcap').map((e) => e.id);
  const contradictedBy = s.evidence.filter((e) => e.kind === 'duskcap').map((e) => e.id);
  const all = s.evidence.map((e) => e.id);
  return { supportedBy, contradictedBy, all };
}

// Union of the caveats carried by the cited evidence, in first-seen order.
function caveatsOf(s: State, ids: string[]): string[] {
  const out: string[] = [];
  for (const id of ids) {
    const e = s.evidence.find((x) => x.id === id);
    if (!e) continue;
    for (const c of e.caveats) if (!out.includes(c)) out.push(c);
  }
  return out;
}

type BeliefState = 'none' | 'probably_safe' | 'probably_unsafe' | 'uncertain';

function beliefState(sup: number, con: number): BeliefState {
  if (sup === 0 && con === 0) return 'none';
  if (con === 0) return 'probably_safe';
  if (sup === 0) return 'probably_unsafe';
  return 'uncertain';
}

function currentBelief(s: State): BeliefState {
  const { supportedBy, contradictedBy } = split(s);
  return beliefState(supportedBy.length, contradictedBy.length);
}

function observations(n: number): string {
  return n === 1 ? 'Based on one observation.' : `Based on ${n} observations.`;
}

interface MushroomRow {
  present: boolean;
  label: string;
  canAbsorb: boolean;
  canTaste: boolean;
  because: string[];
  caveats: string[];
}

function row(s: State, present: boolean, label: string, canAbsorb: boolean, canTaste: boolean, because: string[]): MushroomRow {
  return { present, label, canAbsorb, canTaste, because: [...because], caveats: caveatsOf(s, because) };
}

// The single source of truth for what the HUD shows and allows for one mushroom.
function mushroomRow(s: State, id: string): MushroomRow {
  const m = s.mushrooms[id];
  if (m.consumed) return row(s, false, '', false, false, []);
  if (m.tasted !== null) {
    const because = [`taste_${id}`];
    const cav = caveatsOf(s, because);
    // CR5: the faded label wins over the dark label.
    const qualifier = cav.includes(TASTE_FADED) ? ' (taste has faded)' : cav.includes(TASTED_IN_DARK) ? ' (tasted in the dark)' : null;
    if (m.tasted === 'glowcap') {
      return row(s, true, qualifier ? `Probably a glowcap${qualifier}` : 'Glowcap', true, false, because);
    }
    return row(s, true, qualifier ? `Probably a duskcap${qualifier}` : 'Duskcap — avoid', false, false, because);
  }
  const { supportedBy, contradictedBy} = split(s);
  // CR2: twice bitten.
  if (contradictedBy.length >= 2) return row(s, true, 'Too risky — taste first', false, true, contradictedBy);
  const bs = beliefState(supportedBy.length, contradictedBy.length);
  if (bs === 'none') return row(s, true, 'Glowing mushroom', true, true, []);
  if (bs === 'probably_safe') return row(s, true, 'Probably a glowcap', true, true, supportedBy);
  if (bs === 'probably_unsafe') return row(s, true, 'Probably a duskcap', true, true, contradictedBy);
  // CR4: cite the counterexample only.
  return row(s, true, 'Could be a duskcap — taste first', true, true, contradictedBy);
}

function viewOf(s: State) {
  const { supportedBy, contradictedBy, all } = split(s);
  const bs = beliefState(supportedBy.length, contradictedBy.length);
  let text = '';
  let note = '';
  if (bs === 'probably_safe') {
    text = 'Glowing mushrooms give you light.';
    note = observations(supportedBy.length);
  } else if (bs === 'probably_unsafe') {
    text = 'Glowing mushrooms make you heavy.';
    note = observations(contradictedBy.length);
  } else if (bs === 'uncertain') {
    text = 'Not every glowing mushroom is safe. Taste before absorbing.';
  }

  const mushrooms: Record<string, MushroomRow> = {};
  for (const id of Object.keys(s.mushrooms)) mushrooms[id] = mushroomRow(s, id);

  return {
    slime: { glowing: s.glow > 0, heavy: s.heavy > 0 },
    mushrooms,
    belief: { state: bs, text, note, supportedBy, contradictedBy, caveats: caveatsOf(s, all) },
    decision: {
      state: s.decision.state,
      basis: [...s.decision.basis],
      reopenedBy: [...s.decision.reopenedBy],
      caveats: [...s.decision.caveats],
      history: s.decision.history.map((h) => ({ change: h.change, because: [...h.because] })),
    },
  };
}

// Records new evidence and updates the trust decision.
function commit(s: State, basis: string[]): void {
  s.decision = {
    state: 'committed',
    basis: [...basis],
    reopenedBy: [],
    caveats: caveatsOf(s, basis),
    history: [...s.decision.history, { change: 'committed', because: [...basis] }],
  };
}

const RECOVERY_COUNT = 2;

function observe(s: State, e: Evidence): void {
  const before = currentBelief(s);
  s.evidence.push(e);
  const after = currentBelief(s);
  if (s.decision.state === 'none') {
    if (before !== 'probably_safe' && after === 'probably_safe') {
      // Basis: the evidence that made the belief probably_safe; frozen from now on.
      commit(s, split(s).supportedBy);
    }
  } else if (e.kind === 'duskcap') {
    s.decision.state = 'reopened';
    s.decision.reopenedBy.push(e.id);
    s.decision.history.push({ change: 'reopened', because: [e.id] });
  } else if (s.decision.state === 'reopened') {
    // CR7: the second glowcap observation since the most recent contradiction recommits.
    let lastContradiction = -1;
    s.evidence.forEach((x, i) => {
      if (x.kind === 'duskcap') lastContradiction = i;
    });
    const since = s.evidence.slice(lastContradiction + 1).filter((x) => x.kind === 'glowcap');
    if (since.length >= RECOVERY_COUNT) commit(s, since.slice(0, RECOVERY_COUNT).map((x) => x.id));
  }
}

function requireMushroom(s: State, id: unknown): MushroomState {
  if (typeof id !== 'string' || !Object.prototype.hasOwnProperty.call(s.mushrooms, id)) {
    throw new Error(`unknown mushroom: ${String(id)}`);
  }
  return s.mushrooms[id];
}

// Applies an event to s in place; throws on rejection (caller discards s).
function apply(s: State, event: Record<string, unknown>): void {
  switch (event.type) {
    case 'absorb': {
      const id = event.id as string;
      const m = requireMushroom(s, event.id);
      const kind = event.kind;
      if (!isKind(kind)) throw new Error(`unknown kind: ${String(kind)}`);
      if (m.consumed) throw new Error(`${id} already consumed`);
      if (!mushroomRow(s, id).canAbsorb) throw new Error(`${id} may not be absorbed`);
      if (m.tasted !== null && m.tasted !== kind) throw new Error(`${id} was tasted as ${m.tasted}`);
      m.consumed = true;
      if (kind === 'glowcap') s.glow = GLOW_SECONDS;
      else s.heavy = HEAVY_SECONDS;
      observe(s, { id: `absorb_${id}`, kind, caveats: [] });
      return;
    }
    case 'taste': {
      const id = event.id as string;
      const m = requireMushroom(s, event.id);
      const kind = event.kind;
      if (!isKind(kind)) throw new Error(`unknown kind: ${String(kind)}`);
      if (m.consumed) throw new Error(`${id} already consumed`);
      if (m.tasted !== null) throw new Error(`${id} already tasted`);
      m.tasted = kind;
      const caveats = s.glow > 0 ? [] : [TASTED_IN_DARK];
      observe(s, { id: `taste_${id}`, kind, caveats, age: 0 });
      return;
    }
    case 'tick': {
      const dt = event.dt;
      if (typeof dt !== 'number' || !Number.isFinite(dt) || dt < 0 || dt > 0.1) {
        throw new Error(`dt out of range: ${String(dt)}`);
      }
      s.glow = Math.max(0, s.glow - dt);
      s.heavy = Math.max(0, s.heavy - dt);
      for (const e of s.evidence) {
        if (e.age === undefined) continue;
        e.age += dt;
        if (e.age >= TASTE_FADE_SECONDS && !e.caveats.includes(TASTE_FADED)) e.caveats.push(TASTE_FADED);
      }
      return;
    }
    default:
      throw new Error(`unknown event type: ${String(event.type)}`);
  }
}

export function createPolicy(saved?: unknown) {
  let state: State = saved === undefined ? initialState() : clone(saved as State);
  return {
    dispatch(event: unknown): void {
      if (typeof event !== 'object' || event === null) throw new Error('event must be an object');
      const next = clone(state);
      apply(next, event as Record<string, unknown>);
      state = next;
    },
    view() {
      return viewOf(state);
    },
    save(): unknown {
      return clone(state);
    },
  };
}

// Glowcap beat policy.

export type Kind = 'glowcap' | 'duskcap';

const LEVEL: readonly string[] = ['cave', 'pool', 'ruin', 'grove'];
const KINDS: readonly string[] = ['glowcap', 'duskcap'];
const GLOW_SECONDS = 30;
const HEAVY_SECONDS = 20;
const MAX_DT = 0.1;

interface MushroomState {
  consumed: boolean;
  tasted: Kind | null;
}

interface State {
  glow: number;
  heavy: number;
  mushrooms: Record<string, MushroomState>;
  supportedBy: string[];
  contradictedBy: string[];
  decision: { state: 'none' | 'committed' | 'reopened'; basis: string[]; reopenedBy: string[] };
}

export type BeliefState = 'none' | 'probably_safe' | 'probably_unsafe' | 'uncertain';

export interface MushroomView {
  present: boolean;
  label: string;
  canAbsorb: boolean;
  canTaste: boolean;
  because: string[];
}

export interface View {
  slime: { glowing: boolean; heavy: boolean };
  mushrooms: Record<string, MushroomView>;
  belief: { state: BeliefState; text: string; note: string; supportedBy: string[]; contradictedBy: string[] };
  decision: { state: 'none' | 'committed' | 'reopened'; basis: string[]; reopenedBy: string[] };
}

export type GlowEvent =
  | { type: 'absorb'; id: string; kind: string }
  | { type: 'taste'; id: string; kind: string }
  | { type: 'tick'; dt: number };

function initialState(): State {
  const mushrooms: Record<string, MushroomState> = {};
  for (const id of LEVEL) mushrooms[id] = { consumed: false, tasted: null };
  return {
    glow: 0,
    heavy: 0,
    mushrooms,
    supportedBy: [],
    contradictedBy: [],
    decision: { state: 'none', basis: [], reopenedBy: [] },
  };
}

function clone<T>(v: T): T {
  return JSON.parse(JSON.stringify(v)) as T;
}

function beliefState(s: State): BeliefState {
  const sup = s.supportedBy.length > 0;
  const con = s.contradictedBy.length > 0;
  if (sup && con) return 'uncertain';
  if (sup) return 'probably_safe';
  if (con) return 'probably_unsafe';
  return 'none';
}

function note(n: number): string {
  return n === 1 ? 'Based on one observation.' : `Based on ${n} observations.`;
}

function fail(msg: string): never {
  throw new Error(msg);
}

function checkMushroom(s: State, e: { id?: unknown; kind?: unknown }): { m: MushroomState; id: string; kind: Kind } {
  if (typeof e.id !== 'string' || !Object.hasOwn(s.mushrooms, e.id)) fail(`unknown mushroom ${String(e.id)}`);
  if (typeof e.kind !== 'string' || !KINDS.includes(e.kind)) fail(`unknown kind ${String(e.kind)}`);
  const m = s.mushrooms[e.id as string]!;
  if (m.consumed) fail(`mushroom ${e.id as string} already consumed`);
  return { m, id: e.id as string, kind: e.kind as Kind };
}

function canAbsorb(s: State, m: MushroomState): boolean {
  if (m.consumed) return false;
  if (m.tasted === 'duskcap') return false;
  return true;
}

// Applies an event to a state in place. Throws (before or after partial mutation)
// on rejection; the caller discards the working copy in that case.
function apply(s: State, e: GlowEvent): void {
  if (e === null || typeof e !== 'object') fail('event must be an object');
  switch (e.type) {
    case 'tick': {
      const dt = e.dt;
      if (typeof dt !== 'number' || !Number.isFinite(dt) || dt < 0 || dt > MAX_DT) fail(`dt out of range: ${String(dt)}`);
      s.glow = Math.max(0, s.glow - dt);
      s.heavy = Math.max(0, s.heavy - dt);
      return;
    }
    case 'taste': {
      const { m } = checkMushroom(s, e);
      if (m.tasted !== null) fail(`mushroom ${e.id} already tasted`);
      m.tasted = e.kind as Kind;
      return;
    }
    case 'absorb': {
      const { m, id, kind } = checkMushroom(s, e);
      if (!canAbsorb(s, m)) fail(`cannot absorb ${id}`);
      if (m.tasted !== null && m.tasted !== kind) fail(`kind contradicts taste of ${id}`);
      m.consumed = true;
      const ev = `absorb_${id}`;
      if (kind === 'glowcap') {
        s.glow = GLOW_SECONDS;
        s.supportedBy.push(ev);
        if (s.decision.state === 'none' && beliefState(s) === 'probably_safe') {
          s.decision = { state: 'committed', basis: [...s.supportedBy], reopenedBy: [] };
        }
      } else {
        s.heavy = HEAVY_SECONDS;
        s.contradictedBy.push(ev);
        if (s.decision.state !== 'none') {
          s.decision.state = 'reopened';
          s.decision.reopenedBy.push(ev);
        }
      }
      return;
    }
    default:
      fail(`unknown event type ${String((e as { type?: unknown }).type)}`);
  }
}

function render(s: State): View {
  const bs = beliefState(s);
  const sup = [...s.supportedBy];
  const con = [...s.contradictedBy];
  const belief = {
    state: bs,
    text:
      bs === 'probably_safe'
        ? 'Glowing mushrooms give you light.'
        : bs === 'probably_unsafe'
          ? 'Glowing mushrooms make you heavy.'
          : bs === 'uncertain'
            ? 'Not every glowing mushroom is safe. Taste before absorbing.'
            : '',
    note: bs === 'probably_safe' ? note(sup.length) : bs === 'probably_unsafe' ? note(con.length) : '',
    supportedBy: sup,
    contradictedBy: con,
  };
  const mushrooms: Record<string, MushroomView> = {};
  for (const id of LEVEL) {
    const m = s.mushrooms[id]!;
    let v: MushroomView;
    if (m.consumed) v = { present: false, label: '', canAbsorb: false, canTaste: false, because: [] };
    else if (m.tasted === 'glowcap') v = { present: true, label: 'Glowcap', canAbsorb: true, canTaste: false, because: [`taste_${id}`] };
    else if (m.tasted === 'duskcap') v = { present: true, label: 'Duskcap — avoid', canAbsorb: false, canTaste: false, because: [`taste_${id}`] };
    else if (bs === 'none') v = { present: true, label: 'Glowing mushroom', canAbsorb: true, canTaste: true, because: [] };
    else if (bs === 'probably_safe') v = { present: true, label: 'Probably a glowcap', canAbsorb: true, canTaste: true, because: [...sup] };
    else if (bs === 'probably_unsafe') v = { present: true, label: 'Probably a duskcap', canAbsorb: true, canTaste: true, because: [...con] };
    else v = { present: true, label: 'Could be a duskcap — taste first', canAbsorb: true, canTaste: true, because: [...sup, ...con] };
    mushrooms[id] = v;
  }
  return {
    slime: { glowing: s.glow > 0, heavy: s.heavy > 0 },
    mushrooms,
    belief,
    decision: { state: s.decision.state, basis: [...s.decision.basis], reopenedBy: [...s.decision.reopenedBy] },
  };
}

export function createPolicy(saved?: unknown) {
  let state: State = saved === undefined ? initialState() : clone(saved as State);
  return {
    dispatch(event: GlowEvent): void {
      const next = clone(state);
      apply(next, event);
      state = next;
    },
    view(): View {
      return render(state);
    },
    save(): unknown {
      return clone(state);
    },
  };
}

// Glowcap beat policy.

export type Kind = 'glowcap' | 'duskcap';

const LEVEL: readonly string[] = ['cave', 'pool', 'ruin', 'grove'];
const KINDS: readonly string[] = ['glowcap', 'duskcap'];
const GLOW_SECONDS = 30;
const HEAVY_SECONDS = 20;
const HEAVY_MAX = 30;
const MAX_DT = 0.1;
const REGROW_SECONDS = 45;
// CR10: declared capacity of lives per mushroom (spec requires at least 64).
export const MAX_LIVES = 1024;
const DARK = 'tasted_in_dark';
const FADED = 'taste_faded';
const SECONDHAND = 'secondhand';
const FADE_SECONDS = 60;
// Tolerance so that e.g. 600 ticks of 0.1 s count as a full minute despite float rounding.
const EPS = 1e-9;

interface MushroomState {
  consumed: boolean;
  // CR10: 1-based life number of the current (or last consumed) mushroom.
  life: number;
  // CR10: seconds (sum of tick dt) since this life was consumed.
  consumedAge: number;
  // CR11: evidence that consumed the current life (null while present).
  consumedBy: string | null;
  tasted: Kind | null;
}

interface State {
  glow: number;
  heavy: number;
  mushrooms: Record<string, MushroomState>;
  supportedBy: string[];
  contradictedBy: string[];
  // CR3: caveats carried by each evidence id.
  evidenceCaveats: Record<string, string[]>;
  // CR5: seconds elapsed (sum of tick dt) since each taste.
  tasteAge: Record<string, number>;
  // CR7: glowcap observations since the most recent contradiction.
  sinceContradiction: string[];
  // caveats: frozen at commit time (CR5).
  decision: { state: 'none' | 'committed' | 'reopened'; basis: string[]; reopenedBy: string[]; caveats: string[]; history: HistoryEntry[] };
}

export interface HistoryEntry {
  change: 'committed' | 'reopened';
  because: string[];
}

export type BeliefState = 'none' | 'probably_safe' | 'probably_unsafe' | 'uncertain';

export interface MushroomView {
  present: boolean;
  label: string;
  canAbsorb: boolean;
  canTaste: boolean;
  because: string[];
  caveats: string[];
  why: { absorb: WhyView; taste: WhyView };
}

export interface WhyView {
  reason: string;
  because: string[];
  caveats: string[];
}

export interface View {
  slime: { glowing: boolean; heavy: boolean; heavySeconds: number };
  mushrooms: Record<string, MushroomView>;
  belief: { state: BeliefState; text: string; note: string; supportedBy: string[]; contradictedBy: string[]; caveats: string[] };
  decision: { state: 'none' | 'committed' | 'reopened'; basis: string[]; reopenedBy: string[]; caveats: string[]; history: HistoryEntry[] };
}

export type GlowEvent =
  | { type: 'absorb'; id: string; kind: string }
  | { type: 'taste'; id: string; kind: string }
  | { type: 'witness'; id: string; kind: string }
  | { type: 'tick'; dt: number };

function initialState(): State {
  const mushrooms: Record<string, MushroomState> = {};
  for (const id of LEVEL) mushrooms[id] = { consumed: false, life: 1, consumedAge: 0, consumedBy: null, tasted: null };
  return {
    glow: 0,
    heavy: 0,
    mushrooms,
    supportedBy: [],
    contradictedBy: [],
    evidenceCaveats: {},
    tasteAge: {},
    sinceContradiction: [],
    decision: { state: 'none', basis: [], reopenedBy: [], caveats: [], history: [] },
  };
}

function clone<T>(v: T): T {
  return JSON.parse(JSON.stringify(v)) as T;
}

function beliefState(s: State): BeliefState {
  const sup = s.supportedBy.length > 0;
  const con = s.contradictedBy.length > 0;
  if (sup && con) return 'uncertain';
  if (sup) return 'probably_safe';
  if (con) return 'probably_unsafe';
  return 'none';
}

function note(n: number): string {
  return n === 1 ? 'Based on one observation.' : `Based on ${n} observations.`;
}

function fail(msg: string): never {
  throw new Error(msg);
}

function checkMushroom(s: State, e: { id?: unknown; kind?: unknown }): { m: MushroomState; id: string; kind: Kind } {
  if (typeof e.id !== 'string' || !Object.hasOwn(s.mushrooms, e.id)) fail(`unknown mushroom ${String(e.id)}`);
  if (typeof e.kind !== 'string' || !KINDS.includes(e.kind)) fail(`unknown kind ${String(e.kind)}`);
  const m = s.mushrooms[e.id as string]!;
  if (m.consumed) fail(`mushroom ${e.id as string} already consumed`);
  return { m, id: e.id as string, kind: e.kind as Kind };
}

// Rules for one mushroom, shared by the view and by absorb validation.
// CR10: evidence id for the current life of a mushroom.
function evidenceId(prefix: 'absorb' | 'taste' | 'witness', id: string, life: number): string {
  return life === 1 ? `${prefix}_${id}` : `${prefix}_${id}_${life}`;
}

function caveatsOf(s: State, evidence: readonly string[]): string[] {
  const out = new Set<string>();
  for (const ev of evidence) for (const c of s.evidenceCaveats[ev] ?? []) out.add(c);
  return [...out];
}

function mushroomView(s: State, id: string): MushroomView {
  const v = mushroomRule(s, id);
  return { ...v, caveats: caveatsOf(s, v.because), why: whyNot(s, id) };
}

// CR11: why an action is not allowed (first match), or reason '' when allowed.
function whyNot(s: State, id: string): { absorb: WhyView; taste: WhyView } {
  const m = s.mushrooms[id]!;
  const mk = (reason: string, because: string[]): WhyView => ({ reason, because, caveats: caveatsOf(s, because) });
  const allowed = mk('', []);
  const tasteEv = evidenceId('taste', id, m.life);
  if (m.consumed) {
    const by = m.consumedBy !== null ? [m.consumedBy] : [];
    return { absorb: mk('Already eaten', by), taste: mk('Already eaten', [...by]) };
  }
  let absorb = allowed;
  if (m.tasted === 'duskcap') absorb = mk('Known duskcap', [tasteEv]);
  else if (m.tasted === null && s.contradictedBy.length >= 2) absorb = mk('Too risky untasted', [...s.contradictedBy]);
  const taste = m.tasted !== null ? mk('Already tasted', [tasteEv]) : mk('', []);
  return { absorb, taste };
}

function mushroomRule(s: State, id: string): Omit<MushroomView, 'caveats' | 'why'> {
  const m = s.mushrooms[id]!;
  const bs = beliefState(s);
  const sup = s.supportedBy;
  const con = s.contradictedBy;
  const tasteEv = evidenceId('taste', id, m.life);
  const tc = s.evidenceCaveats[tasteEv] ?? [];
  const dark = tc.includes(DARK);
  const faded = tc.includes(FADED);
  const qual = faded ? ' (taste has faded)' : dark ? ' (tasted in the dark)' : '';
  if (m.consumed) return { present: false, label: '', canAbsorb: false, canTaste: false, because: [] };
  if (m.tasted === 'glowcap')
    return { present: true, label: qual ? `Probably a glowcap${qual}` : 'Glowcap', canAbsorb: true, canTaste: false, because: [tasteEv] };
  if (m.tasted === 'duskcap')
    return { present: true, label: qual ? `Probably a duskcap${qual}` : 'Duskcap — avoid', canAbsorb: false, canTaste: false, because: [tasteEv] };
  // CR2: twice bitten.
  if (con.length >= 2) return { present: true, label: 'Too risky — taste first', canAbsorb: false, canTaste: true, because: [...con] };
  if (bs === 'none') return { present: true, label: 'Glowing mushroom', canAbsorb: true, canTaste: true, because: [] };
  if (bs === 'probably_safe') return { present: true, label: 'Probably a glowcap', canAbsorb: true, canTaste: true, because: [...sup] };
  if (bs === 'probably_unsafe') return { present: true, label: 'Probably a duskcap', canAbsorb: true, canTaste: true, because: [...con] };
  // CR4: cite the counterexample only.
  return { present: true, label: 'Could be a duskcap — taste first', canAbsorb: true, canTaste: true, because: [...con] };
}

// Adds one piece of evidence to the belief and updates the trust decision.
function commit(s: State, basis: string[]): void {
  s.decision = {
    state: 'committed',
    basis: [...basis],
    reopenedBy: [],
    caveats: caveatsOf(s, basis),
    history: [...s.decision.history, { change: 'committed', because: [...basis] }],
  };
}

function record(s: State, ev: string, kind: Kind): void {
  if (kind === 'glowcap') {
    s.supportedBy.push(ev);
    s.sinceContradiction.push(ev);
    if (s.decision.state === 'none' && beliefState(s) === 'probably_safe') {
      commit(s, s.supportedBy);
    } else if (s.decision.state === 'reopened' && s.sinceContradiction.length >= 2) {
      // CR7: trust recovers on the second glowcap observation since the latest contradiction.
      commit(s, s.sinceContradiction.slice(0, 2));
    }
  } else {
    s.contradictedBy.push(ev);
    s.sinceContradiction = [];
    if (s.decision.state !== 'none') {
      s.decision.state = 'reopened';
      s.decision.reopenedBy.push(ev);
      s.decision.history.push({ change: 'reopened', because: [ev] });
    }
  }
}

// Applies an event to a state in place. Throws (before or after partial mutation)
// on rejection; the caller discards the working copy in that case.
function apply(s: State, e: GlowEvent): void {
  if (e === null || typeof e !== 'object') fail('event must be an object');
  switch (e.type) {
    case 'tick': {
      const dt = e.dt;
      if (typeof dt !== 'number' || !Number.isFinite(dt) || dt < 0 || dt > MAX_DT) fail(`dt out of range: ${String(dt)}`);
      s.glow = Math.max(0, s.glow - dt);
      s.heavy = Math.max(0, s.heavy - dt);
      for (const id of LEVEL) {
        const m = s.mushrooms[id]!;
        if (!m.consumed || m.life >= MAX_LIVES) continue;
        m.consumedAge += dt;
        if (m.consumedAge >= REGROW_SECONDS - EPS) {
          // CR10: a stranger grows in its place.
          m.consumed = false;
          m.consumedAge = 0;
          m.consumedBy = null;
          m.life += 1;
          m.tasted = null;
        }
      }
      for (const ev of Object.keys(s.tasteAge)) {
        const age = s.tasteAge[ev]! + dt;
        s.tasteAge[ev] = age;
        const cav = s.evidenceCaveats[ev] ?? [];
        if (age >= FADE_SECONDS - EPS) {
          if (!cav.includes(FADED)) s.evidenceCaveats[ev] = [...cav, FADED];
          // Once faded, the age no longer matters; drop it to keep saves small.
          delete s.tasteAge[ev];
        }
      }
      return;
    }
    case 'taste': {
      const { m } = checkMushroom(s, e);
      if (m.tasted !== null) fail(`mushroom ${e.id} already tasted`);
      m.tasted = e.kind as Kind;
      const ev = evidenceId('taste', e.id, m.life);
      s.evidenceCaveats[ev] = s.glow > 0 ? [] : [DARK];
      s.tasteAge[ev] = 0;
      record(s, ev, e.kind as Kind);
      return;
    }
    case 'absorb': {
      const { m, id, kind } = checkMushroom(s, e);
      if (!mushroomView(s, id).canAbsorb) fail(`cannot absorb ${id}`);
      if (m.tasted !== null && m.tasted !== kind) fail(`kind contradicts taste of ${id}`);
      m.consumed = true;
      m.consumedAge = 0;
      const ev = evidenceId('absorb', id, m.life);
      m.consumedBy = ev;
      s.evidenceCaveats[ev] = [];
      if (kind === 'glowcap') s.glow = GLOW_SECONDS;
      // CR8: heaviness stacks up to 30 s.
      else s.heavy = s.heavy > 0 ? Math.min(HEAVY_MAX, s.heavy + HEAVY_SECONDS) : HEAVY_SECONDS;
      record(s, ev, kind);
      return;
    }
    case 'witness': {
      // CR9: another creature eats it; no effect on the slime's timers, no canAbsorb check.
      const { m, id, kind } = checkMushroom(s, e);
      if (m.tasted !== null && m.tasted !== kind) fail(`kind contradicts taste of ${id}`);
      m.consumed = true;
      m.consumedAge = 0;
      const ev = evidenceId('witness', id, m.life);
      m.consumedBy = ev;
      s.evidenceCaveats[ev] = [SECONDHAND];
      record(s, ev, kind);
      return;
    }
    default:
      fail(`unknown event type ${String((e as { type?: unknown }).type)}`);
  }
}

function render(s: State): View {
  const bs = beliefState(s);
  const sup = [...s.supportedBy];
  const con = [...s.contradictedBy];
  const belief = {
    state: bs,
    text:
      bs === 'probably_safe'
        ? 'Glowing mushrooms give you light.'
        : bs === 'probably_unsafe'
          ? 'Glowing mushrooms make you heavy.'
          : bs === 'uncertain'
            ? 'Not every glowing mushroom is safe. Taste before absorbing.'
            : '',
    note: bs === 'probably_safe' ? note(sup.length) : bs === 'probably_unsafe' ? note(con.length) : '',
    supportedBy: sup,
    contradictedBy: con,
    caveats: caveatsOf(s, [...sup, ...con]),
  };
  const mushrooms: Record<string, MushroomView> = {};
  for (const id of LEVEL) mushrooms[id] = mushroomView(s, id);
  return {
    slime: { glowing: s.glow > 0, heavy: s.heavy > 0, heavySeconds: s.heavy > 0 ? Math.max(1, Math.ceil(s.heavy - EPS)) : 0 },
    mushrooms,
    belief,
    decision: { state: s.decision.state, basis: [...s.decision.basis], reopenedBy: [...s.decision.reopenedBy], caveats: [...s.decision.caveats],
      history: s.decision.history.map((h) => ({ change: h.change, because: [...h.because] })),
    },
  };
}

// ---- CR12: compact save format ----
// Every evidence id is recorded exactly once, into supportedBy or contradictedBy,
// so the save keeps one ordered evidence table `e` and refers to it by index.
// Entry: sign (+ support / - contradiction), source letter, mushroom index,
// optional `_<life>`, optional `.` + caveat codes in order.

const SAVE_VERSION = 1;
const PREFIX_CODE: Record<string, string> = { absorb: 'a', taste: 't', witness: 'w' };
const CODE_PREFIX: Record<string, string> = { a: 'absorb', t: 'taste', w: 'witness' };
const CAVEAT_CODE: Record<string, string> = { [DARK]: 'd', [FADED]: 'f', [SECONDHAND]: 's' };
const CODE_CAVEAT: Record<string, string> = { d: DARK, f: FADED, s: SECONDHAND };
const DECISION_CODES = ['none', 'committed', 'reopened'] as const;
const TASTE_CODES = [null, 'glowcap', 'duskcap'] as const;

interface Saved {
  v: number;
  g: number;
  h: number;
  m: [number, number, number, number, number][]; // life, consumed, consumedAge, consumedBy idx|-1, tasted code
  e: string[];
  ta: [number, number][]; // [evidence idx, age] for tastes not yet faded
  sc: number[];
  d: [number, number[], number[], string, [number, number[]][]]; // state, basis, reopenedBy, caveat codes, history
}

function parseEvidenceId(ev: string): { prefix: string; idx: number; life: number } {
  const m = /^(absorb|taste|witness)_([a-z]+)(?:_(\d+))?$/.exec(ev);
  if (!m) throw new Error(`bad evidence id ${ev}`);
  const idx = LEVEL.indexOf(m[2]!);
  if (idx < 0) throw new Error(`bad evidence id ${ev}`);
  return { prefix: m[1]!, idx, life: m[3] ? Number(m[3]) : 1 };
}

function encodeCaveats(cs: readonly string[]): string {
  return cs.map((c) => CAVEAT_CODE[c] ?? fail(`unknown caveat ${c}`)).join('');
}

function decodeCaveats(code: string): string[] {
  return [...code].map((c) => CODE_CAVEAT[c] ?? fail(`unknown caveat code ${c}`));
}

function encodeState(s: State): Saved {
  const sup = new Set(s.supportedBy);
  const order: string[] = [];
  // Merge supportedBy and contradictedBy back into recording order using the
  // evidence table order kept in evidenceCaveats (insertion order of keys).
  for (const ev of Object.keys(s.evidenceCaveats)) {
    if (sup.has(ev) || s.contradictedBy.includes(ev)) order.push(ev);
  }
  const index = new Map(order.map((ev, i) => [ev, i] as const));
  const ix = (ev: string): number => index.get(ev) ?? fail(`unindexed evidence ${ev}`);
  const e = order.map((ev) => {
    const { prefix, idx, life } = parseEvidenceId(ev);
    const cav = encodeCaveats(s.evidenceCaveats[ev] ?? []);
    return `${sup.has(ev) ? '+' : '-'}${PREFIX_CODE[prefix]}${idx}${life === 1 ? '' : `_${life}`}${cav ? `.${cav}` : ''}`;
  });
  return {
    v: SAVE_VERSION,
    g: s.glow,
    h: s.heavy,
    m: LEVEL.map((id) => {
      const m = s.mushrooms[id]!;
      return [m.life, m.consumed ? 1 : 0, m.consumedAge, m.consumedBy === null ? -1 : ix(m.consumedBy), TASTE_CODES.indexOf(m.tasted)];
    }),
    e,
    ta: Object.entries(s.tasteAge).map(([ev, age]) => [ix(ev), age]),
    sc: s.sinceContradiction.map(ix),
    d: [
      DECISION_CODES.indexOf(s.decision.state),
      s.decision.basis.map(ix),
      s.decision.reopenedBy.map(ix),
      encodeCaveats(s.decision.caveats),
      s.decision.history.map((h) => [h.change === 'committed' ? 1 : 2, h.because.map(ix)]),
    ],
  };
}

function decodeState(raw: unknown): State {
  const v = raw as Saved;
  if (v === null || typeof v !== 'object' || v.v !== SAVE_VERSION) fail('unsupported save');
  const s = initialState();
  const ids: string[] = [];
  for (const entry of v.e) {
    const m = /^([+-])([atw])(\d+)(?:_(\d+))?(?:\.([a-z]+))?$/.exec(entry);
    if (!m) fail(`bad saved evidence ${entry}`);
    const id = LEVEL[Number(m[3])] ?? fail(`bad saved evidence ${entry}`);
    const life = m[4] ? Number(m[4]) : 1;
    const ev = evidenceId(CODE_PREFIX[m[2]!] as 'absorb' | 'taste' | 'witness', id, life);
    ids.push(ev);
    s.evidenceCaveats[ev] = decodeCaveats(m[5] ?? '');
    if (m[1] === '+') s.supportedBy.push(ev);
    else s.contradictedBy.push(ev);
  }
  const at = (i: number): string => ids[i] ?? fail(`bad evidence index ${i}`);
  s.glow = v.g;
  s.heavy = v.h;
  LEVEL.forEach((id, i) => {
    const [life, consumed, consumedAge, consumedBy, tasted] = v.m[i] ?? fail('bad saved mushroom');
    s.mushrooms[id] = {
      consumed: consumed === 1,
      life,
      consumedAge,
      consumedBy: consumedBy < 0 ? null : at(consumedBy),
      tasted: TASTE_CODES[tasted] ?? null,
    };
  });
  for (const [i, age] of v.ta) s.tasteAge[at(i)] = age;
  s.sinceContradiction = v.sc.map(at);
  const [state, basis, reopenedBy, cav, history] = v.d;
  s.decision = {
    state: DECISION_CODES[state] ?? fail('bad decision state'),
    basis: basis.map(at),
    reopenedBy: reopenedBy.map(at),
    caveats: decodeCaveats(cav),
    history: history.map(([c, b]) => ({ change: c === 1 ? 'committed' : 'reopened', because: b.map(at) })),
  };
  return s;
}

export function createPolicy(saved?: unknown) {
  let state: State = saved === undefined ? initialState() : decodeState(saved);
  return {
    dispatch(event: GlowEvent): void {
      const next = clone(state);
      apply(next, event);
      state = next;
    },
    view(): View {
      return render(state);
    },
    save(): unknown {
      return encodeState(state);
    },
  };
}

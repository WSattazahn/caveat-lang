// Glowcap beat policy.

export type Kind = 'glowcap' | 'duskcap';

const LEVEL: readonly string[] = ['cave', 'pool', 'ruin', 'grove'];
const KINDS: readonly string[] = ['glowcap', 'duskcap'];
const GLOW_SECONDS = 30;
const HEAVY_SECONDS = 20;
const HEAVY_MAX = 30;
const MAX_DT = 0.1;
const REGROW_SECONDS = 45;
// CR10: declared capacity of lives per mushroom (spec requires at least 64).
export const MAX_LIVES = 1024;
const DARK = 'tasted_in_dark';
const FADED = 'taste_faded';
const SECONDHAND = 'secondhand';
const FADE_SECONDS = 60;
// Tolerance so that e.g. 600 ticks of 0.1 s count as a full minute despite float rounding.
const EPS = 1e-9;

interface MushroomState {
  consumed: boolean;
  // CR10: 1-based life number of the current (or last consumed) mushroom.
  life: number;
  // CR10: seconds (sum of tick dt) since this life was consumed.
  consumedAge: number;
  // CR11: evidence that consumed the current life (null while present).
  consumedBy: string | null;
  tasted: Kind | null;
}

interface State {
  glow: number;
  heavy: number;
  mushrooms: Record<string, MushroomState>;
  supportedBy: string[];
  contradictedBy: string[];
  // CR3: caveats carried by each evidence id.
  evidenceCaveats: Record<string, string[]>;
  // CR5: seconds elapsed (sum of tick dt) since each taste.
  tasteAge: Record<string, number>;
  // CR7: glowcap observations since the most recent contradiction.
  sinceContradiction: string[];
  // caveats: frozen at commit time (CR5).
  decision: { state: 'none' | 'committed' | 'reopened'; basis: string[]; reopenedBy: string[]; caveats: string[]; history: HistoryEntry[] };
}

export interface HistoryEntry {
  change: 'committed' | 'reopened';
  because: string[];
}

export type BeliefState = 'none' | 'probably_safe' | 'probably_unsafe' | 'uncertain';

export interface MushroomView {
  present: boolean;
  label: string;
  canAbsorb: boolean;
  canTaste: boolean;
  because: string[];
  caveats: string[];
  why: { absorb: WhyView; taste: WhyView };
}

export interface WhyView {
  reason: string;
  because: string[];
  caveats: string[];
}

export interface View {
  slime: { glowing: boolean; heavy: boolean; heavySeconds: number };
  mushrooms: Record<string, MushroomView>;
  belief: { state: BeliefState; text: string; note: string; supportedBy: string[]; contradictedBy: string[]; caveats: string[] };
  decision: { state: 'none' | 'committed' | 'reopened'; basis: string[]; reopenedBy: string[]; caveats: string[]; history: HistoryEntry[] };
}

export type GlowEvent =
  | { type: 'absorb'; id: string; kind: string }
  | { type: 'taste'; id: string; kind: string }
  | { type: 'witness'; id: string; kind: string }
  | { type: 'tick'; dt: number };

function initialState(): State {
  const mushrooms: Record<string, MushroomState> = {};
  for (const id of LEVEL) mushrooms[id] = { consumed: false, life: 1, consumedAge: 0, consumedBy: null, tasted: null };
  return {
    glow: 0,
    heavy: 0,
    mushrooms,
    supportedBy: [],
    contradictedBy: [],
    evidenceCaveats: {},
    tasteAge: {},
    sinceContradiction: [],
    decision: { state: 'none', basis: [], reopenedBy: [], caveats: [], history: [] },
  };
}

function clone<T>(v: T): T {
  return JSON.parse(JSON.stringify(v)) as T;
}

function beliefState(s: State): BeliefState {
  const sup = s.supportedBy.length > 0;
  const con = s.contradictedBy.length > 0;
  if (sup && con) return 'uncertain';
  if (sup) return 'probably_safe';
  if (con) return 'probably_unsafe';
  return 'none';
}

function note(n: number): string {
  return n === 1 ? 'Based on one observation.' : `Based on ${n} observations.`;
}

function fail(msg: string): never {
  throw new Error(msg);
}

function checkMushroom(s: State, e: { id?: unknown; kind?: unknown }): { m: MushroomState; id: string; kind: Kind } {
  if (typeof e.id !== 'string' || !Object.hasOwn(s.mushrooms, e.id)) fail(`unknown mushroom ${String(e.id)}`);
  if (typeof e.kind !== 'string' || !KINDS.includes(e.kind)) fail(`unknown kind ${String(e.kind)}`);
  const m = s.mushrooms[e.id as string]!;
  if (m.consumed) fail(`mushroom ${e.id as string} already consumed`);
  return { m, id: e.id as string, kind: e.kind as Kind };
}

// Rules for one mushroom, shared by the view and by absorb validation.
// CR10: evidence id for the current life of a mushroom.
function evidenceId(prefix: 'absorb' | 'taste' | 'witness', id: string, life: number): string {
  return life === 1 ? `${prefix}_${id}` : `${prefix}_${id}_${life}`;
}

function caveatsOf(s: State, evidence: readonly string[]): string[] {
  const out = new Set<string>();
  for (const ev of evidence) for (const c of s.evidenceCaveats[ev] ?? []) out.add(c);
  return [...out];
}

function mushroomView(s: State, id: string): MushroomView {
  const v = mushroomRule(s, id);
  return { ...v, caveats: caveatsOf(s, v.because), why: whyNot(s, id) };
}

// CR11: why an action is not allowed (first match), or reason '' when allowed.
function whyNot(s: State, id: string): { absorb: WhyView; taste: WhyView } {
  const m = s.mushrooms[id]!;
  const mk = (reason: string, because: string[]): WhyView => ({ reason, because, caveats: caveatsOf(s, because) });
  const allowed = mk('', []);
  const tasteEv = evidenceId('taste', id, m.life);
  if (m.consumed) {
    const by = m.consumedBy !== null ? [m.consumedBy] : [];
    return { absorb: mk('Already eaten', by), taste: mk('Already eaten', [...by]) };
  }
  let absorb = allowed;
  if (m.tasted === 'duskcap') absorb = mk('Known duskcap', [tasteEv]);
  else if (m.tasted === null && s.contradictedBy.length >= 2) absorb = mk('Too risky untasted', [...s.contradictedBy]);
  const taste = m.tasted !== null ? mk('Already tasted', [tasteEv]) : mk('', []);
  return { absorb, taste };
}

function mushroomRule(s: State, id: string): Omit<MushroomView, 'caveats' | 'why'> {
  const m = s.mushrooms[id]!;
  const bs = beliefState(s);
  const sup = s.supportedBy;
  const con = s.contradictedBy;
  const tasteEv = evidenceId('taste', id, m.life);
  const tc = s.evidenceCaveats[tasteEv] ?? [];
  const dark = tc.includes(DARK);
  const faded = tc.includes(FADED);
  const qual = faded ? ' (taste has faded)' : dark ? ' (tasted in the dark)' : '';
  if (m.consumed) return { present: false, label: '', canAbsorb: false, canTaste: false, because: [] };
  if (m.tasted === 'glowcap')
    return { present: true, label: qual ? `Probably a glowcap${qual}` : 'Glowcap', canAbsorb: true, canTaste: false, because: [tasteEv] };
  if (m.tasted === 'duskcap')
    return { present: true, label: qual ? `Probably a duskcap${qual}` : 'Duskcap — avoid', canAbsorb: false, canTaste: false, because: [tasteEv] };
  // CR2: twice bitten.
  if (con.length >= 2) return { present: true, label: 'Too risky — taste first', canAbsorb: false, canTaste: true, because: [...con] };
  if (bs === 'none') return { present: true, label: 'Glowing mushroom', canAbsorb: true, canTaste: true, because: [] };
  if (bs === 'probably_safe') return { present: true, label: 'Probably a glowcap', canAbsorb: true, canTaste: true, because: [...sup] };
  if (bs === 'probably_unsafe') return { present: true, label: 'Probably a duskcap', canAbsorb: true, canTaste: true, because: [...con] };
  // CR4: cite the counterexample only.
  return { present: true, label: 'Could be a duskcap — taste first', canAbsorb: true, canTaste: true, because: [...con] };
}

// Adds one piece of evidence to the belief and updates the trust decision.
function commit(s: State, basis: string[]): void {
  s.decision = {
    state: 'committed',
    basis: [...basis],
    reopenedBy: [],
    caveats: caveatsOf(s, basis),
    history: [...s.decision.history, { change: 'committed', because: [...basis] }],
  };
}

function record(s: State, ev: string, kind: Kind): void {
  if (kind === 'glowcap') {
    s.supportedBy.push(ev);
    s.sinceContradiction.push(ev);
    if (s.decision.state === 'none' && beliefState(s) === 'probably_safe') {
      commit(s, s.supportedBy);
    } else if (s.decision.state === 'reopened' && s.sinceContradiction.length >= 2) {
      // CR7: trust recovers on the second glowcap observation since the latest contradiction.
      commit(s, s.sinceContradiction.slice(0, 2));
    }
  } else {
    s.contradictedBy.push(ev);
    s.sinceContradiction = [];
    if (s.decision.state !== 'none') {
      s.decision.state = 'reopened';
      s.decision.reopenedBy.push(ev);
      s.decision.history.push({ change: 'reopened', because: [ev] });
    }
  }
}

// Applies an event to a state in place. Throws (before or after partial mutation)
// on rejection; the caller discards the working copy in that case.
function apply(s: State, e: GlowEvent): void {
  if (e === null || typeof e !== 'object') fail('event must be an object');
  switch (e.type) {
    case 'tick': {
      const dt = e.dt;
      if (typeof dt !== 'number' || !Number.isFinite(dt) || dt < 0 || dt > MAX_DT) fail(`dt out of range: ${String(dt)}`);
      s.glow = Math.max(0, s.glow - dt);
      s.heavy = Math.max(0, s.heavy - dt);
      for (const id of LEVEL) {
        const m = s.mushrooms[id]!;
        if (!m.consumed || m.life >= MAX_LIVES) continue;
        m.consumedAge += dt;
        if (m.consumedAge >= REGROW_SECONDS - EPS) {
          // CR10: a stranger grows in its place.
          m.consumed = false;
          m.consumedAge = 0;
          m.consumedBy = null;
          m.life += 1;
          m.tasted = null;
        }
      }
      for (const ev of Object.keys(s.tasteAge)) {
        const age = s.tasteAge[ev]! + dt;
        s.tasteAge[ev] = age;
        const cav = s.evidenceCaveats[ev] ?? [];
        if (age >= FADE_SECONDS - EPS && !cav.includes(FADED)) s.evidenceCaveats[ev] = [...cav, FADED];
      }
      return;
    }
    case 'taste': {
      const { m } = checkMushroom(s, e);
      if (m.tasted !== null) fail(`mushroom ${e.id} already tasted`);
      m.tasted = e.kind as Kind;
      const ev = evidenceId('taste', e.id, m.life);
      s.evidenceCaveats[ev] = s.glow > 0 ? [] : [DARK];
      s.tasteAge[ev] = 0;
      record(s, ev, e.kind as Kind);
      return;
    }
    case 'absorb': {
      const { m, id, kind } = checkMushroom(s, e);
      if (!mushroomView(s, id).canAbsorb) fail(`cannot absorb ${id}`);
      if (m.tasted !== null && m.tasted !== kind) fail(`kind contradicts taste of ${id}`);
      m.consumed = true;
      m.consumedAge = 0;
      const ev = evidenceId('absorb', id, m.life);
      m.consumedBy = ev;
      s.evidenceCaveats[ev] = [];
      if (kind === 'glowcap') s.glow = GLOW_SECONDS;
      // CR8: heaviness stacks up to 30 s.
      else s.heavy = s.heavy > 0 ? Math.min(HEAVY_MAX, s.heavy + HEAVY_SECONDS) : HEAVY_SECONDS;
      record(s, ev, kind);
      return;
    }
    case 'witness': {
      // CR9: another creature eats it; no effect on the slime's timers, no canAbsorb check.
      const { m, id, kind } = checkMushroom(s, e);
      if (m.tasted !== null && m.tasted !== kind) fail(`kind contradicts taste of ${id}`);
      m.consumed = true;
      m.consumedAge = 0;
      const ev = evidenceId('witness', id, m.life);
      m.consumedBy = ev;
      s.evidenceCaveats[ev] = [SECONDHAND];
      record(s, ev, kind);
      return;
    }
    default:
      fail(`unknown event type ${String((e as { type?: unknown }).type)}`);
  }
}

function render(s: State): View {
  const bs = beliefState(s);
  const sup = [...s.supportedBy];
  const con = [...s.contradictedBy];
  const belief = {
    state: bs,
    text:
      bs === 'probably_safe'
        ? 'Glowing mushrooms give you light.'
        : bs === 'probably_unsafe'
          ? 'Glowing mushrooms make you heavy.'
          : bs === 'uncertain'
            ? 'Not every glowing mushroom is safe. Taste before absorbing.'
            : '',
    note: bs === 'probably_safe' ? note(sup.length) : bs === 'probably_unsafe' ? note(con.length) : '',
    supportedBy: sup,
    contradictedBy: con,
    caveats: caveatsOf(s, [...sup, ...con]),
  };
  const mushrooms: Record<string, MushroomView> = {};
  for (const id of LEVEL) mushrooms[id] = mushroomView(s, id);
  return {
    slime: { glowing: s.glow > 0, heavy: s.heavy > 0, heavySeconds: s.heavy > 0 ? Math.max(1, Math.ceil(s.heavy - EPS)) : 0 },
    mushrooms,
    belief,
    decision: { state: s.decision.state, basis: [...s.decision.basis], reopenedBy: [...s.decision.reopenedBy], caveats: [...s.decision.caveats],
      history: s.decision.history.map((h) => ({ change: h.change, because: [...h.because] })),
    },
  };
}

export function createPolicy(saved?: unknown) {
  let state: State = saved === undefined ? initialState() : clone(saved as State);
  return {
    dispatch(event: GlowEvent): void {
      const next = clone(state);
      apply(next, event);
      state = next;
    },
    view(): View {
      return render(state);
    },
    save(): unknown {
      return clone(state);
    },
  };
}
